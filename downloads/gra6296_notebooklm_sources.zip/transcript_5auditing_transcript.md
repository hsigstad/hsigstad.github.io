# Lecture Transcript: 5Auditing

## About This Document

This is a transcript of lectures from the course **GRA6296 - Economic Analysis of Topics in Law** at BI Norwegian Business School, taught by Henrik Sigstad.

**Slide deck:** 5auditing.pdf
**Lecture date(s):** January 27, 2026, February 03, 2026

This transcript has been cleaned for readability. The original was auto-generated from lecture recordings using OpenAI Whisper.

---

## January 27, 2026

### Slide 1 - Auditing

Which takes us to the next slide deck. We're going to talk a little bit about auditing because we're going to use that as a case to enter into tort law. Think of this as an example that we're going to build up, and we will apply the economic theory of tort law to this case. On the exam, you might have a different case that is not auditing, but we can apply the same thinking. We're going to be quite detailed about what good auditing is and when auditors should be liable to use as an example when we introduce things about tort law.

### Slide 2 - Auditing (revisjon)

Okay, so auditing is basically analyzing a company's financial records and statements to determine whether they are accurate. It's the way to certify the statements that Wirecard was making about their profits and assets.

### Slide 3 - The Big Four Auditing Firms

You know these big four auditing firms.

### Slide 4 - Why Do Firms Hire Auditors?

So these are familiar names. First question: why do firms hire auditors?

### Slide 5 - Why Do Firms Hire Auditors?

The first reason is that it's mandatory for public companies to have an audit. But there's also another reason why they would probably do it even without this mandatory rule, which is that if they don't have their statements audited by someone externally, people may not believe them.

### Slide 6 - Why Do Firms Hire Auditors?

If investors don't trust the company's statements about its financial position, they are not going to invest. So companies want someone external to validate these numbers, even if it's not mandatory.

### Slide 7 - Analogy: Used Car Dealer

Think about a guy trying to sell you a used car. Would you trust what he tells you about the car? You might not trust everything he says because he has incentives to sell the car and may overstate how good it is.

### Slide 9 - What Can The Dealer Do To Make You Trust Him?

How does this guy deal with that situation? He will get an external company to verify the condition of the car. In the US, they have similar ways of verifying used cars, and in Norway, there are trusted experts who do this. The dealer would pay these experts to verify the car's condition. When he sells you the car, he won't just say, "This is like new," but will also show you a document that someone external has certified it as such.

This guy has incentives to hire these external organizations to certify the car in order to sell it to you.

### Slide 10 - A Business Executive Seeking Investors

In the same way, some business executives seeking investors have incentives to get someone to certify their financial positions.

### Slide 11 - A Business Executive Seeking Investors

Because otherwise investors might not trust what you say about the company and how good it's going to be.

### Slide 12 - What Can She Do To Make You Trust Her?

So she has incentives to hire an auditor to audit the financial statements of the firm in order to attract investors, just like a used car dealer would want to hire someone external to verify the car.

### Slide 14 - Why Would An Auditor Be Independent?

In this case, she can hire Ernst & Young to do that. This is the basic economic logic behind auditing. First, why do we need it? And second, why do firms actually want to do it? Of course, it's also mandatory, but even without this requirement, firms have strong reasons to select an auditing company that is trusted by everyone.

Okay, which brings us to the second question: why would this auditor be independent? We're not going to talk too much about this, but it's an interesting question. Auditors are paid by the firm that they audit. Often, these audit companies could provide consulting services to the same firms. If they give a bad opinion about the firm, they might lose future business. So, in a sense, these auditing companies have strong incentives to be very positive about the books and say that everything is good.

### Slide 15 - Example: Arthur Andersen

Way back, before 2002, there was the Big Five. Arthur Andersen was the fifth big auditing company, but it turned out that this company had been too lenient and signed off the books for the American firm Enron, which was involved in massive fraud. In the end, Arthur Andersen went out of business because of this scandal. First, they had legal issues, but also because people wouldn't use this company anymore; they didn't trust their statements. Now you see that auditing companies have incentives to behave in a neutral way. If they don't, no one would want to hire them as an auditor, and it wouldn't be a credible signal to investors if they had their financial statement signed off by Arthur Andersen.

### Slide 17 - Do Auditors Have Incentives to Be Independent?

Let me just restate this. Assume that Arthur Andersen gives an unqualified audit to any firm as long as the firm spends one million on their consulting services. Assume it's legal.

### Slide 18 - Mentimeter

Would this business strategy work?

### Slide 19 - No, the business strategy would likely not work

Likely not. Even if this were legal, it wouldn't work in the long term because people would eventually understand how Arthur Andersen operates. The fact that the financial statement of the firm is signed off by Arthur Andersen wouldn't signal trustworthy information anymore.

### Slide 20 - Incentives To Be Independent

In fact, at the beginning, Arthur Andersen was famous for being very trustworthy.

He refused to sign off the accounts of one big railroad company and lost this customer, but he maintained his reputation for being willing to reject flawed accounts. This is how the firm became important.

### Slide 21 - More Incentives To Be Independent

Eventually, this changed, and Arthur Andersen didn't become reliable anymore because they were too interested in consulting fees.

In addition to having these market-based incentives to become independent, auditors also face criminal and civil liability.

### Slide 22 - A Munich court opened a class-action style procedure against Ernst

All right. This was a slight detour about auditing. Let's go back to what we're going to think about.

In the Wirecard case, Ernst & Young was sued by the investors because they claimed that Ernst & Young didn't do a good job in their auditing.

### Slide 23 - Criminal Liability of Auditors in Norway

You can also be criminally liable if you're doing a very bad audit. There are instances of auditors going to prison, or in some cases, receiving a conditional prison sentence.

### Slide 24 - Norway’s Biggest Financial Fraud

This is the Wirecard of Norway, finance credit back in the 90s.

### Slide 25 - KPMG Found Liable for The Losses

KPMG had to pay over 600 million Norwegian kroner in this case.

This was a lawsuit brought by the investors against the auditing company. It's a huge fine.

### Slide 26 - KPMG Auditor 30 Days Prison

The auditor was imprisoned in this case. It's extremely rare that this happens, but it did happen here.

### Slide 27 - The Wirecard Audit

Okay, so let's talk about the Wirecard audit.

### Slide 29 - How Could You As An Auditor Have

What would you have done in this case to actually detect fraud? It's easy to say with hindsight that Ernst & Young should have seen this, but the question is, what would you have done if you had been the auditor of Wirecard?

### Slide 30 - Wirecard 2016 Income Statement

So, as you know, this was the audit statement in 2019 that everything looked good.

### Slide 31 - How would you verify Wirecard’s income

This is the income statement from 2016, showing very high profits. Your task is to verify that these numbers are correct. This is not really a course about auditing, but to keep you engaged, talk to your neighbor and think about what you would have done and how you could have discovered this fraud.

Okay, so any thoughts or ideas?

I'm not an expert in auditing, so what I'm going to say may not be the best way, but I'll share my thoughts.

### Slide 32 - One Answer

Look at the cash flow and all the transactions coming in. They have a lot of profits here. You might want to check the revenues. There should be some incoming funds for the company. Are these revenues actually true? You can ask to see these incoming revenues, for instance. Good idea.

Any other thoughts? Or maybe you had more in mind than this.

First, figure out where this income comes from. Depending on the source, you may have different ways of verifying it.

Any more ideas?

In this case, that would probably have worked, but there was a simpler way of figuring this out, with hindsight, of course.

The key idea here is that if Wirecard had huge profits over the years, it must have a lot of assets somewhere. There are two ways of auditing. You can first check the transactions to see if they are right, but the other way is to check if the company really has a huge pile of assets. What does this company own? If you look at the assets, you see that all of them were in cash and cash equivalents. This is a big part of it. Then you can just ask, where is this money?

### Slide 36 - EY Did Not Verify Wirecard’s Bank Accounts

If they say, "Oh, it's in this bank," then as an auditor, you can send a letter to that bank to confirm that the money is actually there.

In this case, Wirecard claimed it had one billion euros in a bank in Singapore.

Ernst & Young never checked this directly with the bank. It's a huge amount of money that they didn't check directly. Instead, they relied on some documents and screenshots provided by Wirecard and a third party, but not directly with the bank. In fact, this money didn't exist.

With hindsight, it would have been extremely easy for Ernst & Young to understand that this was a fraud. But of course, it's easy to say that with hindsight.

If you claim that you have a large amount of money in the bank, it's probably a good idea to check that.

### Slide 37 - Should EY Be Held Responsible?

Should Ernst & Young be held responsible for not detecting this?

### Slide 38 - Possible defense by EY

They can say that they didn't claim there was no fraud. They just said in their statement that they were reasonably sure that Wirecard's statements were correct. They verified a random sample of bank accounts, and everything looked good. As auditors, they cannot be expected to detect all instances of fraud.

This is their line of defense in the lawsuit. In their statement, they only say that they are reasonably sure. They don't say they are completely sure there's not a fraud.

### Slide 39 - How Much Auditing is Socially Optimal?

So then the question is, how much auditing would we expect these auditing companies to do? What is really reasonably sure? Were they actually reasonably sure? Did they do a reasonably good audit here or not? That's the key question the court will have to consider when looking at this Wirecard case. In hindsight, it's easy to say that they should have audited more, but maybe it's not reasonable for audit firms to check everything. It's going to be very costly.

### Slide 40 - Mentimeter

This is a guessing exercise. This is not the true numbers, but assume that Wirecard claims it has 1.4 billion, spread across 1,000 bank accounts. You, as an auditor, should decide how many of these bank accounts to check.

The question is, what is the optimal audit? Should we require auditors to check all 1,000? Or maybe a random sample of five is enough, or 50, or 100? You don't have all the numbers here to answer, but answer based on your gut feeling. You can talk to your neighbor if you want to.

There's no correct answer here because it depends on the numbers, but there is a majority for 100.

### Slide 42 - Cost-Benefit Analysis

Let me give you an example where I can actually calculate the optimal audit. Of course, it requires us to know all the numbers and all the cost parameters.

Okay.

According to cost-benefit analysis, we should check another account if the benefit exceeds the cost. In this example, let's assume that the cost is the cost of performing the audit procedure, the cost of sending that email to the bank, and so on. Assume that the benefit is the reduced loss for the investors.

### Slide 43 - Simplification

I'm not completely happy with this assumption because the benefit for society is really the increased trust in capital markets. But for this to fit what we're going to say later about tort law, I'll just assume that the benefit equals the reduced loss for the investors. This takes into account the cost and the benefit for the investors and the auditor, but not the benefit for the CEO to invest all these funds, or the cost in terms of lack of allocation of capital in the future.

### Slide 44 - Simplification

Okay, so this is a simplification. In reality, this is the correct cost-benefit analysis to think about: the investor loses $1 million, they expect to gain $1 million, and then there's a misallocation of capital in the future because people trust capital markets less. But I'm just assuming away these two terms and just thinking about the costs for the investor and the costs and benefits for the investor and the auditing company.

This is to keep it simple and in line with what the book will discuss when it talks about tort law.

## February 03, 2026

### Slide 1 - Auditing

Let's start this lecture by talking about the notebook I shared with you. I will also go over the AI-generated feedback I provided. I want to comment on that feedback so you can understand the quality and what to trust. Then we will continue with the audit lecture and probably start with tort law.

As you know, all students and faculty at BI should have access to the Google AI tools, and Notebook LM is one of those tools. This is the first time I'm using it myself. I set up a notebook for our course and tried to share it with you on your student emails.

Did anyone get that email? Let me know if you didn't receive it, and I can send it again. I uploaded the slides up until tort law. I will continue uploading the later slides as we move along, but there’s no need to add the slides on contract law at this point. I took the book and selected all the relevant chapters that are on the syllabus. Some parts in this PDF are not on the syllabus. For example, we have chapter two, A, B, C, but not D, and then E. So D would be included. Most of this PDF contains only the chapters that are on the syllabus. I also added some past exams and will add a couple more. I included the syllabus and another file about how to make the notebook understand what this is all about. I'm not sure if you need to do that.

I added the solutions to past exams as well. They are online, but you should not look at these solutions now because it will ruin your chance to practice for the exam. The past exam is one way to practice, and if you look at the solution now, you can't use it to test yourself later. The notebook will know the structure of a good exam answer and the format of the exam. You can type in the chat to give me a new exam question or set of questions, and it will generate something similar to past exams. But don't do that yet because it doesn't completely know how I will generate the exam. I will give you a separate AI tool to create realistic exam questions that look like what I will do. The point of this notebook is that you can ask any question about the course, and it will answer based on the sources.

Here are some examples of prompts you can add.

Let's see.

You can ask questions like, "What happens in this model if we change some assumptions?" It will generate output based on the sources.

You can interact with this in any way you want.

Think of this chat as a way to look things up. Instead of scrolling through the PDF of the book, you can easily access the parts you're interested in. You can ask it to explain things better if you don't understand. It links to the slides, for instance. This is the book, and you can go there to look at the text.

You can also generate a lot of summaries of the material in different ways. You've probably seen this famous podcast. It's impressive what kind of content it can generate. Let's see if we can... There's no sound here. You can generate podcasts.

I can't play it for you, but it does a much better job at explaining the Wirecard scandal. The guys in the podcast are much better than me at presenting the material. They are mostly correct, though I noticed a few mistakes that weren't entirely accurate. In general, I think it's good because it's based on the sources.

You can generate these mind maps that organize the material for you. You can also generate videos. I think this is supposed to be a video.

You can't see the sound here. I hear the sound, but there is sound.

There is sound, but I'm not sure how to make it work. Okay, I cannot make this sound work, but...

You can generate these by yourself if you want to have the case materials summarized in a different way, probably a better way than I do. You can test yourself with a quiz.

This is not going to be exam questions, so if you do well on this quiz, it doesn't mean you will do well on the exam. But it can help you remember what the terms mean. For memorizing knowledge, these kinds of quizzes work for the skill I want you to learn. A lot of what you can do in the notebook is not that useful because the only way to learn the skill of economic reasoning is to try to do it. You can generate nice content to summarize the material and test your knowledge with the quiz. You can do a lot of useful things here. But if you never try to actually solve past exam questions without the help of AI, you're not going to do well on the exam.

You have to practice solving actual exam questions to do well because you're not going to have an AI to write the exam answer for you. I think all of this is extremely useful, but...

It cannot substitute for actually trying to think for yourself and developing this economic reasoning skill by solving exam-type questions. Do all of this if you find it useful to learn the material and develop your knowledge. But it's not necessarily good for developing your skills. To get a skill, you first need knowledge, so knowledge is important.

But make sure you also practice the skill that you need.

I find these slides that summarize the material pretty nice as well.

It's extremely impressive and nice looking.

I would definitely do this if I were a student, but don't only do it.

Does anyone have questions or experiences to share using these tools? Maybe some of you have more experience than I do, or suggestions on how I can add more material. When you access this notebook, you can see the sources, download it, and create your own notebook if you want to add more materials. You can generate all kinds of podcasts and things on your own. It won't be shared with anyone else but yourself.

The only thing that is shared is the sources. You are not allowed to modify the sources.

Any questions, comments, ideas, or experiences you want to share?

As I said, I think this is extremely impressive. You should use it for all it's worth, but make sure you don't replace your own thinking with AI. Let me go over the generated feedback for you. This is simulated; it's not one of your answers.

I asked it to generate an answer that was medium weak.

I think you all should have received these HTML files. If you had any problems opening them, let me know. You should be able to download them and open them on a laptop. Opening them on a phone might not be straightforward, but it should work fine on a laptop.

These criteria are what I will use when grading the exam. You see a summary of what the model thinks about your performance on these criteria. If you're here, the choice of theory was weak because economic frameworks were not clearly identified. The answer doesn't specify which theories are used, so this was a correct comment identified by the model.

It lacks economic reasoning about deterrence and cost-benefit trade-off.

This is also a correct comment. This one assumes that the aim is to make sure that everyone pays their taxes, and the punishment is severe with a high probability of detection. That’s going to be very costly.

It also doesn't take into account that sometimes you might want some tax evasion to happen because it might be too costly to fight it.

Yeah.

It should be feasible to check everyone's tax returns carefully. That’s a nice statement, but the real question is whether the cost is high or not. I think this comment was also okay.

Assumptions.

Sometimes I think these assumption comments are a bit too aggressive in stating that you should have assumed a lot of things that you don't necessarily need to assume. Let's see how it did here.

I'm not sure if I totally agree with this. It doesn't really state the assumption that this is feasible, but it's very implicit that this is an assumption. I think this is okay. I wouldn't be too strict on the exam about naming all of the assumptions you implicitly make. However, if there are critical assumptions for the result and you don't state or discuss them, especially what happens if these assumptions change, that could hurt your grade. You don't have to make sure that everything you say is clearly stated as an assumption. But if something is clearly important for the conclusion and you never discuss it, that's not good.

Then you have this feed forward, which explicitly identifies frameworks. This is fine. The feed forward here is meant to give you the most important things you need to fix or think about in the future. Maybe next time you answer, you do what was suggested in the feed forward and receive new feedback. It tries to identify how you can improve your answer, focusing on the main ways to enhance your reasoning or written answers. It doesn't list ten different things to focus on, so these feedbacks are not a complete list of all the errors you made. Instead, it summarizes the kinds of reasoning mistakes you make and gives a few examples, but not all of them.

It aims to avoid overwhelming you with feedback, ensuring that the main message comes across.

Yeah.

The comment here is that this was not really about tax evasion. This is about a different question or something we saw in lecture, but it's not about this case. The student, or the synthetic student, is talking about something else than the case, which looks like the student has copied this from a different case. It's trying to detect whether you actually engaged with the case or just copied from your notes. In general, I think the feedback is very good. You should trust it. Your immediate reaction should be to take it seriously. But if you read it carefully and it doesn't make sense to you, it might be that the comment is off. There's no guarantee that these comments are always pointing out the most important mistakes you're making or that everything would be counted as a mistake by me.

Try to make your own judgment as well.

Don't take everything with a little grain of salt. From my review, I think I agree with about 90% of the comments. So it's pretty good.

But I'm not going to be able to read through all of the generated feedback and check which ones are right or wrong because that's going to be too much work for me.

So, any questions?

The prompt behind this generator is very elaborate and states explicitly what we're covering in the course, exactly what the terms we're using are, and everything. It's a very detailed prompt. I've been working on it for several days, going back and forth to make sure it's calibrated to what I'm trying to teach you and how I will grade on the exam.

Okay, so let's go back to the lecture.

### Slide 39 - How Much Auditing is Socially Optimal?

We are talking about what is an optimal audit. Just to remind you what we have in mind here, these are the assumptions we set up last time.

### Slide 50 - One Bank Account Verified

There is...

A firm that claims it has 1 billion in assets divided equally across 1,000 bank accounts. 5% of firms are fraudulent, so there's a 5% chance that this firm is a fraud. If it's a fraud, 20% of the bank accounts are going to be fake. If it's not a fraud, then the money will be there in all the bank accounts. The question is, how many of these bank accounts should you check as an auditor if the cost is $100 each time you check a bank account? You verify that the money is there.

### Slide 53 - Formula

So this will be the fraudulent firm, and this will be the honest firm. You're starting without knowing anything. You check one account and find that the money is there. You then update the probability that this is a fraud. Now it's 4% instead of 5%. You don't have to know the formula for calculating that probability, but there is one. After checking five accounts, the probability is 1.7% that this firm is a fraud. After checking, say, 20% or 30%, you're extremely sure that this is not a fraud. Even though there are 1,000 accounts, checking 21 accounts is sufficient for you to be extremely sure that this is not a fraud. It won't be cost-effective to check more accounts because the reduction in cost for investors will be less than 100 by checking one more account.

### Slide 56 - The Benefit Of Verifying Accounts

Here is that table. Once you have checked 21 accounts, the benefit of checking one more account is 97 euros, and the cost is 100. So you should stop at that point. If we are maximizing the total cost, we're reducing the total cost for the auditor plus the investors.

### Slide 61 - Notation

This is the notation from the book. X is the number of accounts verified. W is the cost of verifying an account. A is the investor's loss from an undetected fraud, which is one million. That's what they are about to invest.

P is the probability that the firm is a fraud.

In terms of the notation from the book, x is the number of accounts verified, px is the probability of being a fraud. The decrease in the fraud probability is minus the derivative of p. The marginal social benefit is this reduction times what the investors are about to invest.

### Slide 62 - The Optimal Number of Accounts To Verify

The audit that minimizes the expected social cost is arguably the best audit possible because we care not only about minimizing the loss from fraud but also the cost of the actual audit. Auditing all 1,000 accounts is going to be too expensive to be worth it.

This is based on a picture from the book.

You will have the expected harm. This is the expected cost of fraud. It decreases the more accounts you check. But the cost of the audit increases linearly with the number of accounts you check. The black line represents the sum of the cost of fraud and the cost of the audit. At one point, you reach a minimal cost, and that's the optimal audit.

This also connects to the book. In the book, they use derivatives. Think of derivatives here just as the cost of checking one more account. You don't have to know calculus to understand this. It's about how the probability of fraud decreases once you check one more account. In the table, it's this column here. Checking one more account decreases the probability of fraud by 0.0097 percentage points, which is a very small decrease.

You should stop when the benefit in terms of the reduction in the probability of fraud times the loss, if there's a fraud, is equal to the cost of the fraud.

The cost of the audit is the cost of auditing one more account. When the benefit of verifying one more account equals the cost of verifying one more account, you should stop. If the benefit is lower than the cost, then you shouldn't continue checking accounts.

Linking this to the book, another way to draw this in a graph is to look at the marginal social benefit and the marginal cost. The marginal benefit is the benefit of checking one more account, represented by this orange line. The marginal cost is 100 per account, so it stays constant. After 21, the marginal social benefit of checking one more account is lower than the cost, so you shouldn't do it.

### Slide 66 - Mentimeter

Assume investors consider this as checking your understanding. Assume investors consider investing 10 million instead of 1 million.

How many accounts should you verify? Should you verify fewer accounts than 21, the same number, exactly 21, or should you verify more accounts? Should you do a more careful audit if investors are considering investing 10 million instead of 1 million, or maybe a less careful audit, or the same level?

### Slide 67 - Correct Answer: More

Maybe not all of you saw the correct answer, which is more accounts. The question is, why do you have to check more accounts? In this case, why is it optimal to check more accounts? Does anyone want to try to explain why?

Why would an optimal audit be more careful in this case?

You can talk to your neighbor a bit, and then whenever you have something, you can raise your hand.

Does anyone want to try to explain why we should audit more accounts in this case?

You don't have to connect it to the theory if you don't see that connection, but if you have a gut feeling of why, you can also try to explain that.

Yes?

Can you repeat the last part?

Okay, great. So there...

The idea is that there might be more investors.

If there's 10 million, there might be more investors who get angry, which means you should audit more carefully.

So it...

### Slide 70 - If Investors Consider Investing €10 million

It could definitely be that there are more investors here, but I think if there were just one million and 10 investors instead of one, the optimal audit would still be 21. So if I allow for more than one investor, the number of investors doesn't matter; what matters is the total amount.

But maybe one can set up a theory where the number of investors matters, but not in my theory. Any other questions? Who wants to try?

Excellent. So when the amount to be invested is 10 million, the benefit of reducing the probability of fraud is higher. If there's fraud, you will lose 10 million instead of 1 million. This means that reducing the probability of fraud by 0.009 percentage points could actually make sense because you have to multiply that reduced probability by 10 million instead of 1 million.

The cost of doing the audit is the same, but the benefit of auditing is higher because you avoid losing 10 million. That's a higher number than avoiding losing 1 million. So that is the correct intuition.

So you see here, the benefit of verifying one more account decreases the probability of fraud. But once you multiply that by the amount lost by investors, you get higher numbers. The benefit of verifying more accounts is multiplied by 10. You want to be much more sure that it's not fraud. With these numbers, it's optimal to audit 32 instead of 21 accounts. Then you're down to a probability of fraud of 0.004%, which is extremely low.

At that point, the value of checking one more account decreases the probability of fraud by 0.008 percentage points. When you multiply that very low number by 10 million, you get to 80. It's not zero, but it's lower than the cost of checking one more account, so you should stop there. Even though the amount here is 10 times as much, you don't have to check 10 times as many bank accounts. You just check 10 more. This will generally be true. Are you supposed to check the one that costs more than it's worth as well? No, you should stop. This is the benefit of verifying a 33rd account.

This is verifying one more account after that. You should not continue if the cost of verifying the next account is higher than the benefit. You should stop before doing that.

In this graph, the earlier line shows the benefit, but now you can multiply that benefit by 10, resulting in something 10 times as high. This line is 10 times higher than the previous one, so you should check more accounts. The optimal number to check is 32.

Okay.

### Slide 71 - Mentimeter

Second test: we can discuss this together, and we'll talk about the answer after the break. This question is about what happens if the cost of verifying an account decreases to 50 euros instead of 100 euros. Does that change the optimal number of accounts to check? Would you now audit fewer accounts, the same number of accounts, or more accounts than before?

You can discuss with your neighbors. We'll talk about it after the break.

Thank you.

All right, so you all had the correct answer to this.

If the cost of verifying accounts decreased to 50 euros instead of 100 euros, you should verify more accounts. It's optimal to audit more accounts. Since you all had this right, you probably also understand the reason for why this is the case.

So the reason is that the cost of verifying one more account is now lower than 100. The benefit of verifying one more account at 21 accounts is 97 euros.

When the cost was 100, you should stop there. But when the cost is now 50 euros, it's optimal to continue checking more accounts because the benefits are higher than the costs.

The optimal audit should be more careful when auditing is cheaper.

In this case, it's optimal to verify 24 bank accounts. The difference is not that big, but the benefit of checking more rapidly decreases to below 50.

If the cost of verifying accounts is half, you should not check double as many accounts. You just check a little bit more. Graphically, before, the cost was this shaded green line at 100. Now it's at 50, half of it, and the point where you should stop is 24 instead of 21. This is where the benefit is going to be below the cost.

### Slide 78 - If Only 1% of Firms Are Fraudulent

Okay, so the third question to verify your understanding of this theory: Assume that instead of 5% of firms being fraudulent, only 1% of firms are fraudulent. How many accounts should you verify? Should you verify fewer accounts, the same number, or more accounts? You can talk to your neighbors and answer, and then I want to know the reason why you think what you think.

You are all right on this, maybe because you saw the answer.

Can anyone explain the intuition for why the optimal audit will check fewer accounts when only 1% of firms are fraudulent?

Yes.

The baseline probability is 1% instead of 5%, and the benefit of checking one more account is going to be less because there is less to improve. Can you argue, though, that since only 1% of firms are harder to find, you would still have to check them?

Very good point. Let me repeat this for the video. Another argument could be that if fraudulent firms are very rare, only 1%, then you should check more accounts to discover those firms.

Let me think about how to respond to that.

The aim is to reduce the likelihood of fraud. If the likelihood of fraud is already very low, then there's no need to discover the very few fraudulent firms. You want to reduce that probability, but if you start with 1%, you don't have to check that many accounts to be sure this is not fraud. If you start with a very high probability, then you need to check more to ensure that this firm is not fraudulent with a high likelihood. The aim is not to find the fraudulent firms, but to reduce the probability that this particular firm is fraudulent.

If you think about deterrence, the probability of punishment for engaging in fraud will be lower because a fraudulent firm will have a lower likelihood of being detected. If you consider the economic model of crime, a bad consequence of this is that we will have less deterrence. In Norway, there are not many fraudulent firms, so audits are going to be quite light, which means it's easier to get away with fraud because it's less likely to be detected.

That issue is probably not that significant since we don't have many frauds. If this were going to lead to a lot of fraud in Norway, then we would have to increase the strength of the audits.

All right.

Very good comment.

### Slide 80 - Mentimeter

The correct answer here is fewer accounts because if you're already at a low probability, checking accounts will give us less benefit. We can reduce the probability of fraud less by checking more accounts. If we start with only 1% of firms being fraudulent, the benefit of checking the first account is to reduce that probability to 0.8%, which is a reduction of 0.2 percentage points. When we started with 5%, the benefit of checking the first account was a one percentage point reduction from 5% to 4%. That's a bigger benefit. So if you start at a low probability, the benefit of checking more accounts will be smaller.

In this case, it's optimal to verify 14 instead of 21 accounts because we already start at a low probability.

In the graph, it will look something like this. The cost of auditing is the same, but the benefit of auditing will be lower because we start with a lower probability to begin with.

### Slide 81 - Correct answer

No. Here is the most tricky question. Assume that firms that are fraudulent have 25% of their accounts fake instead of 20%. How many accounts should we verify? Fewer accounts, the same number, or more accounts? This one is hard, so take some time and discuss with your neighbor.

Okay, so fewer accounts is the correct answer. Does anyone want to try to explain why?

Yes.

### Slide 82 - If Fraudulent Firms Have 25% Fake Accounts

Great. Let me repeat this. If there are more fake accounts, then it's easier to detect the fraudulent firms. The probability of actually finding a fraudulent firm is higher because they will have more fake accounts. If you verify several accounts and don’t find any fake accounts, that provides strong evidence that this firm is not fraudulent. If it were fraudulent, you should have found some fake accounts by that time. If you know that fraudulent firms are extremely fraudulent and have a lot of fake accounts, then you don’t have to check as many to be sure it’s not fraud. That’s the intuition.

Any thoughts or comments on this agreement?

What does this tell us about optimal auditing strategies? In an environment where fraudulent firms are extremely fraudulent, you don’t have to audit as much because it will be easy to find those instances. If you check 10 accounts and don’t find anything, you will be very confident that this firm is not fraudulent. The distribution of fraud between firms matters for the optimal audit, which is not obvious without this model in mind.

Let’s see how it goes. You will start with a 5% probability of fraud. With this new assumption, the decrease in the fraud probability after verifying one account is more than one percentage point. You go down to 3.8% instead of 4% chance of fraud after checking one account. The fact that you didn’t discover fraud in that account, when fraudulent firms have a lot of fake accounts, decreases the probability of this firm being fraudulent by much more than before. You are decreasing this probability more rapidly. In this case, 17 instead of 21 accounts is optimal.

Again, the difference in the number of accounts to check is not that huge, but there is a difference.

So here it is.

The marginal social benefit is very high at the beginning. I think I have another picture here. In the beginning, the benefit is high, but it will rapidly decrease. After you cross this point, which is after checking four accounts, the benefit of checking will be lower than it was when the rate of fraud was 20%.

### Slide 85 - Mentimeter

Assume you find one fake account among the 21 you verified. What should you do? You have three options. You can write an adverse audit opinion saying you were not able to verify the assets of this firm. Or you can tell the firm to remove this $1 million from its declared assets and say you verified everything in the updated statement. Or you should audit more accounts. So talk to your neighbor again.

All right.

Thank you.

OK, any thoughts? There are only two responses yet, so I'm not going to show them. But if you have any, now we have some responses.

Why can't I?

For some reason, I cannot show the responses here.

Okay. I don't know what you answered, but does anyone want to share their thoughts?

Ideally, someone who hasn't responded yet today should speak up to include everyone. It's also good practice to speak in public, and this won't be recorded in the video.

### Slide 86 - Answer

Yes. Okay, excellent. So let me repeat that. The idea is that auditing more accounts has a cost. If we already know it's fraud from verifying this 21, then maybe the right option is to write an adverse audit opinion. In the model I've set up, that is the correct answer. In this simple model, there are honest firms and fraudulent firms. The fraudulent firms have 20% of their accounts fraudulent. If you discover one fraudulent account, you know that the firm is a fraud and that 20% of the accounts are fraudulent or fake. So in that model, there's no reason to audit more accounts. You can write the adverse audit opinion.

In reality, you might care about how much fraud there is. In that case, you may want to audit more accounts. But the answer is never going to be just to remove those one million that you didn't find and say everything else is fine because you only audited 21 accounts. The fact that you found one fake account among them probably indicates that this is a more systematic issue inside the firm. So this is definitely not the right answer. Any more thoughts?

The fact that you didn't find the money in one of the bank accounts doesn't mean that it has to be systematic fraud. Maybe there was just one mistake. So maybe in reality, the right answer is to audit more to figure out how bad this problem really is.
