# Lecture Transcript: 2Crime

## About This Document

This is a transcript of lectures from the course **GRA6296 - Economic Analysis of Topics in Law** at BI Norwegian Business School, taught by Henrik Sigstad.

**Slide deck:** 2crime.pdf
**Lecture date(s):** January 06, 2026, January 13, 2026

This transcript has been cleaned for readability. The original was auto-generated from lecture recordings using OpenAI Whisper.

---

## January 06, 2026

### Slide 2 - Today’s Case: The Wirecard Scandal

This is also intended as an activation exercise, so you learn more if you think actively yourself. These questions are there to activate you and make sure that you're thinking and not just listening to me. So let's start with criminal law. We're going to begin with a case, as we will for all the topics. This is the Wirecard scandal.

It's a big scandal, but you might not know about it. It's one of the biggest recent corporate scandals in Europe.

### Slide 5 - An Innovative Financial Technology Company

Wirecard was a company focusing on digital payments. It was a German company.

They had a lot of very advanced technology for digital payments.

In the words of the CEO, they were a global driver of innovation in the digitalization of payments.

### Slide 6 - Global Presence of Wirecard

They had a lot of advanced technology and were present in many different countries around the world. It was a rapidly expanding German tech company, and Germany was very proud of Wirecard.

It was like their equivalent of Amazon or any Silicon Valley company.

### Slide 7 - Very Profitable

It was an extremely profitable business. The earnings statement of the company showed very high profits and rapid expansion.

### Slide 9 - Wirecard Valued at 24 Billion Euros

Yep.

This is the CEO. Here you see the share price of Wirecard was booming.

### Slide 11 - The Collapse of Wirecard

So it became one of the biggest companies in Germany at this point.

This is a very good story with the only exception that this was all fake. The profits didn't exist.

The auditors eventually were unable to verify these profits. They couldn't locate where these profits were. It was all accounting fraud.

Wirecard collapses. The CEO is arrested. Some other members of the company fled to Belarus.

Importantly, this happened over a decade before it was discovered.

Here you see the share price is tanking at this point.

### Slide 12 - Should We Care?

So this is the Wirecard scandal. First, should we care about this scandal? None of us had any shares in Wirecard, right?

### Slide 13 - A Simple Model

Think about this as a very simple model.

An investor lends 100 whatever to Wirecard. The Wirecard CEO steals the money, and Wirecard files for bankruptcy. The investor loses the money. Maybe that's not exactly what happens, but it's a simplification. Is this good or bad? Should we care about this? To think about these kinds of questions, we need to introduce the first economic concept, which is efficiency. It has a very specific meaning in economics.

### Slide 15 - Key Concepts in This Course

There are two terms: Pareto efficiency and Kaldor-Hicks efficiency. This course will focus mostly on Kaldor-Hicks efficiency, but we will mention Pareto efficiency as well, because it is another important concept.

### Slide 16 - Pareto Improvements

Okay, so first, what is a Pareto improvement? A Pareto improvement is something that makes at least one person better off without making anyone else worse off. Assume you have two individuals, A and B. Here, A has two euros and B has five euros. That is better than A having 1 euro and B having 3 euros because both of them are better off, and none are worse off. So that's a Pareto improvement. Also, 3 to A and 7 to B is better than 3 to A and 5 to B according to this Pareto criterion because B is better off and A is not worse off. Note that there is more inequality here. This is increasing inequality, but we still say it's an improvement. If the richer get richer, but the poor do not get poorer, then it's a Pareto improvement. You might like or not like this concept, but this is the definition. We might care about inequality as well.

The last example, 15 to A and 4 to B, is not a Pareto improvement over 2 to A and 5 to B. Here, A is gaining a lot, 15 versus 2, but B is suffering, getting one euro less. So it's not a Pareto improvement.

Okay, so that's the definition of Pareto improvement.

### Slide 17 - Pareto Efficiency

Pareto efficiency is a situation where it's not possible to have any Pareto improvement. It's not possible to make someone better off without making anyone else worse off. One can argue that...

If it's not Pareto efficient, and it's possible to make someone better off without making someone else worse off, then why not do it? We should probably want society to be Pareto efficient.

### Slide 20 - Answer

Sorry, I don't want to show the correct answers.

Okay, you have five seconds to submit before you see. All right, good. So everyone identified five and four as Pareto efficient.

Almost everyone identified nine and one, and two and eight.

So why is this Pareto efficient? There's no way of making B better off without making A worse off. If we want to increase B to more than two, we have this option, this option, and this option. None of these give better outcomes for A.

They are not Pareto improvements over this.

Here, we can give one more to B, but that gives one less to A. So that's also not a Pareto improvement. There are no ways of making B better off here without making A worse off. Similarly, it's not possible to make A better off without making B worse off. So this is Pareto efficient. This is a very bad outcome because it gives zero to A, which is very bad for A. But it's Pareto efficient because we can't make A better off without making B worse off. Nine is basically the best possible outcome for B. Not all Pareto efficient outcomes are necessarily good because they could involve a lot of inequality. For example, if one person in society has all the money, it's not possible to have a Pareto improvement over that. If you try to give some other members of society some money, you will have to take something from the rich person. We don't want a situation where one gets zero and another gets nine. So Pareto efficiency is not the only goal; we also want to think about distribution. This option is probably the best alternative because it's Pareto efficient and somewhat equally distributed.

This is not Pareto efficient because you can improve A without making B worse off by moving to this option. This one is not Pareto efficient because we can change to this alternative and both of them are better off.

Any questions?

### Slide 21 - Chapter 2.IX.C

At least before we think about inequality.

Okay, so I told you I'm going to activate you. To check whether you understood what I said, try to identify which of these outcomes are Pareto efficient. There could be more than one correct answer, so you should be able to answer multiple questions.

Take time to look at this. I don't know why I included so many options, so it's a bit complicated. But feel free to talk to your neighbor and try to understand this.

Okay, good question. So what to compare it to? For instance, whether 7 to A and 1 to B is Pareto efficient...

You have to compare that to all the other options. If that is Pareto efficient, then there should be no possible Pareto improvements. There’s no way of changing some of the other options to make one better off without making someone worse off.

Okay.

Okay, so we're getting some responses. Can those who are still working finish up? I'll give you 30 seconds to submit what you have, and then we'll see.

### Slide 24 - Kaldor-Hicks Efficiency

Okay, let's have a break and continue with Kaldor-Hicks efficiency after the break.

Now you all know what Pareto efficiency is, including its benefits and limits. You've practiced figuring out which options are Pareto efficient.

Let's now talk about Kaldor-Hicks efficiency, also called potential Pareto improvement in the book. It's a weaker concept than Pareto improvement. If you didn't like Pareto improvement, you might not like this either. It's not as strong, but it's more useful. We'll discuss the limitations of Kaldor-Hicks efficiency quite a bit. So what is a Kaldor-Hicks improvement?

It's a change where there could be some gainers and some losers, but those who gain from the new rule gain more than the losers lose. For instance, 2 to A and 5 to B is a Kaldor-Hicks improvement over 4 to A and 1 to B. Here, B gains four, but A loses two. It's a Kaldor-Hicks improvement because four is higher than two. The gainers gain more than the losers lose. If you look at the sum here, 2 plus 5 is 7, which is higher than 4 plus 1. So in total, society is better off if you sum up the amounts of euros here.

Similarly, 5 to A and 6 to B is a Kaldor-Hicks improvement over 3 to A and 7 to B because A gains 2 and B loses 1. The gainers gain 2, and the losers lose 1. The gainers gain more than the losers lose, making it a Kaldor-Hicks improvement. We can also see that by looking at the total: 5 plus 6 is 11, which is higher than 3 plus 7, which is 10. Kaldor-Hicks improvements allow for losers, while Pareto improvements do not. For a Pareto improvement to happen, no one can be worse off. But here, we allow that as long as those who are worse off are not made worse off than those who gain.

Wait. Hide.

Hide.

Okay, so quick question. If you want, you can talk to your neighbor. Is 2 to A, 5 to B a color Higgs improvement or 3 to A and 3 to B?

Yes. Correct.

It's a color Higgs improvement because B gains 2 and A loses 1. Alternatively, 2 plus 5, which is 7, is higher than 3 plus 3. So it's as simple as that. You just sum up the whole society and see if the total cake is higher; then it's a color Higgs improvement.

If the gainers gain more than the losers lose, then the sum must go up. That's equivalent.

### Slide 25 - Kaldor-Hicks Efficiency

Color Higgs efficiency is a situation where you cannot have a color Higgs improvement. So there's no way of getting a color Higgs improvement. Here, again, a test for you. Same outcomes as before. Which of these are color Higgs efficient?

### Slide 26 - Mentimeter

You can take some time to answer this question and feel free to discuss with your neighbor.

### Slide 27 - Answer

Okay, let me start to show your responses first.

Let me comment on them. So 9-1 and 2-8 are correct. There is no way we can move from 9-1 and let someone gain more than the losers lose. For instance, we might want to improve B to 0, but that's a bad example. Here, 4 to B and 5 to A means B will gain 3, but A will lose 4. So this is not a color Higgs improvement. You can try all the other alternatives. There is no way to increase the sum here. It's easy to check by computing the sum. What is the biggest sum here? It's 10. Which of these give 10? It's only this one and that one. So you are mostly right here. So 5 and 4 was a Pareto-efficient outcome, but it's not color Higgs efficient because you can move to this one, and A gains 5 while B loses 3. The gainers gain more than the losers lose. This is a color Higgs improvement over this one. But of course, we might like this better because it's more equal. Even though it doesn't maximize the total surplus to be shared in society, it is more equal. We might have a preference for equality beyond just color Higgs efficiency. The same issue reappears with color Higgs efficiency; it might not be the only thing we care about. We don't only want to maximize the value created in Norway, but we also want to make sure it's distributed more or less equally among the citizens.

Okay, so those are the only two Kaldor-Hicks efficient outcomes.

### Slide 29 - Cost-Benefit Analysis (CBA)

Now let's define the key tool that we're going to use in this course, which is cost-benefit analysis. It's an implementation of the Kaldor-Hicks idea. It says that we should implement the rule if the benefits are higher than the costs. We count all the benefits and costs in society. It might be a situation where someone loses from the rule and someone gains from it, but if those who gain gain more than those who lose lose, then we should implement it according to cost-benefit analysis.

### Slide 30 - Example

So we can go back here and see, should we implement a rule that gives this outcome? According to cost-benefit analysis, yes, because it will increase the total pie. The one who gains, A, gains more than the loser loses.

### Slide 32 - Inequality

This could be problematic in some cases because it doesn't take into account inequality.

So why are we... let me see what I have here.

Yeah, it's coming later.

Okay, here's another similar example. Assume that initially A has one euro and B has six euros. A new legal rule would lead to A having three euros and B having five euros if the rule is implemented. Yes, because A gains two and B loses one.

Alternatively, we can see that the sum here, three plus five, is higher than one plus six. So the total value in society increases.

If we have a Kaldor-Hicks improvement, we could, in theory, generate a Pareto improvement by forcing the one who gains to compensate the one who loses. Here, A gains two and B loses one. A could compensate B by giving one of the gains to B, and then A would be better off without making B worse off. This is why it's also called a potential Pareto improvement, because potentially there could be a Pareto improvement if we allow these kinds of compensations to happen. If you don't like a change, a new rule could increase the value created in Norway, but it might be very bad for oil workers. Maybe we can find a way to compensate them.

In theory, one could think of such compensation, but cost-benefit analysis doesn't require that compensation to happen. We could compensate, but we don't require it. Why not? Principally because it would be impractical to do these kinds of compensation for each new rule we implement. Every time we pass a new law, there will be some losers and winners, and we would need to define a way to compensate the losers for each new law. It would be extremely complicated to pass new laws, which is why cost-benefit analysis doesn't require these kinds of compensation schemes. Another reason is that we pass a lot of laws and change many rules. Sometimes there are losers, but for another change, they might be the winners, so it may average out over time. The third reason is that we do have a general way of compensating losers in society, like specific welfare benefits.

Free healthcare and free education are examples of things we have in society to ensure that no one is extremely bad off. That's the third justification for using cost-benefit analysis. There might be losers, but if someone is very bad off in the end, they have a social safety net.

A rule could generate more value in society. There might be some losers, but they could be compensated by the welfare system. However, cost-benefit analysis is problematic when applied to specific welfare measures. For example, consider applying cost-benefit analysis to healthcare. In Norway, healthcare is public. Imagine a patient waiting for a liver transplant. There is a rich person and a poor person in line. The rich person is willing to pay more for the liver because they have more money. The value of the liver, in monetary terms, is much higher for the rich person than for the poor person. According to cost-benefit analysis, we should give the liver to the rich person. Why is that problematic? It exacerbates inequalities in society by giving the liver to someone who already has a lot.

Healthcare spending is part of the general social safety net in society. We can no longer say we are using cost-benefit analysis while undermining that very safety net. When we apply cost-benefit analysis to healthcare, education, and taxes, it becomes very problematic. In my view, applying it to how to design good contracts, tort law, and efficient legal processes is not controversial. Cost-benefit analysis is useful for many questions about designing good rules, but it is not useful for designing a welfare system, like a social safety net, where the aim is not to create value but to redistribute. Any questions or comments on that? This is an important message so you don’t apply cost-benefit analysis in settings where it might lead to wrong conclusions.

In the settings we will discuss in this course, cost-benefit analysis is, in my view, an uncontroversial tool. When we think about contract law, tort law, and the legal process, it makes sense to think that these are in place to maximize the value created in society. They are not there to redistribute from the rich to the poor. We have other systems in place for that. Some people might disagree and say that contract law should protect the poor, for instance. That is a valid view, but the book and I, unless you convince me otherwise, think that contract law is not the place for redistribution.

There may be exceptions, such as when vulnerable workers have very bad contract terms. In those cases, we should consider redistribution to protect vulnerable workers from abusive contracts. However, think about a contract between a small firm and a large firm. We shouldn’t design this contract to benefit the small firm over the large firm unless there is a societal problem. There are many issues related to economic efficiency, such as large firms dominating markets, which can cause inefficiencies. We might want to tackle monopolies, for instance.

Cost-benefit analysis would suggest that we should break down monopolies because they destroy value by harming competition, but not because we care about redistribution.

You could argue that part of competition law is to redistribute profits from companies to consumers. So, it’s not entirely uncontroversial in all settings, even in business contexts. I take back some of what I said. It depends on the setting where cost-benefit analysis is uncontroversial and where we need to consider inequality and redistribution. On the exam, you should conduct a cost-benefit analysis, but if there are important considerations about inequality or redistribution, those should be mentioned.

Any questions?

The exam questions will be written in English. If you can answer in Norwegian, I need to think about that. I’ll note it down. Maybe part of the reason this is in English is to encourage you to practice English. But if that’s not a goal we should consider, then Norwegian is fine.

Unfortunately, I can't read French.

### Slide 34 - The Collapse of Wirecard

Okay, other questions?

Okay, so this was a long detour from the case, but we needed these concepts to think about the Wirecard case.

### Slide 36 - Cost-Benefit Analysis of the Fraud

To remind you, this is what happened. Investors were investing a lot of money in this company, and then it crashed, and all the investors lost their money. Assume that this investor had invested 100 in Wirecard and this money was lost. Just assume that the CEO stole the money for now.

Let's apply a very simple cost-benefit analysis to this fraud. There was a cost to the investor, which was 100, but in a cost-benefit analysis, we need to take into account all the costs and benefits in society. For the CEO who stole the 100, the benefit is 100.

### Slide 40 - Cost-Benefit Analysis of the Fraud

The conclusion of this very simple cost-benefit analysis is that this fraud basically had no cost to society. It was just a redistribution from the investors to the CEO. So minus 100 here, plus 100 here. In terms of Kaldor-Hicks efficiency, nothing happened. We shouldn't care about this fraud. Of course, investors are angry, but in terms of creating value in society, it doesn't really matter. So is that really the case?

Let me see what I have next here.

First, you can quickly answer this by yourself, and then I'm going to put you in groups to discuss the substantive things here. Do you agree with this cost-benefit analysis that fraud doesn't have a cost?

No. It doesn't feel right that it shouldn't have a cost. In the end, it's a criminal offense. There's probably a good reason why it's a criminal offense, right? Now, don't answer here. I think it's better if we can do it together. I want you to sit together in groups of two to four and discuss this. Why do you disagree with my analysis? What kinds of costs did I forget? What was wrong with my analysis? I want you to sit together in groups and actually discuss this. It's a way of activating you.

Once you've done that, we will do it together.

Thank you.

Okay, should we do the discussion together? Anyone who wants to say something about the costs of fraud that I didn't take into account or what was wrong with my analysis can speak up. You can answer in Norwegian, but we have two international students here, so if you do answer in Norwegian, I'll translate for them. I don't want language to be a barrier to responding, but of course, if you can respond in English, that's even better.

Yes? If there is fraud, there will be legal costs and fees to attorneys. Excellent. Those are two points. Let me talk about the first point first. This is true: all the calls to lawyers and lawsuits do not create value for society. They are basically a waste of money. Of course, lawyers are there for a reason, but if we can avoid discussions like going to court, that is a big cost saver. However, if that were the only cost of fraud, we could just say that fraud is not illegal anymore. If it's not illegal, you can't sue, and then we wouldn't have those costs. But then the second point you mentioned becomes important. There are actually other costs of fraud. If fraud is expected to happen, people would not invest in companies.

The damage of the Wirecard scandal is not just the money lost for investors, but also the reduced trust in the German legal system, auditors, and their ability to detect and punish fraud. If these kinds of fraud happen a lot in Germany, investors would no longer be confident in investing their money in German companies.

I think that is the key cost here.

That's the first consequence, but it leads to real consequences. A really good idea can't attract investors if they worry about fraud. So, the existence of fraud could make it hard to attract capital to very good ideas. This has potentially enormous consequences for the value created in society. The social cost of fraud is not just that investors lost money, but that it could lead to inefficient allocation of capital in the future.

When we do the cost-benefit analysis, we can list this cost to an investor. To be coherent with the cost-benefit analysis framework, we should also take into account the benefit for whoever stole that money.

Those two might cancel out, and the real cost is this.

Now we see that a cost-benefit analysis is not that easy. It's not obvious what should count as which costs. We might forget to count some costs. Applying this cost-benefit framework in practice is not easy. This course will train you to apply this framework and identify the real costs and benefits of something, in this case, fraud. In another case, it could be a legal rule, a clause in a contract, or something like that.

Measuring that cost is a bit hard. You won't be required on the exam to put a number on this, but you should be able to identify the factors that determine this cost.

### Slide 42 - An Economic Theory of Crime and

Okay. Let's discuss the next question. Now that we have agreed that fraud is not good for society, we should think about how to prevent it. This is where criminal law and maybe other things come in. Let's keep the conversation going by raising hands. Talk a little bit in your group about what we can do to prevent fraud. There is more than one answer here, so try to come up with a list, and then we'll talk together.

All right, should we do it together? You probably have mentioned some things already, and maybe more come to mind. Let's start with someone from this part of the room to put some pressure on you guys.

Punishment?

Great. OK, punishment.

This could be a criminal punishment, for instance, a fine or imprisonment. Do you have more things to add?

Detection? Excellent.

### Slide 94 - Mentimeter

It doesn't make sense if the frauds are never discovered; punishment won't help. You need to ensure they are detected. This fraud went on for a decade without being detected. Eventually, it was discovered, but there could be cases where it's never detected. Investors lost their money and thought the company made bad investment decisions. They didn't realize the money was stolen. Great. Any more ideas?

In general, a good legal system secures the interests of both parties. In this case, the CEO and the investors have a legal framework.

You think about the possibility of suing or things like that? That could be one option, but there are also accounting rules for public companies.

Maybe it's part of detection, like the accounting rules. If you have to provide accounts, it will be a bit easier to detect fraud. We'll see exactly how it was detected in the Wirecard case. They did provide accounts, but the accounts were fake. Requiring very specific accounting could make it easier to figure out when it's fake, which is part of the detection problem. More ideas? Thanks.

So in terms of punishment, there could be many different kinds of punishment. It could be criminal punishment.

It could be damages, or it could be the investors suing the CEO to get damages in Norwegian, ashtotning. It could also be some kind of non-legal punishment like reputational punishment or social norms. This punishment can take many forms. It's not only criminal punishment that makes managers avoid fraud; reputational concerns also play a role. If they engage in fraud, who will want to hire them as a CEO in the future? No one. They will destroy their reputation by engaging in fraud. The possibility of being sued by investors is also important. Of course, they typically buy insurance against that, but still...

The insurance company might require a high premium if they think you're about to engage in actual fraud. They may not cover actual fraud, as opposed to just bad decisions. All right. So I'll preview what we're going to talk about next. We're going to provide an economic theory of crime and punishment. It will have basically these ingredients: punishment and detection. It's going to be quite simple, but I think it's quite useful, and it will generate some predictions that are not obvious in the end.

### Slide 96 - Next Lecture

In terms of the problem set, I advise you to wait until after next lecture to start with the first assignment because you will need this theory for that assignment. Of course, you can have a look, but you won't be able to answer it yet. So wait until after next lecture to try the problem set. Any questions before we close?

Okay, great. See you next week.

## January 13, 2026

### Slide 11 - The Collapse of Wirecard

Welcome back. Today, we will finish the first part on criminal law. We'll continue with the Wirecard case as motivation, and I'll deliver the theory from the book and apply it to this case. We'll do it together. To remind you what we did last time, we first talked about why corporate fraud is bad. We used a naive cost-benefit analysis. An investor lends money to Wirecard, and the CEO steals it. If we just count what the investor loses and what the CEO gains, there's no loss in society because someone gains and someone loses. According to cost-benefit analysis, we shouldn't care. However, we argued that there are real costs we didn't consider, which are the costs to capital.

### Slide 40 - Cost-Benefit Analysis of the Fraud

If these kinds of frauds are common, it will be hard for startups to attract capital because investors can't trust these companies anymore. This means we might get less capital for the best firms. That is the real social cost of the fraud. The 100 who are lost is not the cost of the fraud in a social sense. This example shows that cost-benefit analysis is not that easy. You have to think about all the costs and benefits and also count the benefit for the CEO, which is not obvious. To apply cost-benefit analysis properly, we need to count the benefit here.

### Slide 42 - An Economic Theory of Crime and

Let me discuss that. Then we started to talk about how we can prevent fraud because we don't like it. We need to think about how to prevent it efficiently. We discussed things like punishment and the probability of detection. That's exactly the theory we're going to talk about now, which is the economic theory of crime and punishment. It's the chapter in the book.

### Slide 44 - A Simple Model of Crime

This model is very simple. Don't be scared about the x and y here. We can do this without using letters, but we can insert numbers as well. In the exam, you can always use numbers instead of letters if you're not comfortable with representing things this abstractly. In this model, the CEO can decide how much to steal from the company. There is some punishment, which may increase with the amount the CEO steals. It could be a function of X, the amount stolen. There is also some payoff to the CEO. For instance, if the CEO steals one million, the payoff could be one million, but it could also be less because it might not be easy to use the money. We'll talk more about that.

### Slide 47 - A Simple Model of Crime

Now, let me introduce the probability of detection. There might be a fine, but there is also a chance that you don't get the fine because the fraud is not detected. In the Wirecard case, it was eventually detected, but many frauds are never detected. So there's a chance that you can get away without punishment. We'll make a simple assumption that the criminal chooses how much to steal to maximize the expected profits from the crime. Y here is whatever the criminal can keep minus the probability of detection times the fine. It's a simple model that assumes the criminal is risk neutral. They evaluate this punishment as just a multiplication of the probability of detection and the fine. They do not care about risks. In reality, people are risk-averse. They don't want a high risk of paying a large penalty. This riskiness would deter most people from committing crimes, in addition to just the probability times the fine. We will mostly assume in this course that people are risk neutral because it simplifies things. However, on the exam, it's good to discuss how things might change if people are risk-averse. If a criminal is risk-averse, they would abstain from the crime, even if the benefit is higher than zero, as long as the benefit is not very high compared to the expected cost.

### Slide 48 - Example

We will also introduce the probability of detection here eventually.

In our example, one million is how much the CEO embezzles. Assume that the fine is 10 times this, so the fine is 10 million. For now, assume that the CEO can pay it. Assume that Y is whatever is stolen, so the CEO can make use of all the stolen money.

I'm going to briefly discuss this picture from the book so you understand it. The seriousness of the crime is the amount stolen, and the payoff increases with the amount stolen. The punishment also increases, and here you see that the punishment is always higher than the payoff, so it's not worth it to steal.

### Slide 50 - Yes

There's a majority of yes, and that's the correct answer. I don't have the correct answer here, but yes is the correct answer. Why? Because 5% times 10 million is 500,000.

That's the expected fine. Even though it's a very large fine, 10 million, the probability is only 5%. When you multiply that amount by 5%, you get 500,000, which is less than the 1 million here.

Okay, so this is just what I said. Sorry, it's not 100,000; it's 500,000, but still.

So 5% times 10 million is 500,000. You have 1 million in gain minus 500,000 in expected punishment. So you expect to gain 500,000 from this.

### Slide 51 - Risk Aversion

I'm not going to introduce any math to talk about risk aversion, but you should discuss it. How would things change? In which direction would things change if people are risk-averse? You don't have to do it, but it could improve your answer on the exam if you discuss that.

I'm not going to introduce any math to talk about risk aversion, but you should discuss it in that way. How would things change? In which direction would things change if people are risk averse? You don't have to do it, but it could improve your answer on the exam if you discuss that.

Okay, so assume in our example that the probability of getting caught is 5%. Let me hide this. Go to mentimeter, menti.com, and use this code to answer on your own. Do you think that the executive is going to embezzle the 1 million or not, assuming that the CEO behaves as in this theory?

I'm going to wait for a couple more responses.

Oh, so there's not much agreement here.

In expectation, the CEO will gain from embezzling this 1 million because the expected gain is 1 million and the punishment is 500,000 in expectation. This is, of course, assuming the CEO is risk neutral. If the CEO is risk averse, the answer could be no. If the CEO is sufficiently risk averse, they may not want to take on the risk of paying this very large fine.

Okay, so here's the slide about risk aversion. I already said that.

### Slide 52 - The Optimal Amount of Embezzlement

So what would be the optimal amount to embezzle, given that the probability of being detected and the fine can vary with how much you steal? It depends on how that varies, but maybe for some low amount, if you steal it, the probability of detection times the fine is so small that it's worth it. But if you steal a lot, it's going to be detected with a very high likelihood. So the expected punishment is higher than the payoff. There could be some point here, the optimal amount to embezzle, which here is 10,000, and it maximizes the difference between the payoff and the expected punishment.

### Slide 53 - Summary

Okay, so this theory has very simple, natural, and intuitive predictions. The prediction is that we're going to see more crime if the probability of detection is low, the punishment is low, and the profits from crime are high. I think these are quite uncontroversial predictions.

Of course, it assumes that if you think criminals are not rational, maybe you don't think they react to these kinds of incentives. But most people would agree that criminals are at least somewhat rational and respond to these incentives.

### Slide 55 - One Answer: Make It Hard To Use The €1 Million

Okay, so when we're thinking about fighting crime, we can do it in three ways. We can increase the probability of detection, increase the punishment, or decrease the profits from crime. These are three different ways of fighting crime, and we're going to discuss what is the best way. But first, talk a little bit to your neighbor and try to think of ways to reduce the profits from crime. It's not obvious how to do it. So briefly talk to your neighbor, and then I want to see some hands with suggestions on how to fight crime this way.

Thank you.

Thank you.

Okay, so can we take this together? Any ideas? Yes.

### Slide 56 - What Is The Optimal Way To Prevent

Great. Okay, so minimizing the incentives for embezzlement. I'm going to translate to English for the non-Norwegians, but it's fine to answer in Norwegian, and then I'll translate. Increasing the punishment is another way of fighting crime.

Decreasing the incentives for embezzlement is what we have in mind here, but how can we do that? So, that's a correct answer, but we need some specific ways to actually reduce that profit.

Yes?

Yes, but that is increasing the punishment. Decreasing the profits is about finding ways to lower the profits. Even if the probability of the fine is zero, you can still think of ways to decrease the profits. In terms of the model, what I have in mind is the "why" here. Maybe you steal one million, but you cannot enjoy all of it for some reason. This could happen even if it's not detected. There could be reasons why stealing one million doesn't give you the same satisfaction as actually earning one million through other means.

Anyone else want to have an idea? Yes?

Okay, control systems. So that is like detection, right? Or do you have something different in mind? So it's detection, basically. Okay, anyone, last chance?

It's going to be obvious when you hear me say it, but we often think about two ways of fighting crime. However, there's another way we don't consider, but we actually do in practice. This includes making money laundering difficult. For example, if you embezzle one million, it's very hard to spend that money if you have it in cash. You need a way to make it look like this gain is not illegal. It interacts a bit with the probability of detection because if you...

...spend a lot of cash, the likelihood of detection is high. But there's another reason: money launderers have to spend a lot of money, meaning the actual benefit of having this one million you stole is not the same as having one million gained legally.

Here's one rule. I'm not sure if this was actually implemented, but I think in Malaysia, it was going to be a crime to live beyond your means. If you cannot prove where your money comes from while spending a lot, then it's a crime. This makes it very hard to spend the money you stole, so whatever benefit you get from the stolen one million is much lower because it's hard to spend it.

This is a different way of fighting crime than just increasing punishment or the probability of detection. Of course, these things could interact. This kind of law could also make it easier to detect crimes because if you cannot justify how you gained the money, law enforcement may investigate what you did. Any comments? Yeah.

For instance, cash is typically very hard to use due to anti-money laundering rules. Limiting the possibility of using cash is one way to make it harder to spend.

Yep, excellent. To translate, rules that make it harder to spend cash will increase this Y here.

There are limits, like in Norway, where there are limits on how much you can spend in cash for large purchases.

More comments or questions?

### Slide 60 - The Aim of Criminal Law (According to CBA)

Okay, so now let's go back to the punishment versus the probability of detection. We're going to keep this third way of fighting crime in mind, but now let's think about whether we want to fight crime by increasing the probability of detection or increasing the punishment. It's not obvious which one is the most efficient way of fighting crime.

Okay, so let's...

The way we're going to think about what is the best way is to use cost-benefit analysis.

We introduced that idea last time. We talked about some drawbacks, but in many settings, I argue that we can use it. In some settings, it's controversial. I'll let it be up to you to decide if you think this is a controversial way of using cost-benefit analysis, but we're going to apply that to criminal justice. For instance, assume that if the police wear body cameras, it will decrease the harm from crime by five euros but increase the cost of policing by seven euros. Should we require them? Well, no, because the cost is higher than the benefit. This is a simple example of cost-benefit analysis. Of course, there could be many more costs and benefits that we didn't count, but this is just a simple way to think about it. There are differences in who pays the cost and who gains, so there are distributional consequences. But in cost-benefit analysis, we just see if it increases the total value in society.

According to cost-benefit analysis, the aim of criminal law should be to minimize the social cost of crime, which is the sum of the harm that crime causes and the cost of preventing it. We have to think not only about the cost of the crime but also the cost of fighting it.

We should use a particular way of fighting crime if it decreases the social cost.

### Slide 62 - Optimal Level of Deterrence

We can ask questions such as how much crime we should deter. You might think we want to get rid of all crime in society, but that might not be the case because it could be extremely costly to eliminate all crimes. Some crimes may not be very harmful to society, but it could be very costly to fight them. So maybe we should let those crimes happen and just give up.

I'm going to explain this graph from the book to keep in line with it. Here is the reduction in crime. This is 100% reduction in crime, and this is zero crime. There are two lines here: the marginal social benefit and the marginal social cost. According to the book, in the beginning, when you try to fight crime, you want to start with the most harmful crimes that are cheaper to fight. Initially, you start with fighting very harmful crimes that are cheap to fight, and the value of fighting those crimes is very high because the benefit of getting rid of them is much higher than the cost. But as you try to fight more crime, you may end up in a situation where it becomes extremely costly to fight additional crimes. Those remaining crimes are very costly to fight because you need a lot of police presence, which is expensive. Some of these crimes may not be very costly for society, so we should let them happen. There might be an optimal level of crime in society.

You don't have to completely understand this picture. You don't have to draw a graph like this on the exam, but I want you to be able to understand the book.

Okay, so let's have...

### Slide 63 - Mentimeter

Discuss together with your neighbors what the costs of deterring crime are. There will be a list, and it will include more than one item. I will allow you to answer on Mentimeter for this question, so you can add anything that's not on the list. Talk in your group, and whenever you have something to add, please put it on Mentimeter.

Let me know if you can't answer on Mentimeter. If you can add whatever costs you're thinking about on Mentimeter, that would be good.

Great. This is already a nice list.

### Slide 65 - Costs and Benefits

The cost depends on how we fight crime. For example, imprisonment is extremely costly. Policing is also a big cost. If we put people in prison without taking them to court, we can save on lawyer and court costs, but we don't do that for good reasons.

This is a good list. We have to keep in mind all these costs. The benefits of deterring crime depend on what the crime is. For instance, fighting corporate fraud leads to better capital allocation.

I'm not going to talk about the benefits of fighting theft because that's likely the first assignment. However, we can think about the benefits of fighting different crimes. For example, the benefit of fighting drug trafficking might be less consumption of drugs.

When we think about the costs and benefits of deterring crime, we should consider all of these real costs and the benefits, which could include reduced crime or more trust in society.

### Slide 66 - The Cost of Crime

Okay. So I think we already talked about this example. The executive embezzled 1 million. What is the cost of this crime? Let me check if you remember what I said earlier. Try to answer this question before we move on. You can talk to your neighbor while you answer.

All right. Let me comment on this. There's a majority now for more than 1 million, but this is a herding behavior. Once you saw that there was a majority, maybe this one got a lot of responses.

### Slide 68 - Cost-Benefit Analysis

I would say that's likely the correct answer. But in general, I think it's not possible to tell in this case because the social cost of this fraud is going to be a less efficient allocation of capital in the future. The executive embezzles $1 million. That's a benefit for the executive and a cost for investors. Those two cancel out, or maybe they don't completely cancel out because the executive cannot use that money efficiently since it's hard to spend stolen money. The point is that it's not going to be one million because we have to count the benefit for this executive. The real cost is the less efficient allocation of capital because now investors will trust capital markets less. Most likely, that cost is way larger than one million. But in general, it might not be possible to tell. It might be smaller.

Just a small note: the book prefers not to take a stance on whether the executive's benefit should be counted. I think it should, but the book thinks it's controversial to say we should count the benefit of the thief in the cost-benefit analysis. I think we should. That's the only way to apply cost-benefit analysis in a principled way. It says we should take into account the costs and benefits across society, and thieves are also members of society, so we should care about their well-being too.

We don't want them to steal, but we should care about their well-being. It's not like they don't matter in society. We don't want them to benefit a lot from crime because we want them to stop committing crimes. But it's not that we don't care about them. So I disagree a little bit with the book here.

### Slide 70 - Not Optimal To Deter All Crime

This one we already talked about. It's not going to be optimal to deter all crime. For instance, if some frauds are extremely hard to uncover and they do not cause that much social loss, it might be better to just not try to prevent them.

Think about insider trading. Maybe it's extremely hard to figure out insider trading, and the cost to society is not that high because insiders have a lot of information to trade on. You could argue that we should not make insider trading illegal, even though it causes some loss to society. It's very hard to fight insider trading, so we might just give up, for instance.

### Slide 71 - Mentimeter

To test your understanding again: according to this economic theory of crime that I've been discussing, which factor should lead us to be less willing to prevent a particular crime? Which of these crimes should we be more willing to accept and just let happen, not fight it? For instance, if it's hard for a criminal to spend the stolen money, does that mean we should let this crime happen? You can discuss with your neighbor before you answer.

There could be more than one answer here.

Thank you.

Okay, so let me comment on this.

Crime is hard to prove in court, that's correct. If it's very hard to prove it in court, we should probably give up trying to fight it. Criminals gain a lot from the crime. We should be more inclined to let those crimes happen for two reasons. First, if they gain a lot, it might be hard to fight. Second, if they gain a lot, it's good for them. We care about them.

Of course, if they gain a lot, maybe the cost for society is high as well. But if the cost for society is the same, and criminals gain a lot, those are better crimes than those where the criminal doesn't gain that much. For example, insider trading. Insider traders gain a lot from this. Good for them. That's a reason why we could let it happen. Of course, if the cost for other investors is very high as well, then that's a different factor.

If the crime is victimless, that means there are no victims, and no one is paying any cost. That should be legal. But people may have different interpretations of this. For instance, way back, gay sex was illegal. There weren't really any victims of that crime. No reason to have that as a crime. You could also argue that selling drugs has no victims because people who pay for these drugs want them. So who are the real victims? Of course, you could argue that people are not rational when they buy drugs.

It's hard for a criminal to spend the stolen money. If it's very hard for a criminal to spend the stolen money, that means...

it's going to be easier to fight it because they don't benefit that much from the crime. So the cost of fighting it is low, and the benefit of this crime is also lower for the criminal.

Okay, very good point. If this is already sufficient for this crime not to happen, we don't have to fight it. Maybe this is enough so it's already not happening, then we don't need to fight it. So it's a valid point, yeah.
