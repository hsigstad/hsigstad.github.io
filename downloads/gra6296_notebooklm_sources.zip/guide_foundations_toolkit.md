# Foundations Toolkit (GRA)

This file contains the canonical analytical toolkit used in the GRA course.

---

## Purpose and Scope

The Foundations Toolkit defines the authoritative models, notation, terminology, and assumptions used across all application chapters. Application chapters must comply with this toolkit and may not introduce new models or notation not defined here.

The toolkit is deliberately minimal and reusable. It provides a small set of analytical frameworks that apply across different areas of law by changing what counts as an action, a sanction, or an enforcement mechanism.

---

## Core Analytical Frameworks

### The Economic Theory of Crime

**Purpose:** Analyze how legal rules affect criminal behavior through incentives and expected sanctions.

**Key insight:** Behavior is shaped not only by the size of sanctions, but also by the likelihood that sanctions are imposed.

**Model structure:**
- Private gain: *y* (payoff from the criminal act)
- Fine: *f* (sanction imposed if caught)
- Probability: *p* (detection and conviction)

**Decision rule:**
The criminal commits the act if the private gain exceeds the expected sanction:

> y > pf

**How to apply:**
1. Identify the action
2. Identify the private gain
3. Identify the sanction
4. Identify the probability of sanction
5. Analyze how legal rules change incentives

---

### Economic Theory of Tort Law

**Purpose:** Analyze how liability rules affect precaution and accident prevention.

**Key insight:** Optimal precaution balances the cost of taking care against the expected reduction in accident costs.

**Model structure:**
- Precaution: *x* (level of care taken by the potential injurer)
- Cost per unit of precaution: *w*
- Harm from an accident: *A*
- Probability of accident: *p(x)* (decreasing in *x*)

**Expected social cost:**

> E(SC) = wx + p(x)A

The first term is the cost of precaution. The second term is the expected harm from accidents.

**Optimal precaution:**
The socially optimal level of precaution *x** minimizes expected social cost. At the optimum, the marginal cost of additional precaution equals the marginal reduction in expected harm.

**Liability rules:**

*Strict liability:* The injurer pays damages *D = A* whenever an accident occurs, regardless of precaution level.
- Injurer's cost: wx + p(x)D = wx + p(x)A
- Since this equals the social cost, the injurer chooses optimal precaution *x**
- Problem: The victim has no incentive for precaution (fully compensated)

*Negligence:* The injurer pays damages only if precaution is below the legal standard of due care.
- If the legal standard equals *x**, the injurer will choose exactly *x** to avoid liability
- The victim bears accident costs when the injurer is not negligent, giving the victim incentives for precaution
- Both parties have efficient incentives if the legal standard equals the efficient level

**When to use each rule:**
- Strict liability: When only the injurer can take precaution, or when determining negligence is costly
- Negligence: When both parties can take precaution (bilateral care situations)

---

### Cost–Benefit Analysis

**Purpose:** Provide a framework for evaluating legal rules and institutional designs.

**Core concepts:**
- **Economic surplus:** sum of benefits minus costs across all parties
- **Efficiency:** a rule is efficient if no alternative generates higher surplus
- **Externalities:** costs or benefits not reflected in private payoffs
- **Internalization:** aligning private incentives with social costs by making actors bear externalities

**Cost–benefit analysis:**
- Compare expected benefits to expected costs
- Account for behavioral responses
- Include enforcement costs
- Balance marginal deterrence benefits against marginal enforcement costs

**Scope and limits:**
- Appropriate for business-relevant legal settings (contracts, criminal law)
- Less appropriate where law serves redistributive or rights-based functions
- Distribution is better handled through taxation and transfers in most private law contexts

---

### Transaction Costs

**Purpose:** Explain when and why legal intervention matters.

**Core concept:**
Transaction costs are the costs of identifying trading partners, negotiating agreements, monitoring performance, and enforcing obligations.

**Coasean benchmark:**
If transaction costs were zero, parties would bargain to efficient outcomes regardless of initial rights allocation. In practice, transaction costs often prevent efficient bargaining, and legal rules shape outcomes.

**Role of law:**
- Provide clear default rules
- Lower enforcement costs
- Reduce information problems
- Facilitate coordination

---

### Information, Evidence, and Verifiability

**Purpose:** Analyze how information problems shape legal rules and institutions.

**Key distinctions:**
- Symmetric vs. asymmetric information
- Observable vs. verifiable information
- Adverse selection (hidden characteristics before transaction)
- Moral hazard (hidden actions after transaction)

**Responses to information problems:**
- **Disclosure:** mandatory revelation
- **Screening:** designing choices to induce revelation
- **Signaling:** costly actions to convey information

**Legal implications:**
- Contract design: reliance on objective, documentable events
- Litigation: burden of proof, evidentiary standards
- Enforcement: expected sanctions depend on probability of detection

---

### Self-Enforcement

**Purpose:** Explain when formal legal enforcement can be replaced or complemented by private mechanisms through reputation and repeated interaction.

**Conditions for self-enforcement:**
1. Information about past behavior must be available
2. Future interaction must be valuable enough to discipline current behavior

**Mechanisms:**
- Reputation
- Repeated interaction
- Relational contracts

**When self-enforcement fails:**
- One-shot transactions
- Information is difficult to verify
- Parties can exit easily after cheating
- Gains from opportunism are large

**Role of law:**
Legal institutions support private ordering by improving information, increasing costs of opportunism, and stabilizing expectations. Law complements rather than replaces reputational incentives.

---

## How the Toolkit Is Used

### Across Legal Domains

The same frameworks apply to different areas of law by changing what counts as:
- The relevant action
- The private payoff
- The sanction
- The enforcement mechanism

### In Application Chapters

Application chapters must:
- Use models and notation defined in this toolkit
- Not introduce new theories or notation
- Explicitly reference foundations concepts when applying them

### In Problem Sets and Exams

Students are expected to:
- Apply toolkit models to new situations
- Use notation consistently
- State assumptions clearly
- Show how legal rules affect incentives using the economic theory of crime or other frameworks

---

## Status

This toolkit is authoritative for all application chapters, problem sets, and exams. Changes to the toolkit should be rare and carefully considered, as they affect the entire course structure.
