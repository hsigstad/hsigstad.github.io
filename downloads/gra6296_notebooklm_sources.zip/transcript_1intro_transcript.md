# Lecture Transcript: 1Intro

## About This Document

This is a transcript of lectures from the course **GRA6296 - Economic Analysis of Topics in Law** at BI Norwegian Business School, taught by Henrik Sigstad.

**Slide deck:** 1intro.pdf
**Lecture date(s):** January 06, 2026

This transcript has been cleaned for readability. The original was auto-generated from lecture recordings using OpenAI Whisper.

---

## Slide 1 - The Economic Analysis of Topics in Law

Welcome to the economic analysis of topics in law. You are master's students in the law and business program, and there are also some international exchange students in the course. Anyone outside of those categories? No.

## Slide 3 - Economics (Samfunnsøkonomi)

Economics, or samfunnsøkonomi in Norwegian, is about how agents respond to incentives. Law and economics uses economic theory to understand how people respond to the law and how laws influence behavior in society. We want to design legal rules that produce desired outcomes. We think of law as something that changes behavior, either positively or negatively. Understanding how it changes behavior and creates economic value is important. While not many of you will design laws yourselves, you might find yourself in situations where you're designing a contract, which is like designing a rule. Deciding on clauses in a contract is useful to think about how those clauses will influence behavior and how to maximize the value a contract creates.

## Slide 4 - Law and Economics / The Economic Analysis of Law

This course uses economic theory to analyze law. I'm Henrik, an economist who studies law from an economist's perspective. I will teach you about economic analysis and ensure that everything I say about the law is correct. If you have very specific doubts about the law, I may not be the right person to clarify those. But feel free to ask questions, and I can help.

As you see, I'm going to record the lectures.

People usually don't record lectures for two reasons. First, they think students won't raise their hands and be active. There's no need to worry about that because I have the microphone here, and anything you say will not be in the recording. The second reason is that they worry students won't show up. I believe the reason for low attendance today is not the recording. As long as people have a good excuse for not coming to class, I will continue recording. If I see attendance going down, I might stop recording to encourage people to come to class. Being in the classroom is important for your learning, and if you think you can just watch the video later, you might postpone it. We will have a lot of interaction in the classroom that will be useful.

The economic analysis of law and law and economics are synonymous. Economic analysis of law is a more fitting term than law and economics. Law and economics sounds like there is a little bit of law and a little bit of economics, but it really means using economic theory to analyze law.

## Slide 5 - A New Way To Think

Law and economics, or economic analysis of law, is a new way of thinking about law. In typical law courses, you might learn what the law is and how to interpret it, but not why it's there or how it influences behavior. This approach helps explain why certain rules are good or bad.

Law and economics can also guide us on how to ideally interpret the law. If the law is unclear, we can discuss how to interpret it in a way that maximizes welfare in society.

## Slide 6 - Some Cases We Will Cover

The course will be case-based. We will always start with a case and then introduce the theories.

Some cases we will cover include how a firm can efficiently prevent employees from engaging in misconduct. For example, Danske Bank had issues with compliance regarding money laundering rules. We will explore how to ensure that employees in an organization comply with the law. I aim to make these cases as business-relevant as possible, focusing on how to design a compliance regime inside a business, which is similar to designing a law.

Another case is about when auditors should be held liable for fraud. If there's fraud in a company that an auditor has audited, when should that auditor be liable? According to economic theory, there is one answer, but according to the law, there is another. One can argue that we should interpret the law so that these two definitions coincide.

Typically, auditors are liable if they are negligent and did not perform a good enough audit. However, what constitutes a good enough audit is not clearly defined; it's very vague. We can use economic theory to understand which factors determine what is a good or a bad audit.

Another case is about when you can trust your business partners.

## Slide 7 - How To Design A Contract?

We're going to talk a lot about how to design contracts because that's where the law and economics perspective is most useful for you. For instance, we will discuss how to penalize delays in construction projects. What should be the optimal penalty for delays? Who should bear the risk for certain unknown factors? In the tunnel construction example, you don't know how the ground is, and which party in the contract should bear that risk.

## Slide 8 - How Should Delays Be Penalized in Construction Contracts?

We will also cover how to structure an M&A transaction. These are extremely complex contracts when merging or acquiring firms. How should you think about signing the terms of that contract efficiently? We will have lectures about lawsuits and civil procedure. We will discuss why lawsuits happen and how the legal process and the threat of suing someone can shape incentives. Laws on the books do not guarantee compliance; you need people to actually sue, and those lawsuits need to be credible for this to work. We will think about when the legal process shapes incentives and gives firms and individuals reasons to comply with the law. We will also discuss abusive litigation, using the patent troll example. These cases will help teach you how to use economic theories and reasoning in general. On the exam, you will get a new case that is not covered in the course. The aim of this course is to teach you a general method of applying economic theories. By studying these examples, you should learn how to tackle the exam.

## Slide 15 - Textbook available for free online

The textbook is free online. It's a good textbook by top scholars in the field.

It mostly covers what we're doing in the lecture, but if you have to choose between the book and the lecture slides, focus on the slides. We will cover some things, particularly about designing good contracts, that are not well covered in the book.

## Slide 17 - Lecture Plan

On the syllabus I posted on its learning, you can see the reading list. You can check what the reading is for each lecture by looking at the plans. For today, you should read chapters one and two. These are introductory parts. I didn't expect you to read them for today, but you should read those chapters. The reading for criminal law is also listed, but this is not the entire book. It's a large book, and there are many chapters we are not covering.

## Slide 18 - Economic Theory We Will Use

We will start with torts and crimes, then move to contracts, the legal process, and then the review. These are the main themes. This doesn't cover all areas of law, but the method we're introducing can be applied to any area of law. On the exam, you will get something related to these areas, but if you really learn the method, you should be able to apply it to any other area of law.

We will use a narrow set of economic theories. I'm going to teach you some very useful theories or methods that you will use throughout the course. The most important concept is efficiency. Kaldor-Hicks efficiency is essentially what is called cost-benefit analysis, and it is the foundation for this analysis. This is the most important tool. We will think about costs and benefits, and the rule is good if the benefits are higher than the costs. It sounds simple, but applying it in practice is not easy. We will discuss the Coase theorem, some bargaining, and a bit of game theory. We will not cover repeated games, so that should be excluded. It's a small set of economic theories that are not difficult to read and memorize. The challenging part is applying them. The aim of this course is not just to teach you knowledge; it's to teach you skills. You need to be able to apply these theories to legal questions. Think of this as a skill. The only way to learn this course is by practicing. When learning to ride a bike, you can read about it, but the only way to learn is to try and try again until you master it. This is how you should think about this course. There will be mandatory assignments to encourage you to practice the skill, but you should do much more practice, especially as the exam approaches. During the lectures, I will encourage you to actively use the concepts, so we will have a lot of interaction and discussion.

## Slide 21 - Exam

I'm going to ask you questions, and you're going to discuss in groups during the lecture. There's no reason for me to just tell you all the information. You're not going to learn it that way.

## Slide 22 - Office hours

Okay, if you want to meet with me, just send me an email.

## Slide 23 - Questions?

Stop me at any point if you have questions.

There are going to be five assignments, and three of them need to be approved to sit for the exam. You can answer them in groups of up to three students.

I'm going to approve the assignment if it's clear that you've made an effort and really tried.

It doesn't have to be a perfect answer. The point is this will force you to practice. These assignments are exam questions, so there's no reason not to do them. This is the only way to practice for the exam—by actually trying exam-relevant questions.

You should do this even if it weren't mandatory. I don't think forcing you to do this is very bad. You can start this already, but my experience is that very few do this because you only need three out of four. Think of this as an option to select any legal rule you're interested in and analyze it using economic theories. This could be a topic for your master thesis. For those who hand this in, I'm going to give you feedback, especially if this is something you want to do for your master thesis.

You do it in groups, but all of you have to submit on its learning. This way, I can record who has submitted or not. It's not sufficient for only one member of the group to submit, but you can submit the identical answer.

The first deadline is January 26th. The first assignment is already out, and you can start after today's lecture if you want.

The exam is a three-hour written exam.

It's going to be an economic analysis of one or more cases, typically one case with four questions. It will have the exact same format as the practice exam questions. All printed and handwritten support materials are allowed. This is to reiterate that this is not about knowledge. Having all these support materials will not help you on the exam. You can bring them because I don't want you to think this is about memorizing things. The fact that you can bring support materials doesn't mean you should. It's just so you're not trying to memorize the material. It won't be useful to have these materials on the exam because you'll see a totally new case. If you don't understand what they've done, you have no chance of using these materials to answer the exam. You might think of clever ways to write something useful for yourself, but don't bring a list. Bring the entire book if you want, but you have three hours for the exam, so you shouldn't spend time reading the book.

Great. That's it for the course. Any questions? Feel free to ask in Norwegian if you want, and I'll answer in English.

Yep.

Great. How many pages should you write for the assignment? It doesn't have to be a lot, maybe one page per question. There are three questions, so one page per question is more than enough.

On the exam, you should use all your available time and make your answers as detailed as possible within the three hours.

But make sure that what you write is correct. It's better to have a short answer that is correct than a long answer that contains many errors.

More questions? Hmm.

Okay, I'm going to use Mentimeter. You should go to menti.com and use that code. I'll give you some small questions along the way.
