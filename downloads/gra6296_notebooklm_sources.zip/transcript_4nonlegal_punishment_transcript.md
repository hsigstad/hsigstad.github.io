# Lecture Transcript: 4Nonlegal Punishment

## About This Document

This is a transcript of lectures from the course **GRA6296 - Economic Analysis of Topics in Law** at BI Norwegian Business School, taught by Henrik Sigstad.

**Slide deck:** 4nonlegal_punishment.pdf
**Lecture date(s):** January 27, 2026

This transcript has been cleaned for readability. The original was auto-generated from lecture recordings using OpenAI Whisper.

---

## Slide 1 - Non-legal Punishment

This lecture is going to be about what I call non-legal punishment.

## Slide 3 - How To Prevent Fraud

We're back to the Wirecard case and thinking about how to prevent fraud. We can have criminal punishment, we can have tort law, and then we can have what I call non-legal punishment. We'll talk about what that is in this case.

## Slide 5 - Self-Enforcing Laws

First, let me talk about self-enforcing laws. This is the most typical example: it's illegal to drive on the left-hand side of the road.

## Slide 6 - Self-Enforcing Laws

People drive on the right because they can get a fine for driving on the left. There's a probability of being detected by the police. So there are legal incentives. But there are also strong non-legal incentives to drive on the right side of the road. If you try to drive on the left side, it's very hard to avoid crashing into cars coming toward you. This law of driving on the right-hand side would probably be largely obeyed even without police or traffic enforcement because it doesn't make sense to risk an accident by driving on the left side. This is an example of a self-enforcing law that operates without the need for the state to punish or for tort law. It's a way to enforce a law that is automatic and driven by the environment around it.

## Slide 7 - Can laws against financial fraud be

Can you think of a way in which laws against financial fraud can be self-enforcing in a similar way?

## Slide 8 - Mentimeter

Go to menti.com.

You can discuss with your neighbors. Are there any non-legal punishments for engaging in fraud? In the example of the cars, the non-legal punishment is crashing into other cars if you drive on the left side. Is there some kind of punishment for fraud that is similar?

Thank you.

I wouldn't have asked this question if the answer wasn't yes. The interesting question is, what kind of non-legal punishment can you think of? I want to see some hands with ideas about what kind of non-legal punishment might operate here.

Yes.

## Slide 24 - Non-Legal Punishments for Financial Fraud

Excellent. So that's exactly what I was after. In the market, having a reputation for engaging in fraud is going to be very bad for you because no one will want to do business with you or trust you with money. There are strong non-legal punishments for engaging in fraud. If this becomes known, it's going to be very hard for you to conduct business. We can also think about social norms; people might not invite you to dinner because they disapprove of you. That's a different kind of non-legal punishment that doesn't operate through the market but is more about social norm sanctioning. We're not going to talk about those kinds of social punishments. We're going to focus on non-legal punishments that happen in the marketplace, where people will trust you less and engage less with you in business.

In the Wirecard case, the CEO of Wirecard is probably going to have a very hard time finding a new job as a CEO after this scandal. That's a strong punishment because you earn a lot in these positions.

Let me give you some more examples of this kind of non-legal punishment. The first one is personal debt. What happens if you don't pay your debt? Creditors can sue you to seize your assets or garnish your wages. That's a legal punishment. This falls under tort law or contract law.

But there's also non-legal punishment. If you don't pay your debts, you're going to get a very bad credit score, and you won't be able to get a loan from the bank.

Here is how it works: my credit score is very good.

So how does this kind of self-enforcement work in the case of personal debt? Lenders will punish you for your past debt defaults. Why do they punish you? Because they don't trust you anymore. They don't trust you to pay back. They don't do it to punish you, but the effect is that you get punished. It needs to be the case that these banks actually have incentives not to lend to you in the future for this kind of non-legal punishment to work.

A key feature of this kind of system is that the bank will know that you defaulted in the past.

This information about your credit score must be available to all the banks, and they can share information about whether you have defaulted before or not.

Interestingly, this happens in practice. Companies collect information about your credit history, and they sound like public institutions. But in fact, they are private institutions run by the banks. This is something that the banks themselves organize to share information, and they have all the incentives to share this information because they want to know who has defaulted in the past. Your credit score is built this way by the banks. They have the incentive to collect this information and use it to punish you if you don't pay the debt. It's a very interesting system where you have incentives to repay your debt, even if there are no public criminal sanctions or no possibility for the banks to sue you.

Even in those cases, you would have the incentive to repay your debt if you wanted to get a loan in the future.

Second example, consumer fraud. So, an Airbnb scam, for instance.

Of course, it's illegal. You can get sued and held criminally liable, but there are also non-legal punishments. On Airbnb, that non-legal punishment is getting a bad rating.

You will get a very bad review if you engage in fraud on Airbnb, making it hard to attract more customers in the future. So, you have an incentive to treat your customers well. This is a similar mechanism to a credit rating.

Okay. Back to Wirecard. I think I already mentioned how this kind of non-legal punishment would operate here.

The example was that the investor lends 100 to Wirecard, and the Wirecard CEO steals the money.

What might be the non-legal punishment for engaging in this fraud? The CEO will have a hard time getting a job in the future if this is discovered.

This kind of non-legal punishment we talked about is about reputation, basically.

## Slide 28 - Why did investors continue to lend to Wirecard?

This fraud went on for more than a decade. So why did the investors continue to lend to Wirecard during this period? They did it because they didn't know it was a fraud. Had they known, they would not have invested in this firm.

## Slide 29 - Non-Legal Punishment Requires Information

I might talk a little more about reputations later. All of these examples are about your reputation. The example with cars driving on the right side of the road is not about reputation; that's a different kind of mechanism, non-legal enforcement. A third kind of non-legal enforcement related to reputation is relationships. You might not lose your reputation, but you might lose a relationship, like a business partner, if you engage in fraud. It's a related mechanism. Reputation requires some public information about you, so everyone knows how you treated your other business partners, like reviews on Airbnb or your credit score in the case of personal debt. After the break, let's talk about why this fraud was not stopped earlier and why this kind of non-legal mechanism didn't kick in immediately. You would expect that the fraud would be discovered, the CEO would lose his job, and this non-legal punishment would kick in immediately, preventing fraud. But in this case, the fraud happened over a decade before it was discovered, which arguably weakened this kind of non-legal punishment and any other punishment. If you can continue committing fraud for years without any punishment, that is the key question we will discuss next.

This kind of non-legal punishment requires information about fraud. If fraud is never discovered, this mechanism is not going to work.

## Slide 30 - Non-Legal Punishment Requires Information

In the case of personal debt, the credit score gives you this public information.

## Slide 31 - Credit Rating of Firms

We have credit ratings for firms in the same way. These are some of the top credit rating agencies for firms.

## Slide 32 - Credit Rating

They give a triple A rating, which is the best, and so on. This serves as a way of labeling firms that are risky to invest in.

## Slide 33 - Of course Wirecard did repay loans initially

But of course, Wirecard did repay all their loans.

## Slide 34 - Wirecard Was Essentially A Pyramid Scheme

It was essentially a pyramid scheme. The money from new investors was used to pay back earlier loans. All the loans and everything outstanding was paid.

## Slide 35 - Credit rating agencies should ideally have understood that Wirecard

They never defaulted on any loan. So they did have a pretty decent credit rating.

The credit rating agency should have understood that Wirecard was not in a position to repay its debt. They should have given Wirecard a very bad credit rating because Wirecard didn't have the ability to repay its debt.

## Slide 36 - Wirecard 2019 Credit Rating

Here is Moody's credit rating of Wirecard in 2019. It got a BAA3 rating, which is still an investment grade rating. The outlook looked stable.

So it's a decent credit rating that it got in 2019. Let me see.

## Slide 37 - Wirecard 2020 Credit Rating

This is the 2020 rating.

## Slide 38 - Mentimeter

It reflects the positives: Wirecard's strong market position in Asia and Europe, a well-diversified business profile, and a sound financial profile. Apparently, Moody's read the data in a way that suggested Wirecard was doing pretty well.

That's when things were starting to unravel a bit.

Okay, how could Moody's claim that Wirecard had a sound financial profile with very high margins? How could Moody's make that statement?

Any ideas on where these credit rating agencies get their information from? Yep.

Yeah.

Yeah.

## Slide 41 - Why did Moody’s trust Wirecard’s claims of high profits?

Definitely. This information comes from the financial statements of the company, which were made by the executives. The fraud was in these numbers. The numbers they presented showed very high profits and earnings, but these numbers were fake. Moody's just read those numbers and said, "Well, it looks very good." This shows the problem that this method doesn't necessarily work to discover fraud.

But why did Moody's trust this statement by Wirecard? It's naive to just trust these statements when you're worried about hidden issues. How can a credit rating agency read the financial statement and say something about creditworthiness?

Good. In general, there are mechanisms in place that allow you to trust these statements. The key is that the statement has to be audited. For all public companies, you cannot just say, "Okay, this is the financial situation." It needs to be checked by an external agency, which is the auditing company.

In this case, it was Ernst & Young who audited the company. Here is their opinion.

Our audit has not led to any reservations. The consolidated financial statements comply with the standards and give a true and fair view of the net assets, financial position, and results of the operation of the group.

They didn't see any issues with the statement. They thought it reflected the true financial position of the firm. Of course, this was wrong. It was proven wrong later, but this is the 2019 audit.
