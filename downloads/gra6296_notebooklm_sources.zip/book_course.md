Introduction and Orientation
============================

About the Course and the Exam
-----------------------------

This course teaches you how to think about legal rules using economic reasoning. The goal is not to memorize doctrine or reproduce textbook arguments, but to learn how to analyze legal and business problems in a structured, transparent, and convincing way.

At the exam, you will be asked to analyze realistic cases involving contracts, regulation, litigation, or compliance. There is rarely a single correct answer. What matters is whether your reasoning is clear, well structured, and grounded in economic theory.

### What We Are Testing

You are expected to demonstrate that you understand the course material by applying it. In particular, good answers:

-   Use concrete examples, preferably tied directly to the case.
-   Explicitly use economic theory (for example cost--benefit analysis, optimal deterrence, bargaining theory) and explain why it is relevant.
-   State assumptions clearly, and explain how conclusions might change if those assumptions do not hold.
-   Use your own words rather than quoting the book or lecture slides.
-   When helpful, use simple numerical examples to clarify the logic.

Memorizing definitions or reproducing standard arguments is not sufficient.

### Structure of the Exam

The exam is a three-hour written, open-material exam. The questions are case-based and closely resemble the practice exam assignments given during the semester. Most questions fall into one of three types:

-   **Legal rules, institutions, and interpretation** --- evaluating, justifying, or interpreting legal rules using cost--benefit reasoning.
-   **Ex ante incentive design** --- analyzing how contracts or governance mechanisms should be designed to maximize total surplus.
-   **Private behavior under legal incentives** --- predicting how rational actors behave given the legal environment.

If you understand and can solve the assignments, you are well prepared for the exam.

### How Answers Are Graded

Answers are graded based on demonstrated understanding, not on whether you reach a particular conclusion. Clear structure, explicit reasoning, and correct use of economic concepts are rewarded. Different answers can receive full credit if the underlying logic is sound.

### How to Prepare

The best way to prepare is to actively work with the assignments and practice structuring short, clear analyses under time pressure. Focus on explaining why a legal rule or contract works (or fails), not just what it does.

If you can clearly explain your reasoning, you are doing exactly what the exam is designed to test.

About the Book
--------------

### Why law and economics is useful

Legal rules shape behavior, markets, and institutions long before any dispute reaches a court. They affect how firms invest, how contracts are written, how risks are managed, and how people respond to incentives in everyday economic activity. To understand law only as a set of commands or doctrines is therefore insufficient. What matters just as much is how people and organizations respond to legal rules in practice.

Law and economics provides a systematic way to analyze these responses. By focusing on incentives, constraints, and trade-offs, it helps clarify why legal rules sometimes work as intended and why they sometimes produce unintended consequences. The same basic reasoning can be applied across many areas of law, from contracts and torts to criminal law, civil procedure, competition law, and corporate governance.

The goal of this book is not to promote a particular legal ideology, but to provide a disciplined way of thinking about how law affects behavior and outcomes.

### Who this book is written for

This book is written primarily for students at a business school who will work in firms, consulting, finance, or regulated industries, and who will regularly interact with legal rules as part of professional decision-making. Many readers will need to understand not only what the law requires, but how legal rules shape incentives, risks, and strategic choices.

At the same time, the book is also intended for students who may work in public administration, regulatory agencies, courts, or policy-oriented roles, as well as for those who want to participate thoughtfully in public debate about law and regulation. Across these roles, the common need is an ability to reason about how legal rules influence real-world behavior.

### What this book helps you do

The book aims to help you predict how individuals and firms are likely to respond to legal rules, to understand why some legal arrangements perform better than others, and to identify trade-offs involved in legal and regulatory design. It provides tools for analyzing both existing legal rules and proposed reforms, using economic reasoning to structure arguments and clarify consequences.

Rather than offering answers to specific legal questions, the book offers a framework for thinking systematically about law.

### Business decisions and public decisions

Law and economics is useful from both a private and a public perspective. From a private perspective, it helps firms think about contract design, compliance, litigation strategy, and risk management. From a public perspective, it helps regulators, judges, and policymakers think about rule design, enforcement, and institutional structure.

This book deliberately moves between these perspectives. Understanding how private actors respond to legal rules is essential for good public policy, just as understanding public enforcement and regulation is essential for informed private decision-making.

### How this book is designed

The book emphasizes incentives and behavior rather than legal doctrine. It uses simple models and stylized examples to isolate key mechanisms, not to reproduce the complexity of real legal systems in full detail. A small set of analytical tools is introduced and reused across chapters to highlight common patterns across different areas of law.

Simplification is a feature of this approach, not a flaw. Understanding the assumptions behind a model is often more important than the model\'s conclusions.

### How to Read the Structural Sections of Each Chapter

Each application chapter in this book follows a fixed internal structure. Some sections are part of the analytical argument, while others play a structural and pedagogical role. Understanding this distinction will help you read more efficiently and prepare for the exam.

The following sections appear repeatedly across chapters and always have the same meaning.

1.  Exam Question

    This section presents a representative exam-style question for the chapter. It shows the type of problem the chapter prepares you to solve and clarifies what kind of reasoning is expected under exam conditions.

2.  Worked Examples

    This section contains fully worked, exam-style examples. Worked examples demonstrate how to structure reasoning: how to state assumptions, apply the relevant models, and justify conclusions step by step. They are templates for reasoning, not facts to memorize.

3.  How Conclusions Depend on Assumptions

    This section explains how the chapter's main conclusions change when key assumptions are relaxed or modified. This is exam-relevant: you are expected to be able to discuss how results depend on assumptions and how alternative assumptions would affect behavior or efficiency.

    Some material inside this section may be clearly marked as **Awareness**. Such material is included to broaden understanding but is not required for the exam.

4.  Takeaways

    This section summarizes what you should retain from the chapter. It states the core decision rules, mechanisms, and conclusions that you should be able to apply on the exam and in new contexts.

5.  Numbered sections vs. structural sections

    Numbered sections in each chapter form the analytical spine: they develop the economic argument step by step. The unnumbered structural sections described above provide scaffolding around that argument. They help you understand how to use the analysis, how to apply it on the exam, and how its conclusions depend on assumptions.

### The Pedagogy of the Book: Active and Interactive Learning

This book is designed around a simple but strict pedagogical principle:

You learn law and economics by actively reasoning, not by passively reading.

Economic reasoning is a skill, not a body of facts. You do not learn to ride a bicycle by reading about it --- you learn by practicing. The same applies here. If a concept does not click immediately from reading the chapter, that is normal. Understanding often comes from seeing the same idea applied across different examples and then trying to apply it yourself.

For that reason, the book is not organized as a linear text to be read from start to finish. Instead, its structure is deliberately designed to enforce engagement, signal priorities, and make passive consumption harder. The goal is not efficiency in reading, but discipline in reasoning.

1.  Activation questions

    In activation mode, the book occasionally prompts you to activate relevant knowledge before you proceed, or to check whether you have understood what you have just read. These prompts are meant to support learning by forcing you to retrieve and apply concepts rather than simply recognizing them on the page.

    Activation questions are not assessments. They are tools for self-diagnosis. If you find them unhelpful or distracting, you can always turn activation mode off. However, using them as intended mirrors professional reasoning: good analysis starts by checking whether the necessary tools and concepts are actually in place.

2.  Boxes

    The book uses a small and fixed set of pedagogical boxes. These boxes are not summaries or decorative highlights. Each box type has a stable and precise meaning across the entire book.

    Some boxes explain why a result holds (Intuition). Others show how to reason step by step in an exam-style format (Worked Examples). Assumptions boxes identify the conditions on which conclusions depend. Awareness material is explicitly marked as non-exam and is included only to broaden understanding. Each chapter ends with a single Takeaways box, which defines what you are expected to retain and be able to apply.

    Learning to recognize these signals is part of learning how to read the book effectively.

3.  Foldability

    Many elements of the book are foldable in the HTML version, including sections and pedagogical boxes. This structure supports different reading strategies: a first pass focused on core logic, a second pass engaging with examples and extensions, and targeted review before the exam. By making these strategies explicit in the structure of the text, the book encourages active and purposeful reading rather than linear coverage.

### How this book is created: AI as a collaborative tool

This book is created through a collaboration between human judgment and AI assistance.

The instructor defines the pedagogical goals, selects topics and analytical frameworks, determines assumptions, and decides what ultimately belongs in the book. AI is used as a support tool for drafting text, generating examples, maintaining consistency across chapters, and improving clarity.

All AI-assisted content is reviewed, edited, and approved by the instructor, who remains fully responsible for the final product.

The Course NotebookLM {#using-ai}
---------------------

This course provides a NotebookLM workspace---an AI assistant that knows the course material and can help you learn. NotebookLM is Google\'s AI tool that answers questions based on documents you upload. Unlike general-purpose AI assistants, it grounds its responses in your source materials and provides inline citations so you can verify its answers.

You are welcome to use other AI tools as well, but the course NotebookLM is the recommended starting point. It has been configured with the course content and knows how to generate exam-style questions, give feedback on your answers, and produce example solutions in the style expected in this course.

This chapter explains how to set up the notebook and how to use it effectively to **learn more**, not just faster.

### Setting Up Your Notebook {#ai-tools}

You will create your own notebook and upload the course materials.

1.  Creating Your Notebook

    1.  Go to <https://notebooklm.google.com/>
    2.  Log in with your BI email (or your own Google account)
    3.  Click \"Create new notebook\"
    4.  Download the source files from <https://hsigstad.github.io/downloads/gra6296_notebooklm_sources.zip>
    5.  Unzip the archive and add all the files to your notebook

    The zip file contains:

    -   The course book in markdown format
    -   Course slides and readings (PDFs)
    -   Past exams with solutions (2023--2025), which you can use as practice or ask the notebook to explain
    -   The foundations toolkit defining the course\'s analytical frameworks
    -   Guide files that tell the AI how to generate questions, feedback, and solutions

2.  Configuring the Notebook

    To make the notebook respond consistently to exam-related requests, you should configure its conversational goal:

    1.  Click the settings icon in the top right corner
    2.  Select \"Configure notebook\"
    3.  Under \"Define your conversational goal, style, or role\", select \"Custom\"
    4.  Paste the following instruction:

    > You support students in developing economic reasoning and preparing for the GRA6296 exam. When asked to generate an exam question or a complete exam, follow the structure and requirements in exam~format~.md and do not include solutions. Provide solutions only if students explicitly request them. When reviewing student answers, give feedback in accordance with feedback~guide~.md.

### What the Notebook Can Do {#notebook-capabilities}

Once configured, your notebook can help you in three main ways.

1.  Generate Practice Questions

    The notebook can create practice questions in the style of the course exam. You can ask for:

    -   A single practice question on a specific topic
    -   A complete exam (case with four subquestions)

    Example prompts:

    -   \"Give me a practice question on contract design.\"
    -   \"Create a full exam set.\"

    Questions follow the exam format: a realistic case followed by questions that require economic analysis. The questions will not name theories or hint at which framework to use---just like the real exam.

2.  Give Feedback on Your Answers

    After you write an answer, you can ask the notebook to evaluate your reasoning. Paste your answer and ask for feedback.

    Example prompt:

    -   \"Here is my answer to the question above. Give me feedback.\"

    The feedback evaluates your answer along five criteria:

    1.  **Responding to the question** --- Did you address what was asked?
    2.  **Choice of theory** --- Did you select and name an appropriate economic framework?
    3.  **Economic reasoning** --- Did you apply the framework logically?
    4.  **Connection to case** --- Did you tie reasoning to specific facts?
    5.  **Assumptions** --- Did you make key assumptions explicit?

    Each criterion is rated **Strong**, **Medium**, or **Weak**, with examples from your answer and suggestions for improvement.

    The feedback is diagnostic, not corrective. It identifies patterns in your reasoning but does not rewrite your answer or assign grades. Treat it as a structured second opinion.

3.  Generate Example Solutions

    You can ask the notebook for an example solution to a question. This is most useful **after** you have attempted the question yourself.

    Example prompt:

    -   \"Show me an example solution to this question.\"

    The solution shows one well-structured way to answer the question. Remember that there are usually several correct approaches---the example solution is not the only acceptable answer.

    Do *not* memorize example solutions. The exam will present unseen cases, and rehearsed formulations without understanding will not earn credit.

4.  Clarify Concepts and Examples

    You can use the notebook to clarify material you find confusing:

    -   \"Explain the difference between strict liability and negligence.\"
    -   \"Give me another example of moral hazard in a contract setting.\"
    -   \"Why does the probability of detection matter for deterrence?\"

    The notebook draws on the course materials to answer, so explanations stay within the course framework.

5.  Other Study Features

    NotebookLM also offers built-in features for generating study materials:

    -   **Audio overviews** --- podcast-style summaries of your sources
    -   **Study guides** --- structured summaries with key concepts
    -   **Flashcards** --- for memorizing definitions and key points
    -   **Quizzes** --- auto-generated questions to test yourself
    -   **Mind maps** --- visual overviews of how concepts connect

    These can be useful for review, but remember that the exam tests **reasoning**, not recall. Use these features to support understanding, not replace it.

### How to Use the Notebook Effectively {#effective-use}

The notebook is most valuable when you use it actively. The following principles will help you get the most out of it.

1.  Try First, Ask Second

    The most important principle is simple:

    > Always try to answer a question yourself before asking the notebook.

    Even a partial or wrong answer is valuable, because it reveals what you understand and what you do not. If you go straight to the notebook for an answer, you lose the learning opportunity. If you first commit to an answer---mentally or in writing---the notebook becomes a tool for **feedback**, not a substitute for thinking.

    When practicing exam questions, work through them fully on your own first. Think hard before reaching for help. If you get stuck, ask for a **hint** rather than the full solution:

    -   \"Give me a hint about which framework applies here.\"
    -   \"What is the first step I should consider?\"
    -   \"Am I on the right track with this reasoning?\"

    This keeps you engaged in the problem-solving process rather than outsourcing it to the AI.

2.  Let the Notebook Question You

    One of the most effective ways to learn is to be questioned. Instead of asking the notebook to explain a topic, ask it to **test you**.

    Useful prompts include:

    -   \"Ask me conceptual questions about this chapter.\"
    -   \"Give me a short exam-style question and wait for my answer.\"
    -   \"Challenge my reasoning if it is incomplete.\"

    This forces you to retrieve and apply the material, which is far more effective than rereading or summarizing.

3.  Practice Explaining

    A powerful learning technique is to pause after a section and explain it **without looking**.

    You can use prompts such as:

    -   \"I will explain the main idea of this section---tell me if I\'m correct.\"
    -   \"What did I miss in my explanation?\"

    If you cannot explain a concept clearly, you should not move on yet.

4.  Vary the Models

    Most chapters introduce simple economic models. You should actively vary them.

    Ask the notebook to:

    -   change parameters,
    -   alter probabilities,
    -   introduce transaction costs,
    -   or remove enforcement.

    Examples:

    -   \"What happens to deterrence if detection probability falls?\"
    -   \"How does settlement change if one party is impatient?\"

    This builds intuition and prevents rote learning.

5.  Generate Wrong Answers on Purpose

    Another effective technique is to ask the notebook for **plausible but wrong** reasoning:

    -   \"Give me a common but incorrect argument here.\"
    -   \"What is a tempting mistake students make on this topic?\"

    Being able to spot wrong answers is often harder---and more valuable---than producing correct ones.

6.  Connect Chapters

    Law and economics is cumulative. Many exam questions require you to draw on ideas from multiple chapters.

    Use the notebook to practice this:

    -   \"How does this relate to the Coase Theorem?\"
    -   \"Which transaction costs matter here?\"
    -   \"Where does bargaining power enter?\"

    You should get used to seeing the **same tools** reappear in different legal contexts.

7.  Simulate the Exam

    The notebook can simulate realistic exam conditions:

    -   timed questions,
    -   limited prompts,
    -   and minimal guidance.

    For example:

    -   \"Give me one exam question and 30 minutes to answer.\"
    -   \"Do not help me until I submit my answer.\"
    -   \"Grade this as if it were an exam answer.\"

    This helps you practice structuring answers under pressure.

8.  What to Avoid

    The notebook is least effective when used passively. In particular:

    -   Do not rely on summaries alone.
    -   Do not copy formulations without understanding them.
    -   Do not confuse fluency with insight.
    -   Do not ask for solutions before you have genuinely tried.

    If the notebook sounds convincing but you could not reproduce the argument yourself, you have not learned it.

    Your brain develops through use. Every time you struggle with a problem and work through it yourself, you strengthen your ability to reason economically. Every time you skip the struggle and go straight to the answer, you miss that training. The notebook is a powerful tool, but it cannot do your learning for you.

### Limitations {#ai-limits}

NotebookLM is grounded in your uploaded sources, which makes it more reliable than general-purpose AI tools. However, it can still make errors---especially on nuanced judgment calls or when combining ideas in new ways.

Always check the inline citations. When the notebook makes a claim, it shows which source it drew from. Click the citation to verify the information is accurate and not taken out of context.

The notebook cannot replace reading the material or thinking through problems yourself. It is a study partner, not an answer key. If you rely on it passively, you will not develop the reasoning skills the exam tests.

Foundations
===========

Cost--Benefit Analysis {#cba}
----------------------

::: {.foundationorientationbox}
**Introduces:**

-   Cost--benefit analysis
-   Economic surplus and efficiency

**Used in:**

-   All application chapters
:::

This chapter introduces **cost--benefit analysis** (CBA, *nytte-kostnadsanalyse*) as the central evaluative framework used throughout the book. CBA provides a disciplined way to assess whether a legal rule, contractual clause, or enforcement regime is likely to improve outcomes, by comparing the real benefits it creates to the real costs it imposes.

### Economic Surplus and Efficiency {#efficiency}

Cost--benefit analysis evaluates rules by their effect on **economic surplus** (*samlet overskudd*).

Economic surplus refers to the difference between the benefits created by an action, rule, or institutional arrangement and the real resources it consumes. When we say that a rule increases surplus, we mean that it creates more value than it destroys.

Throughout the book, a rule, clause, or institution is called **efficient** (*effektiv*) if it maximizes total economic surplus, taking behavioral responses and enforcement costs into account.

### Cost--Benefit Analysis {#cost-benefit-analysis}

Cost--benefit analysis (CBA) provides a structured way to evaluate legal rules, policies, and institutional arrangements by comparing their expected benefits to their expected costs across society as a whole. The relevant costs and benefits include all real effects generated by the rule, regardless of who bears them.

In practice, this requires analyzing how a rule changes behavior and identifying the resulting real-world effects, such as changes in precaution, investment, compliance, harm, delay, or resource use.

Cost--benefit reasoning is therefore distinct from the internal calculations made by private actors. Firms, individuals, and regulators routinely weigh expected gains against expected costs when deciding how to act. Such private cost--benefit reasoning is essential for predicting behavior, but it is not what we mean by cost--benefit analysis in this course.

In the legal context, CBA is used to assess whether a rule or policy is a good idea overall. It highlights that enforcement is not free: increasing deterrence typically requires higher monitoring costs, higher sanctions, or both. A rule performs well under CBA when the marginal benefits of improved behavior exceed the marginal social costs of enforcement and compliance.

1.  Externalities and Internalization

    An **externality** (*eksternalitet*) is a cost or benefit that a decision-maker imposes on others but does not take into account when choosing how to act. When such effects are not reflected in private payoffs, individual decisions may diverge from what is socially efficient.

    When a legal rule changes private incentives so that decision-makers bear costs they would otherwise impose on others, economists say that the rule **internalizes** (*internaliserer*) the externality. Internalization aligns private decision-making with social costs, and doing so often tends to improve total economic surplus.

### A Practical Recipe for Cost--Benefit Analysis {#cba-recipe}

In law and economics, questions are rarely framed as formal cost--benefit calculations. Instead, they typically ask which factors matter for whether a rule, policy, or clause works well, or under what conditions it is likely to be beneficial.

Such questions invite a cost--benefit perspective. The goal is not to reach a definitive yes/no conclusion, but to identify what the answer depends on and to explain the relevant trade-offs in a structured way.

The following recipe shows how to do this.

1.  Step 1: Be clear about what is being changed

    State clearly what rule, clause, or policy is being considered, and what it is compared to (the status quo or an alternative rule). Cost--benefit reasoning is always comparative.

2.  Step 2: Identify who changes behavior

    Ask who is likely to act differently because of the rule: firms, consumers, managers, victims, offenders, litigants, regulators, etc.

    Focus on how behavior changes (effort, care, delay, investment, compliance, litigation, quality, risk-taking).

3.  Step 3: List real effects in the world

    Identify the main positive and negative effects that follow from the change in behavior. These should be effects that exist in the real world and could, at least in principle, be measured.

    Examples include time spent, resources used, harm avoided, risks reduced or increased, delays, accidents, errors, or misuse.

    Avoid vague labels. If you mention something abstract (such as "trust" or "confidence"), explain what concrete effects it leads to.

4.  Step 4: Handle transfers correctly

    Some rules mainly shift money or risk from one party to another.

    You may list such transfers, but you can also ignore them, since they cancel out when assessing whether the rule is a good idea overall. What matters is whether the rule changes behavior in a way that leads to real gains or real losses.

5.  Step 5: Identify the key factors that determine magnitude

    This is the most important step on the exam.

    For each important effect, explain what determines whether it is large or small. For example:

    -   how strongly people respond to the rule,
    -   how much the rule changes prices, risks, or incentives,
    -   how costly enforcement or monitoring is,
    -   how easy it is to avoid or comply with the rule,
    -   how serious the underlying problem is to begin with.

    You do not need numbers. You need to explain what would matter if numbers were available.

6.  Step 6: Give conditional conclusions

    Do not conclude that the rule is or is not a good idea.

    Instead, explain:

    -   when the rule is more likely to work well,
    -   when it is more likely to work poorly,
    -   which considerations pull in opposite directions,
    -   and which assumptions about behavior, enforcement, information, or institutions these conclusions depend on.

    Explain briefly how the conclusion would change if these assumptions do not hold.

### Common Pitfalls When Using CBA {#cba-pitfalls}

The recipe above describes how cost--benefit reasoning should be used in this course. In practice, exam answers often go wrong in predictable ways. Being aware of these pitfalls will help you avoid losing points for otherwise sensible ideas.

1.  Calling private cost--benefit reasoning \"CBA\"

    Students sometimes use the term \"cost--benefit analysis\" when analyzing a private actor\'s decision, such as whether a firm should invest in compliance, sue, settle, or take precautions. Analyzing how private actors weigh costs and benefits is often essential for predicting behavior, but this should not be called cost--benefit analysis. The term cost--benefit analysis (CBA) is used to evaluate whether a rule or policy is a good idea overall, by comparing the gains and losses it creates across society rather than for a single decision-maker.

2.  Listing abstract concepts instead of real effects

    Students often list items such as \"less trust\", \"reduced confidence\", or \"weaker legitimacy\" as costs or benefits.

    These are not costs or benefits in themselves. If you mention such concepts, you must explain what real effects they lead to (for example worse investment decisions, higher verification costs, or more misuse of resources).

3.  Confusing mechanisms with outcomes

    Relatedly, students sometimes list the mechanism through which a rule operates as a cost or benefit.

    For example, \"stricter enforcement\" or \"higher sanctions\" are not benefits by themselves. The relevant question is what these changes lead to in terms of behavior, harm reduction, resource use, or risk.

4.  Mishandling transfers

    Many rules redistribute money or risk between parties.

    A common pitfall is to list only one side of a transfer (for example payments made by firms, fines paid by offenders, or compensation paid to victims) and treat this as a net cost or benefit.

    Transfers cancel out in a CBA. What matters is whether the transfer changes behavior in a way that creates real gains or real losses.

5.  Jumping to a final conclusion

    Strong exam answers rarely conclude that a rule is or is not a good idea.

    A common mistake is to give a decisive answer without explaining what it depends on. What matters is identifying the key factors and trade-offs, and explaining under which conditions one effect is likely to dominate another.

6.  Being vague about what matters

    Answers sometimes list many possible effects without explaining which ones are likely to matter most.

    A good answer highlights the main drivers of the outcome and explains why they are important, rather than providing a long but shallow list.

7.  Ignoring assumptions

    Finally, students often rely on implicit assumptions about behavior, enforcement, or information without stating them.

    Making assumptions explicit---and briefly noting how conclusions might change if they fail---signals strong understanding and is rewarded on the exam.

### Limits of the Welfare Framework

Welfare analysis and cost--benefit analysis focus on aggregate outcomes and abstract from how gains and losses are distributed. A legal rule or contractual arrangement can therefore increase total surplus while shifting benefits toward some parties and away from others.

Cost--benefit analysis asks whether a rule increases total surplus, not whether everyone gains. A policy can be efficient even if some parties are made worse off, as long as the gains to the winners exceed the losses to the losers. In principle, the winners could compensate the losers and still be better off. Importantly, cost--benefit analysis does not require that such compensation actually occurs. The focus is on whether the total pie grows, not on how it is divided.

This is why efficiency and distribution are treated as separate questions. Efficiency asks whether a rule creates more value than it destroys. Distribution asks who bears the costs and who receives the benefits. Both questions matter, but they call for different tools. Legal rules are typically evaluated for efficiency, while distributional concerns are addressed through other instruments such as taxation and transfers.

In many areas of private law---such as contract law, tort law, corporate law, and competition law---using legal rules to pursue redistribution is typically inefficient. These legal regimes are primarily designed to shape incentives, reduce transaction costs, and facilitate productive activity. When redistribution is pursued through such rules, it often distorts behavior in ways that reduce total surplus.

Contract design provides a clear illustration. When parties are free to contract, selecting clauses that maximize total surplus between them is usually uncontroversial. Distributional concerns can be handled through prices or transfers without altering the efficient allocation of rights and obligations. In such settings, cost--benefit analysis can often be used as a practical decision rule for evaluating contractual terms.

In contrast, cost--benefit analysis should be applied with caution in domains that are explicitly designed to serve redistributive or equity-related objectives, such as health care and education. In these contexts, willingness to pay may reflect income differences rather than underlying need, and efficiency-based reasoning may conflict with broader social and legal commitments.

Throughout this book, cost--benefit analysis is used as a disciplined tool for evaluating incentives and trade-offs in business-relevant legal settings, while recognizing its limits where law serves redistributive or rights-based functions.

::: {.examplebox data-title="Cost–Benefit Analysis and Distributional Conflict"}
Consider a proposal to give a scarce kidney transplant to a richer patient rather than to a poorer patient who is earlier in the queue. If the richer patient has a higher willingness to pay for receiving the kidney sooner, a standard cost--benefit analysis may conclude that the proposal increases total surplus.

This example illustrates a core limitation of cost--benefit analysis: when willingness to pay reflects income differences, efficiency-based reasoning can favor outcomes that increase inequality. For this reason, cost--benefit analysis is particularly problematic in sectors such as health care and education, which are designed to serve redistributive and equity-related goals.
:::

### How This Chapter Is Used Later

The concepts introduced here are applied throughout the book:

-   In contract law, to evaluate default rules and enforcement mechanisms.
-   In corporate governance, to assess incentive structures and control mechanisms.
-   In competition law, to analyze market power and consumer harm.
-   In criminal law and civil procedure, to study deterrence and enforcement design.

Readers should view this chapter as a toolkit rather than a destination: its value lies in repeated application rather than standalone mastery.

Transaction Costs
-----------------

::: {.foundationorientationbox}
**Introduces:**

-   Transaction costs
-   Coasean benchmark

**Used in:**

-   [Why Contracts Exist](#why-contracts)
-   [Limits of Private Ordering](#limits-private-order)
-   [Designing Good Contracts](#designing-contracts)
-   [Corporate Governance](#corporate-governance)
:::

Many legal institutions can be understood as responses to transaction costs---the costs that prevent parties from reaching efficient agreements on their own. This chapter introduces transaction costs as a unifying concept and explains how law helps overcome them.

### What Are Transaction Costs?

Transaction costs (*transaksjonskostnader*) are the costs of identifying trading partners, negotiating agreements, monitoring performance, and enforcing obligations. When transaction costs are low, parties can often resolve conflicts and allocate rights through private agreement. When transaction costs are high, mutually beneficial agreements may fail to occur.

In business settings, transaction costs arise from uncertainty, information asymmetries, bargaining difficulties, and enforcement problems.

### Transaction Costs and Legal Rules

When transaction costs are positive, the initial allocation of legal rights matters. Legal rules influence behavior by determining who bears risk, who must take precautions, and who has the right to act or to be compensated.

From an economic perspective, legal rules can be evaluated based on how well they reduce transaction costs or mitigate their consequences. This includes:

-   providing clear default rules,
-   lowering enforcement costs,
-   reducing information problems, and
-   facilitating coordination among parties.

### The Coasean benchmark {#coasean-benchmark}

The Coasean benchmark, named after economist Ronald Coase, provides a useful theoretical point of comparison for analyzing legal rules. It asks how outcomes would be determined if parties could bargain at zero cost.

Under the Coasean benchmark, if transaction costs were zero and legal rights were clearly defined and tradable, parties would bargain to efficient outcomes regardless of the initial allocation of rights. Efficiency would be achieved through private agreement, and the law would matter only for how surplus is distributed, not for whether value is created.

The importance of the Coasean benchmark does not lie in its realism. Transaction costs are rarely zero, and bargaining is often costly or impossible. Rather, the benchmark serves as a **diagnostic tool**. It clarifies when legal rules affect behavior and outcomes, and when private ordering can be relied upon instead.

Throughout the book, the Coasean benchmark is used as a reference point. In later chapters, it is applied to evaluate when voluntary agreement can be treated as evidence of efficiency, and to identify the institutional and informational conditions under which this logic breaks down.

### Applications Across Legal Domains

Transaction costs and the limits of private bargaining help explain the structure of many business-relevant legal institutions:

-   In contract law, default rules and formal requirements reduce negotiation and enforcement costs.
-   In tort law, liability rules substitute for costly private bargaining.
-   In corporate law, governance structures address coordination and monitoring problems.
-   In competition law, rules limit strategic behavior that exploits bargaining and coordination failures.

Throughout the book, transaction costs provide a lens for understanding why legal rules differ across contexts and why private ordering sometimes fails.

Information and Verifiability {#information-verifiability}
-----------------------------

::: {.foundationorientationbox}
**Introduces:**

-   Asymmetric information
-   Adverse selection problem
-   Moral hazard problem
-   Observable versus verifiable (distinction)
-   Disclosure, screening, signaling (standard responses)

**Used in:**

-   [Limits of Private Ordering](#limits-private-order)
-   [Designing Good Contracts](#designing-contracts)
-   [Corporate Governance](#corporate-governance)
:::

Legal rules operate in environments where information is incomplete and unevenly distributed. Parties differ in what they know about relevant facts, and courts face institutional limits in determining what actually occurred. These informational constraints are a central reason why private ordering may fail and why legal institutions matter.

Information problems shape incentives, contract design, enforcement, and institutional structure across all areas of law. They influence what parties can credibly promise, what behavior can be verified, and which disputes can be resolved through legal processes.

This chapter introduces a small set of information-related concepts that recur throughout the book. The goal is not to model information in detail, but to identify the core distinctions that legal institutions must work with in practice.

### Asymmetric Information

Information may be **symmetric** or **asymmetric**. Information is symmetric when all relevant parties share the same knowledge about characteristics, actions, or states of the world. It is **asymmetric** (*asymmetrisk*) when one party knows something that another party does not.

Asymmetric information is pervasive in legal and economic settings. Sellers often know more about product quality than buyers, borrowers know more about their risk than lenders, and agents know more about their effort than principals.

Information matters because it affects incentives. When relevant characteristics or actions are hidden, individuals may behave differently than they would under full information. Anticipating this, other parties adjust their behavior, prices, or willingness to contract. Efficient exchange or cooperation may fail even when it would be mutually beneficial under full information.

Throughout the book, information asymmetry is treated as a background constraint on legal and institutional design rather than as an exception.

### Adverse Selection and Moral Hazard {#adverse-selection-moral-hazard}

Asymmetric information gives rise to two canonical problems that differ by **timing**.

**Adverse selection** (*ugunstig utvalg*) arises when one party has private information about relevant characteristics **before** a transaction or relationship begins. Because uninformed parties cannot distinguish types, contracts or prices may be distorted, and mutually beneficial transactions may not occur.

Examples include hidden product quality, private information about risk in insurance, or private information about ability in labor markets.

**Moral hazard** (*moralsk risiko*) arises when one party\'s **actions** after a transaction are imperfectly observed. When effort, care, or compliance cannot be monitored or verified, parties may take actions that benefit themselves while imposing costs on others.

Examples include hidden effort by employees, hidden precaution by injurers, excessive risk-taking by borrowers, or opportunistic behavior by managers.

The distinction matters because the two problems call for different institutional responses. Adverse selection primarily motivates **ex ante** mechanisms such as screening and disclosure, while moral hazard motivates **ex post** incentives, monitoring, and sanctions.

Many legal rules can be understood as responses to one or both of these problems.

### Observability vs. Verifiability

A central constraint in law and economics is the distinction between **observability** and **verifiability**.

An action or outcome is **observable** (*observerbar*) if relevant parties can see or infer that it occurred. It is **verifiable** (*verifiserbar*) if it can be demonstrated to a court using admissible evidence and applicable legal standards.

Verifiability is therefore an institutional concept, not a purely factual one. It depends on evidentiary rules, procedural constraints, and the capacity of courts and enforcement agencies.

Many promises, actions, or states of the world may be observable to the parties involved yet difficult or impossible to verify legally. Anticipating this, rational parties adjust contract design, documentation, and governance structures.

Verifiability constraints help explain why legal agreements rely heavily on objective, documentable events rather than subjective assessments of effort, intent, or quality. They also explain why legal systems emphasize formality, records, and standardized procedures.

Across the book, limits of verifiability play a central role in explaining contract incompleteness, enforcement design, and institutional choice.

### Standard Responses to Asymmetric Information

When information is asymmetric, parties and legal systems rely on a small set of standard mechanisms to mitigate or manage informational gaps.

**Disclosure** (*opplysningsplikt*) requires one party to reveal information to another. Mandatory disclosure is common when one party systematically holds superior information. Disclosure can reduce adverse selection but is costly and imperfect, especially when information is complex or strategically framed.

1.  Screening

    **Screening** occurs when the less informed party designs choices that induce the informed party to reveal information through behavior. Contract menus, procedural requirements, and eligibility criteria often serve screening functions.

2.  Signaling

    **Signaling** (*signalisering*) occurs when the informed party voluntarily undertakes a costly action to convey information about itself. For signals to be credible, they must be less costly for high-quality or compliant types than for others.

    Legal rules interact with all three mechanisms by mandating disclosure, shaping which signals are legally meaningful, and constraining the design of screening devices.

### Second-Best Enforcement and Institutional Design

Because information is imperfect and verifiability is limited, legal rules operate in a second-best world. Perfect accuracy is unattainable, and enforcement is costly.

As a result, legal institutions trade off accuracy, enforcement costs, and behavioral responses. Formal requirements, evidentiary thresholds, and procedural rules are not designed to uncover the truth in every case, but to create workable incentives under informational constraints.

The concepts in this chapter provide a common language for understanding how law responds to hidden information across contracts, corporate governance, torts, criminal law, and civil procedure. Later chapters reuse these ideas rather than reintroducing them in isolation.

Self-Enforcement
----------------

::: {.foundationorientationbox}
**Introduces:**

-   Reputation
-   Repeated interaction

**Used in:**

-   [Why Contracts Exist](#why-contracts)
-   [Limits of Private Ordering](#limits-private-order)
-   [Designing Good Contracts](#designing-contracts)
-   [Corporate Governance](#corporate-governance)
:::

Legal sanctions are not the only forces that shape compliance and lawful behavior. In many settings, behavior is disciplined through **self-enforcement** (*selvhåndhevelse*) mechanisms such as reputation, repeated interaction, and social sanctions. This chapter explains when such mechanisms can sustain cooperation or compliance, and when they are likely to fail.

### The Logic of Self-Enforcement {#self-enforcement-logic}

Self-enforcement can be understood as an extension of the Legal Incentives Model in which incentives arise from future interaction rather than from formal legal sanctions. In both cases, behavior is shaped by comparing the short-term private benefit of opportunistic behavior to an expected future cost. What differs is the source of that cost.

In the Legal Incentives Model, the expected cost comes from the legal system and takes the form of a sanction that is imposed with some probability. In self-enforcement, the expected cost comes from the loss of future opportunities: damaged reputation, termination of relationships, exclusion from networks, or worse terms in future transactions.

The analytical logic is therefore the same. Opportunistic behavior is deterred when its immediate private benefit is outweighed by the expected future loss it triggers. Self-enforcement replaces formal legal sanctions with privately generated incentives that depend on information and repeated interaction.

Self-enforcement operates across many legal domains. A supplier may deliver on time to preserve a long-term relationship, even when short-term breach would be profitable. A CEO may abstain from embezzling funds not only because of legal sanctions, but because reputational damage would reduce future job prospects. Similarly, professionals may comply with tort or regulatory standards to avoid exclusion from future business. In each case, behavior is disciplined by the value of future interaction rather than by immediate legal punishment.

Self-enforcement should therefore not be seen as an alternative to incentive-based reasoning, but as a different enforcement mechanism operating through the same economic logic. Later chapters examine how legal enforcement and self-enforcement interact, and when one can substitute for or complement the other.

Self-enforcement relies on incentives rather than external enforcement. An agent behaves cooperatively today in order to preserve valuable future opportunities. When self-enforcement works, formal legal enforcement may be unnecessary or play only a supporting role.

Two conditions are necessary for self-enforcement to be effective.

### Condition 1: Information About Past Behavior

Future counterparties must be able to observe, or credibly infer, how an agent behaved in the past. If opportunistic behavior cannot be detected or communicated, future interactions cannot be conditioned on past actions.

Information about past behavior may come from direct experience, public records, reputational intermediaries, or informal networks. When information is noisy, delayed, or manipulable, reputational enforcement becomes weaker.

### Condition 2: Value of Future Interaction

An agent must care sufficiently about future opportunities that depend on current behavior. If future gains are small relative to the short-term benefit of cheating, self-enforcement will fail.

This condition highlights the importance of repeat business, long-term relationships, and switching costs. One-shot transactions and end-game situations are especially prone to opportunistic behavior.

### Reputations and Relationships

Reputations (*omdømme*) summarize past behavior and affect access to future transactions. They are particularly important in markets where formal enforcement is costly, slow, or incomplete.

Long-term relationships strengthen self-enforcement by increasing the value of future interaction and allowing for flexible responses to unforeseen contingencies. In such settings, informal agreements may outperform rigid formal contracts.

### Limits of Self-Enforcement

Self-enforcement breaks down when either of the two conditions fails. This commonly occurs when:

-   transactions are infrequent or one-shot,
-   information about behavior is difficult to verify,
-   parties can exit markets easily after cheating, or
-   the gains from opportunism are large.

In these situations, reliance on private ordering alone may lead to inefficient outcomes.

### The Role of Law

Formal legal institutions can support private ordering by improving information, increasing the cost of opportunism, and stabilizing expectations. Contract law, disclosure rules, and enforcement mechanisms often complement reputational incentives rather than replace them.

Throughout the book, self-enforcement is treated as an alternative or complement to legal enforcement. In later chapters, we return to these mechanisms when discussing contract design, corporate governance, and compliance.

::: {.assumptionbox data-title="Norms and Social Motivations"}
Behavior may also be influenced by social norms, moral commitments, and internalized values that operate independently of reputation or future interaction. Such motivations can lead individuals to comply with rules or obligations even when deviation would not be detected and would not affect future opportunities.

This book does not model these forces explicitly. When relevant, intrinsic motivations can be treated as part of the private benefit $B$. Norms are discussed in this chapter only insofar as they shape reputational and relational enforcement. The formation and internalization of social norms lie outside the scope of the analytical toolkit developed here.
:::

Contracts
=========

Why Contracts Exist {#why-contracts}
-------------------

::: {.chapterorientationbox}
**Foundations used:**

-   [Transaction Costs](#transaction-costs)
-   [Self-Enforcement](#self-enforcement)

**Learning goal:** apply commitment logic to understand when contracts enable cooperation.
:::

**Types of Questions You Should Be Able to Answer**

::: {.questionblock}
-   Why do mutually beneficial transactions sometimes fail to occur?
-   When can legal enforcement solve commitment problems?
-   When is self-enforcement sufficient without courts?
:::

::: {.activationquestion data-activation-id="why-contracts-prereq" data-activation-type="radio"}
Parties disagree about the fair division of surplus

Parties cannot easily negotiate, monitor, or enforce agreements

Parties are irrational and fail to maximize their payoffs

Legal rules prevent parties from contracting

Correct. High transaction costs---the costs of identifying partners, negotiating terms, monitoring performance, and enforcing agreements---prevent efficient bargaining even when mutually beneficial trades exist.

Not quite. The transaction costs framework focuses on the costs of negotiating, monitoring, and enforcing agreements. When these costs are high, efficient outcomes may fail to materialize even when both parties would benefit.
:::

Many economically valuable transactions involve cooperation over time. One party must take an action today---invest, deliver, or exert effort---while the other party's reciprocal action occurs later. Examples include public procurement, supplier contracts with delayed payment, employment relationships, and credit agreements.

From a social perspective, many such interactions are efficient: if both parties perform as promised, total benefits exceed total costs. In principle, there exists a division of surplus that makes both sides better off.

Yet in practice, these mutually beneficial transactions often fail to occur or are carried out inefficiently. The central reason is not disagreement about prices or values, but the inability of parties to credibly commit to future behavior.

Promises alone are often insufficient. Once one party has acted, the other may have an incentive to behave opportunistically---to withhold performance, cut quality, or refuse payment. Anticipating this, rational parties may refuse to cooperate in the first place, even when cooperation would create surplus.

This is not a moral problem, but an incentive problem. Law and economics treats distrust as a predictable outcome of rational behavior under weak commitment. The economic role of contracts is therefore not merely to record promises, but to change incentives by making commitments credible.

### A Simple Example: Public Procurement Without Contracts

To see how cooperation can fail even when it is efficient, consider a simplified public procurement example.

The state wants a private contractor to build a new highway and railway:

-   Construction costs the contractor 1.5 (billion NOK).
-   The state values the completed project at 2.
-   Total surplus from completion is therefore 0.5.

From a social perspective, the project should go ahead. There exists a payment---say 1.8--- that gives the contractor a payoff of 0.3 and the state a payoff of 0.2.

Now consider the interaction without a contract. The timing is as follows:

1.  The state decides whether to pay.
2.  After observing the state's decision, the contractor decides whether to build.

The payoffs are:

-   If the state pays and the contractor builds: (0.2, 0.3).
-   If the state pays and the contractor does nothing: the contractor keeps the payment.
-   If the state does not pay: nothing happens and both receive 0.

Only one outcome creates positive total surplus: payment followed by construction. However, this outcome is not stable when promises are unenforced.

If the state were to pay first, the contractor would then face a choice between building and keeping the payment without building. Because construction costs are incurred after payment and there is no penalty for non-performance, the contractor prefers not to build. Anticipating this incentive, the state rationally refuses to pay in the first place.

The outcome is therefore no payment, no construction, and zero surplus---despite the existence of a mutually beneficial transaction.

### The Commitment Problem

The failure of cooperation in the example reflects a general **commitment problem** (*forpliktelsesproblem*). At the moment performance is required, the other party's obligation is already sunk. Promises about future actions are therefore cheap to make but costly to keep.

This logic is symmetric. If the contractor were required to build first and receive payment only after completion, the state would face the temptation not to pay. Anticipating this, the contractor would refuse to invest.

The key insight is that rational parties cannot rely on unenforced promises when actions are separated in time. Inefficient outcomes arise not because parties are irrational, but because incentives make non-cooperation individually optimal.

### Contracts as Commitment Devices

Contracts solve the commitment problem by making promises costly to break. Their central economic function is to reshape incentives so that performance becomes individually optimal.

Return to the procurement example. Suppose the parties sign a legally enforceable contract specifying payment of 1.8 in exchange for construction. If the contractor fails to perform, the state can sue for breach of contract.

Assume that:

-   Compensatory damages equal the state's lost benefit of 2.
-   Legal costs are 0.1 and borne by the losing party.

After receiving payment, the contractor now faces the following choice:

-   Build: incur a cost of 1.5 and earn 0.3.
-   Breach: pay damages of 2 plus legal costs of 0.1, yielding --0.3.

Because breach is now more costly than performance, construction becomes the contractor's optimal action. Anticipating this, the state is willing to pay. Legal enforcement transforms the cooperative outcome into the stable outcome of rational behavior.

Importantly, this result does not depend on trust or moral motivation. Even a purely self-interested party will perform when breach is sufficiently costly. Contract law substitutes for trust by providing external enforcement.

### Contracts and Self-Enforcement

Contracts are not always enforced primarily through courts. The same commitment problems can sometimes be addressed through private enforcement mechanisms such as reputation, repeated interaction, and the value of future trade.

### Summary

This chapter has explained why contracts are necessary from an economic perspective. Many mutually beneficial transactions involve delayed exchange and relationship-specific investments. Without enforceable commitments, rational parties anticipate opportunistic behavior and may refuse to cooperate, even when cooperation would create surplus.

Contracts solve this problem by changing incentives. By making promises legally enforceable, contract law makes breach costly and performance privately optimal. In doing so, contracts convert interactions where cooperation breaks down into interactions where cooperation is sustainable.

This chapter focuses on why contracts exist and how enforcement enables cooperation. Questions about when private contracts should be constrained or overridden are taken up in the next chapter on the limits of private ordering.

### Assumptions and Robustness {#assumptions-why-contracts .unnumbered html_container_class="structural-section assumptions-section"}

::: {.assumptionbox data-title="Observable Breach"}
The analysis assumes that breach can be observed and proven in court. When non-performance is difficult to verify---for example, when quality is subjective or effort is unobservable---legal enforcement may be ineffective even if contracts are formally enforceable. In such cases, self-enforcement mechanisms become more important.
:::

::: {.assumptionbox data-title="Effective Legal Enforcement"}
The commitment logic requires that courts can make breach sufficiently costly. If enforcement is slow, uncertain, or damages are capped below the gains from breach, the commitment problem may persist despite formal contracts.
:::

### Takeaways {#takeaways-why-contracts .unnumbered html_container_class="structural-section takeaways-section"}

-   Mutually beneficial transactions can fail when parties cannot credibly commit to future performance.
-   Contracts solve commitment problems by making breach costly, aligning private incentives with cooperation.
-   Legal enforcement substitutes for trust: even self-interested parties perform when sanctions exceed the gains from breach.
-   Self-enforcement through reputation and repeated interaction can sometimes achieve similar results without courts.

### Exam Questions {#exam-questions-contracts .unnumbered html_container_class="structural-section exam-questions-section"}

Limits of private ordering {#limits-private-order}
--------------------------

::: {.chapterorientationbox}
**Foundations used:**

-   [Cost--Benefit Analysis](#cba)
-   [Transaction Costs](#transaction-costs)
-   [Information, Evidence, and Verifiability](#information-verifiability)

**Learning goal:** identify when private agreements fail to produce efficient outcomes and assess when law should facilitate or constrain private ordering.
:::

**Types of Questions You Should Be Able to Answer**

::: {.questionblock}
-   How can legal rules facilitate efficient private agreements?
-   When and how should law intervene in private contracting?
:::

::: {.activationquestion data-activation-id="limits-private-order-prereq" data-activation-type="radio"}
Only the costs and benefits to the parties who contracted

Only the costs and benefits that can be measured in money

All real resource costs and benefits to all affected parties

Only the costs and benefits that occur within the contract period

Correct. Cost--benefit analysis includes all real resource costs and benefits regardless of who bears them. This is why third-party effects matter: private contracts may be inefficient when they impose costs on parties not at the bargaining table.

Not quite. Cost--benefit analysis aims to measure total surplus across all affected parties, not just the contracting parties. This broader scope is why private ordering can fail when contracts impose externalities on third parties.
:::

Enforceable contracts allow parties to solve commitment problems and cooperate over time. When contracting is cheap and effective, voluntary agreement is a powerful mechanism for creating value and allocating risk. In such settings, the fact that parties choose to contract is usually informative about whether the arrangement creates surplus.

This presumption, however, is not unconditional. Whether voluntary agreement can be trusted as a guide to welfare depends on whether the conditions underlying the Coasean benchmark plausibly hold. When these conditions fail, private agreement may no longer reliably reflect efficient incentives or outcomes.

This chapter examines when and why private contracting succeeds, when it fails, and how contract law responds. Building on the Coasean benchmark introduced in the transaction costs chapter, the central organizing principle is transaction costs broadly understood: the costs of information, negotiation, enforcement, and participation. When high transaction costs prevent efficient agreements from forming, the law plays a **facilitative** role by supporting private ordering. When contracts exist but agreement cannot be trusted to reflect social costs and benefits, the law plays a **corrective** role by shaping or constraining contractual outcomes.

### The Coasean benchmark {#coasean-benchmark-contracts}

A useful starting point for analyzing contract law is the Coasean benchmark introduced in the transaction costs chapter. As a limiting case, it highlights when private bargaining can be relied upon to produce efficient outcomes and when legal rules matter.

In applying the Coasean benchmark to real contracts, the key question is whether voluntary agreement can be treated as evidence of efficiency. This is the case only when the institutional and informational conditions required for effective bargaining plausibly hold. In particular, voluntary agreement is informative about surplus creation when:

\(i\) transaction costs are sufficiently low for mutually beneficial agreements to be formed and enforced, (ii) relevant information and actions are observable or verifiable, or can be credibly communicated, (iii) all materially affected parties are represented at the bargaining table, and (iv) consent is **meaningful**, in the sense that parties have real outside options and are not subject to coercion, extreme urgency, or severe lock-in.

When these conditions hold, private consent is a reliable guide to efficiency. Contract law should then usually take a **facilitative** posture: enforcing promises, supplying clear default rules, and reducing the costs of contracting and enforcement.

The Coasean benchmark is not a claim that contracts are always efficient. Rather, it provides a structured way of identifying when private agreement can be trusted as a signal of efficiency, and when legal intervention may be warranted because one or more of these conditions fail.

### The Facilitative Role of Contract Law

In some settings, the logic of the Coasean benchmark remains valid in principle, but high transaction costs prevent efficient agreements from forming or being reliably enforced in practice. The potential gains from trade exist, yet private ordering fails because contracting is too costly or fragile given the available institutions.

As discussed in the transaction costs chapter, private bargaining can sustain efficient outcomes only when the costs of identifying trading partners, negotiating terms, monitoring performance, and enforcing agreements are sufficiently low. When these costs are high, voluntary agreements may fail to form altogether or may take an incomplete and unstable form, even when the underlying exchange would be mutually beneficial.

In such cases, the primary role of contract law is **facilitative**. The problem is not that private contracts are undesirable, but that efficient contracts are too costly to create or enforce through private ordering alone. Legal rules can improve outcomes by reducing the costs of contracting and by making commitments credible.

High transaction costs arise for many reasons. Negotiating detailed terms requires time and expertise. Anticipating and specifying all relevant future contingencies may be impossible or prohibitively expensive. Monitoring performance and enforcing obligations also consume resources and may be subject to uncertainty.

When transaction costs are high, parties may under-contract, rely on vague or informal arrangements, or avoid potentially valuable transactions altogether. Contract law can mitigate these problems by supplying **default rules**, standardized terms, and mechanisms for judicial gap-filling. These tools allow parties to economize on negotiation and drafting by relying on terms they would likely have chosen themselves if contracting were cheaper.

Predictable enforcement plays a central role in this facilitative function. Parties must be able to anticipate the legal consequences of performance and breach with reasonable certainty. Unpredictable or highly discretionary enforcement undermines the credibility of commitments and discourages efficient investment and cooperation.

In its facilitative role, contract law does not seek to design outcomes, correct bargaining power, or redistribute surplus. Its function is to remove impediments to private agreement and to support private ordering. This perspective is often summarized as a **Normative Coasean** design principle: to promote efficiency, legal rules should be structured so as to reduce the costs of contracting and enforcement, thereby allowing mutually beneficial agreements to occur.

### When Should Law Intervene in Private Contracts?

Private contracts are generally respected because, under the Coasean benchmark, voluntary agreement is a reliable guide to efficient outcomes. However, private agreement is not always informative. Even when contracts are formally voluntary and legally enforceable, institutional constraints may prevent private bargaining from internalizing all relevant costs and incentives.

The central question is therefore not simply whether parties consented, but whether the conditions of the Coasean benchmark hold---whether consent reliably reflects surplus creation. When one or more conditions fail, legal intervention can improve welfare by reshaping incentives or constraining contractual outcomes. The following subsections identify the main ways in which this occurs.

1.  Information and Incentive Problems

    Here, the Coasean benchmark fails because relevant information or actions cannot be credibly observed, verified, or disciplined through contracting.

    Contracts often rely on information that one party cannot observe or verify. When quality, risk, or effort is privately known, contractual terms may be based on distorted beliefs rather than accurate assessments of costs and benefits. In such settings, private agreement does not reliably reflect underlying incentives or social costs.

    These problems are especially acute when performance is difficult to verify or when actions are taken after the contract is signed. Private contracts may then under-incentivize precaution, quality, or effort, or may encourage excessive risk-taking, even when both parties act voluntarily and in good faith.

    Legal intervention can respond either by improving information flows or by reshaping incentives directly. Disclosure requirements, warranties, liability rules, and mandatory standards can reduce information asymmetries or substitute for missing contractual discipline. The economic justification for these interventions is not paternalism, but the need to align private incentives with underlying risks and costs when information is imperfect or unverifiable.

2.  Missing Affected Parties

    Here, the Coasean benchmark fails because not all materially affected parties are able to participate in bargaining.

    Private contracts bind only those who are party to the agreement. When contractual performance imposes costs or risks on others who are not represented at the bargaining table, private consent is no longer sufficient to ensure efficiency. Even when contracting parties are well-informed and act voluntarily, their agreement may fail to reflect all relevant social costs and benefits.

    The core problem in such cases is not bargaining failure among the contracting parties, but the absence of affected parties whose interests are not internalized. Third-party harms may therefore remain unaddressed, and outcomes that are privately efficient for the contracting parties may be socially inefficient.

    Legal intervention can address these failures by expanding the scope of responsibility beyond the contracting parties. Liability to third parties, restrictions on certain contractual arrangements, or regulatory constraints on contract terms can force parties to take account of costs they would otherwise ignore. In economic terms, these interventions aim to internalize external effects that private contracting alone cannot capture.

3.  Distorted Choice Environments

    Here, the Coasean benchmark fails because consent no longer reliably reflects genuine alternatives or mutual gains.

    In some settings, private agreement does not provide reliable evidence of efficiency because choice itself is distorted. The problem is not a lack of enforcement or hidden information, but the absence of a meaningful alternative. When exit or switching is severely constrained, agreement may reflect necessity rather than genuine mutual advantage.

    At the extreme, a contract signed under a credible threat of violence---for example, when one party is forced to sign at gunpoint---provides no information about surplus creation. A signature exists, but consent is meaningless: agreement no longer signals efficiency.

    Real-world cases are rarely this extreme, but similar concerns arise whenever one party faces severe constraints on exit or switching. Take-it-or-leave-it contracts, lock-in, high switching costs, or urgent necessity can all weaken the informational content of consent. In such situations, agreement may reflect the lack of alternatives rather than the efficiency of the contractual terms.

    The economic concern here is not inequality as a distributive objective, but the effect that inequality can have on choice. Whether contract law should be used for *redistribution* is a separate question. Unequal bargaining positions matter in this context not because unequal outcomes are objectionable in themselves, but because persistent asymmetries can undermine the informational value of consent.

### Summary: The Limits of Private Ordering

Private contracts are a powerful mechanism for creating value because, when the Coasean benchmark holds, voluntary agreement aligns incentives and internalizes costs. In such cases, freedom of contract combined with facilitative legal rules can sustain efficient outcomes with minimal intervention.

However, private ordering has limits. When transaction costs prevent efficient contracts from forming, the appropriate role of contract law is **facilitative**: to reduce the costs of contracting and enforcement so that mutually beneficial agreements can occur. When contracts exist but the Coasean benchmark fails---due to information problems, missing affected parties, or distorted choice environments---private consent is no longer a reliable guide to efficiency.

In these cases, legal intervention may improve welfare by reshaping incentives or constraining contractual outcomes. The central question is therefore not whether parties consented, but whether private agreement reliably reflects surplus creation. Where it does, freedom of contract should prevail. Where it does not, carefully designed legal intervention can enhance efficiency by restoring the link between private incentives and social costs and benefits.

### Assumptions and Robustness {#assumptions-limits-private-order .unnumbered html_container_class="structural-section assumptions-section"}

::: {.assumptionbox data-title="Verifiability"}
The analysis assumes that key aspects of performance are verifiable to courts at reasonable cost. When effort, quality, or precaution cannot be proven in court, parties cannot write enforceable contract terms that depend on these factors. This makes it difficult to create incentives for behavior that matters but cannot be documented. Lack of verifiability is a particular form of high transaction cost that limits what both private contracts and legal rules can achieve.
:::

::: {.awarenessbox data-title="Enforcement"}
The analysis assumes that courts can enforce contracts and legal rules with reasonable accuracy, predictability, and cost. Even when relevant facts are verifiable in principle, weak court performance raises the transaction costs of contracting and litigation, reducing the value of contracts as commitment devices and limiting the effectiveness of both facilitative and corrective legal interventions. Improving enforcement quality can therefore be understood as one way of reducing transaction costs and strengthening private ordering.
:::

::: {.awarenessbox data-title="Redistribution through Contract Law?"}
Should contract law be used to reduce inequality? Economists typically argue that redistribution should be carried out through general taxes and transfers, leaving contract law to facilitate value-creating agreements. This division of labor reflects the view that redistribution is best handled by instruments designed for that purpose.

Redistribution through taxes and transfers, however, can itself be inefficient or difficult to implement. Whether contract law should be used as a redistributive tool therefore depends on whether redistribution through contract law is less costly, in efficiency terms, than redistribution through alternative instruments.

In some settings, this may plausibly be the case. For example, interventions in labor law that limit freedom of contract can redistribute surplus from capital to labor. Although such rules may distort labor market outcomes, they may still be preferable to relying on taxes on corporate income that are costly to enforce, easy to avoid, or highly mobile across jurisdictions.

Concerns about inequality arise primarily in contracts between unequals. In many business-to-business contracts---the main focus of this course---parties are typically repeat players with meaningful outside options, making distributional considerations less central than in consumer or labor contracts.
:::

### Takeaways {#takeaways-limits-private-order .unnumbered html_container_class="structural-section takeaways-section"}

-   The **Coasean benchmark** provides a baseline for evaluating contract law: voluntary agreement can be treated as evidence of efficiency only when transaction costs are low, information is reliable, all affected parties are represented, and consent is meaningful.
-   When the benchmark largely holds but transaction costs prevent efficient contracts from forming, contract law should play a **facilitative** role by reducing the costs of negotiation, drafting, and enforcement.
-   When the benchmark fails---due to information and incentive problems, missing affected parties, or distorted choice environments---private consent is no longer a reliable guide to efficiency.
-   In such cases, legal intervention may improve welfare by reshaping incentives or constraining contractual outcomes so as to restore the link between private incentives and social costs and benefits.

### Exam Questions {#exam-questions-limits .unnumbered html_container_class="structural-section exam-questions-section"}

::: {.examquestion data-question-id="contracts-home-insurance-mandatory"}
Selskapet **TryggBolig AS** tilbyr innboforsikring til privatpersoner. De siste årene har flere kunder valgt å stå uten forsikring, samtidig som antallet store skadeutbetalinger har økt. Bransjen rapporterer også om økende forekomst av forsikringssvindel, særlig ved påståtte tyverier og brannskader. Enkelte kunder har fått avslag fordi selskapet mener skadene ikke er tilstrekkelig dokumentert.

Ledelsen i TryggBolig AS vurderer nå ulike tiltak for å redusere svindel, styrke lønnsomheten og sikre tilliten til selskapet. Samtidig vurderer myndighetene å gjøre innboforsikring obligatorisk for alle husholdninger. Du er ansatt som økonomisk rådgiver og blir bedt om å gi en faglig vurdering av situasjonen.

Et økende antall husholdninger står uten innboforsikring. Myndighetene vurderer derfor å innføre krav om obligatorisk forsikring for alle. Forslaget har skapt politisk debatt: Partier på høyresiden advarer mot statlig inngripen i et privat marked, mens partier på venstresiden mener at en slik ordning er nødvendig for å sikre sosial trygghet. Diskuter forslaget ved hjelp av økonomisk teori.

::: {.goodanswer}
A good answer should use the Coasean benchmark. Good answers could also draw on Adverse selection. The key is to compare a mandate to the voluntary market outcome and explain when voluntary non-insurance is informative evidence of efficiency (consent, understanding, no costs shifted to outsiders) and when it is not. A strong answer connects the observed trend (more uninsured, more large payouts, and more fraud/disputed claims) to frictions that can undermine private ordering, especially risk-type sorting that makes premiums unattractive for low-risk households and information/verifiability problems that raise administrative and enforcement costs. The conclusion should turn on whether the main problem is distribution ("social security") versus efficiency (transaction costs, missing third parties), and on how costly it is to enforce a mandate and deter fraud.
:::

::: {.examplesolution}
To answer this question we will use the Coasean benchmark and Adverse selection.

**Object and counterfactual** The object is a legal requirement that all households must buy home contents insurance. The counterfactual is the current regime where households can opt in or opt out, and insurers are free to contract and price risk.

**Incentives and behavioral responses** Under the Coasean benchmark, voluntary insurance contracts are presumptively welfare-improving because both parties agree only if they expect to be better off. In that world, a growing share of uninsured households could simply reflect heterogeneous preferences and risk exposure: some households may rationally choose to self-insure (bear the risk) rather than pay the premium.

A mandate changes behavior by eliminating the opt-out margin. It increases coverage mechanically, but it also changes who is in the pool and how contracts are priced. If the current voluntary market is unraveling because the remaining buyers are disproportionately high risk, forcing low-risk households into the pool can lower average payouts per policy and stabilize the market. At the same time, compulsory coverage can weaken incentives to avoid losses (and can increase fraud attempts), because more people will have a claim opportunity once insured.

**Transaction costs and private ordering** The Coasean intuition behind the Coasean benchmark holds when rights are well-defined and tradable and transaction costs are close to zero. Put more operationally, voluntary contracts are good evidence of efficiency when (i) the agreement is genuinely voluntary, (ii) both parties understand the contract and act rationally, and (iii) the contract does not impose relevant costs on third parties.

Here there are reasons to doubt that the voluntary outcome reliably aggregates to an efficient market outcome. The facts point to a high-transaction-cost environment driven by information problems about risk type. If the households who most want insurance are those with higher expected losses, insurers must raise premiums, and then low-risk households are the first to opt out. A simple illustration: suppose some households have expected annual losses of 10,000 (high risk) and others 1,000 (low risk). If insurers cannot price perfectly by type and must charge a pooled premium around 5,500, low-risk households will rationally drop out, leaving a worse pool and pushing premiums up further. In that case, the observed increase in non-insurance is not strong evidence that "the market is working"; it may instead reflect adverse selection that prevents mutually beneficial trades with low-risk households.

**Verifiability and enforcement** The prompt also highlights rising fraud and disputed documentation (e.g., alleged theft and fire). That points to verifiability constraints: even if a loss is observable to the insured, it may be hard to prove to the insurer/court at acceptable cost. This raises real resource costs for claims handling (investigation, documentation, disputes), and it can lead to socially wasteful behavior (time and resources spent staging, hiding, or contesting claims).

A mandate does not remove these constraints. It may increase claim volume and therefore increase the resources spent on verification and anti-fraud. Enforcement also matters on the coverage side: a mandatory rule requires some monitoring of whether households actually hold a valid policy (administration and compliance checks), which is itself costly.

**Real costs and benefits**

-   **Risk-bearing and inefficient self-insurance:** Mandatory coverage reduces the need for households to hold costly buffers (e.g., excessive savings or other costly "self-insurance") and reduces the real distress and disruption from uninsured large losses, relative to a world where some remain uninsured.
-   **Misallocation from adverse selection ("market unraveling"):** If adverse selection is driving low-risk households out, a mandate can reduce the inefficiency from missing mutually beneficial insurance trades by forcing broad pooling; this can lower the resources wasted on searching for, pricing, and re-pricing an increasingly risky pool.
-   **Administrative and enforcement costs:** A mandate increases real resource costs of administering compliance (verification of coverage) and may increase insurers' claim-processing and investigative costs because more households are insured and can file claims.
-   **Fraud and loss-avoidance behavior:** Compulsory insurance can increase resources wasted on fraudulent activity and on defensive monitoring/investigation; it can also reduce private incentives to take loss-avoidance precautions if premiums or coverage terms do not reflect behavior well.
-   **Public relief and external costs (if present):** To the extent uninsured households receive public emergency support after large losses, broader coverage can reduce tax-financed relief administration and other spillover costs. If such third-party costs are small, this channel is weak.

Premiums and claim payments are mainly transfers between insureds and insurers and are not themselves real resource costs or benefits, but they matter for incentives and for who opts in or out under voluntary insurance.

**Conditional conclusion** If voluntary contracting conditions are approximately satisfied (low transaction costs, good risk-based pricing, limited fraud, and little or no shifting of costs onto third parties), then the Coasean benchmark implies that mandatory home contents insurance is likely to reduce welfare by forcing coverage on households who rationally prefer to self-insure and by adding compliance administration. If instead adverse selection and verifiability problems are sufficiently severe that the market is unraveling (high-risk households remain insured, low-risk households exit, and pricing cannot correct this), then a mandate can increase welfare by restoring pooling and preventing inefficient non-insurance---provided the added enforcement and anti-fraud costs do not outweigh these gains. The stronger the fraud problem and the higher the costs of monitoring compliance and verifying claims, the weaker the efficiency case for a mandate (even if the distributional "social security" case remains politically salient).
:::
:::

::: {.examquestion data-question-id="cross_cutting-bankid-fraud-regulation"}
The government is considering proposing new rules that assign banks greater responsibility in cases of BankID fraud. The banks argue that the authorities should not intervene and regulate this. They claim that such interventions will only make digital banking services more expensive for customers, and that the banks themselves are best positioned to identify the most effective solutions. Discuss, on the basis of economic theory, under what conditions public regulation may nevertheless be justified.

::: {.goodanswer}
A good answer should use the Coasean benchmark. Good answers could also draw on Cost--Benefit Analysis. The core move is to treat the banks' "leave it to us/contracting" argument as plausible when consent is genuinely informed and transaction costs are low, so that banks and customers can allocate fraud risk efficiently through pricing and contract terms. The answer then identifies concrete conditions under which that inference breaks: customers' limited information and understanding of security quality and contract terms, high transaction costs that prevent efficient tailoring across heterogeneous customers, and third-party effects from reduced trust in the digital payment system. Under those conditions, shifting (some) fraud liability to banks can be justified because it changes incentives to invest in prevention and can internalize broader harms that private contracts may not capture.
:::

::: {.examplesolution}
To answer this question we will use the Coasean benchmark, and Cost--Benefit Analysis.

**Object and counterfactual** The object is a proposed public rule that increases banks' responsibility for losses from BankID fraud (e.g., requiring banks to reimburse customers more often). The counterfactual is private ordering: banks and customers remain free to allocate fraud risk through terms and pricing of digital banking services, with minimal government intervention.

**Incentives and behavioral responses** Under the Coasean benchmark, voluntary contracts can be treated as evidence of efficiency when (i) agreements are truly voluntary, (ii) both parties are sufficiently informed and understand the terms, and (iii) relevant costs are not pushed onto outsiders. A Coasean intuition applies: if rights and liability are well-defined and tradeable and transaction costs are close to zero, the parties can bargain to a Pareto-efficient risk allocation (for example, customers who prefer low fees accept more fraud risk; customers who value protection pay for it).

If these conditions fail, private contracts may not deliver the efficient level of fraud prevention. A key mechanism is that liability affects who has the strongest incentive to invest in anti-fraud measures. If banks bear more of the loss when fraud succeeds, they have stronger incentives to invest in security design, monitoring, and friction-reducing but protective authentication; if customers bear most losses, banks may underinvest from a social perspective even if customers "agreed" in standard terms.

A simple illustration: suppose better security costs the bank 10 per customer per year and reduces expected fraud losses by 50. If customers are left bearing the loss, the bank may not find it privately profitable to spend 10 (it can keep fees low and let customers absorb the 50). If the bank must reimburse, the bank now saves an expected 50 by spending 10, so it invests. This is an internalization logic: shifting responsibility can move behavior toward the efficient precaution level when the bank is the low-cost avoider.

**Transaction costs and private ordering** Even if tailoring would be efficient in theory, Coase-style bargaining can be blocked by transaction costs and information problems. Individualized contracting is costly because banks serve many customers and would need to segment contracts: tech-savvy/low-risk customers could efficiently bear more responsibility, while elderly/less digital customers might efficiently be protected by the bank. In practice, asymmetric information makes such sorting difficult.

A related problem is adverse selection. A customer who insists on strong fraud protection may thereby signal that they are high-risk, leading the bank to set a high price for protection. Then some moderate-risk customers who would be efficient to cover may opt out because the price reflects the pool's risk, not their own. When this happens, private ordering can produce too little coverage and too weak incentives to invest in prevention. In such settings, a mandatory "standard contract" (a default or non-waivable rule) where banks bear more responsibility can be efficiency-enhancing even though individualized contracts could dominate in a frictionless world.

**Real costs and benefits**

-   **Fraud losses (expected harm):** Regulation that makes banks responsible can reduce expected losses if it induces more effective prevention, faster detection, and better account controls; without liability, banks may tolerate higher expected harm because customers absorb it.
-   **Precaution and compliance costs:** Banks may incur higher real costs from stronger authentication, monitoring, customer support, and fraud-response systems; customers may also face more friction (time, failed transactions) if security tightens.
-   **Administrative and enforcement costs:** Public rules can require supervision, complaint handling, and dispute resolution; banks may incur operational costs to document compliance and process reimbursements.
-   **Misallocation from distorted consumer choice:** If customers cannot evaluate security quality or contract terms, they may choose banks based on price while underweighting fraud risk, leading to inefficiently low demand for security and therefore inefficiently low supply.
-   **System-wide trust and usage benefits:** If reimbursement rules sustain trust in digital banking and payments, society can avoid real costs from reduced digital participation (e.g., reverting to slower/manual methods, extra verification steps across the economy).

Any reimbursements, fines, or damages are largely transfers between banks and customers and are not counted as real resource costs or benefits; their importance here is that they change incentives to prevent fraud and to take care in authentication and customer communication.

Whether the benefits exceed the costs depends on (a) how responsive banks' security investment is to increased responsibility, (b) how large the incremental prevention effect is relative to added compliance/friction costs, and (c) whether banks can reduce fraud at lower real cost than individual customers can through vigilance and self-protection.

**Conditional conclusion** Public regulation that increases banks' responsibility for BankID fraud is most plausibly justified when private ordering is unlikely to be reliably efficient: customers have limited information and understanding of security quality and contract terms, transaction costs and asymmetric information block efficient tailoring (including adverse selection in "buying" protection), and fraud has important third-party effects through reduced trust in digital payments that banks do not fully internalize. By contrast, if customers are well-informed, can compare banks' security and liability terms, and can cheaply contract for the preferred mix of price and protection without spillovers to outsiders, the Coasean benchmark points toward leaving responsibility allocation to contract and competition, since intervention would mainly add compliance and service-cost increases without offsetting behavioral gains.
:::
:::

::: {.examquestion data-question-id="cross_cutting-carbon-capture-subsidy-efficiency"}
The cement company NordCem AS plans to install a carbon capture system at its plant in southern Norway to meet increasingly strict emission targets. NordCem has signed a letter of intent with CleanCarbon Technologies AS, a Norwegian technology company specializing in CO2 capture solutions for industrial applications.

The system promises to capture around 400,000 tonnes of CO2 per year---roughly 50% of NordCem\'s current emissions---using an amine-based chemical process.

An employee at NordCem AS criticizes the government\'s large subsidies for carbon capture and says:

\"I don\'t really understand the government\'s thinking. They are spending billions to subsidize carbon capture here, but we don\'t get any support if we want to cut emissions in other, much cheaper ways---like switching fuels or producing different types of cement.\"

Under what conditions is the employee right to worry that subsidizing carbon capture---rather than supporting emissions reductions more generally---leads to an inefficient use of public resources? Discuss using economic theory.

::: {.goodanswer}
A good answer should use Cost--Benefit Analysis. Good answers could also draw on the Legal Incentives Model to explain how a targeted subsidy changes NordCem's private choice of abatement method relative to a technology-neutral policy. The core comparison is whether public spending buys the largest feasible CO$_2$ reduction (or other social benefits) per krone, given that real resource costs---not the subsidy transfer itself---determine efficiency. Strong answers make clear that the employee's concern is strongest when cheaper abatement options exist at the same firm (or sector) and a carbon-capture-only subsidy crowds those options out. They also identify conditions under which carbon capture could still be efficient because it produces additional benefits beyond the immediate emissions reduction, such as reducing future abatement costs through learning or overcoming investment frictions.
:::

::: {.examplesolution}
To answer this question we will use Cost--Benefit Analysis and the Legal Incentives Model.

**Object and counterfactual** The object is a targeted subsidy that covers NordCem's costs of installing and operating carbon capture. The relevant counterfactual is a technology-neutral subsidy that pays for CO$_2$ abatement regardless of method (fuel switching, different cement types, or capture), so that NordCem can choose the least-cost way to reduce emissions.

**Incentives and behavioral responses** Under the Legal Incentives Model logic, a subsidy changes the firm's private payoff by reducing the private cost of the subsidized action. If carbon capture is subsidized but other abatement is not, NordCem is pushed toward carbon capture even when it is not the lowest real-cost way to cut emissions. A technology-neutral subsidy instead preserves the incentive to pick the cheapest available abatement method (or mix of methods), because NordCem can apply support to whichever option reduces emissions at the lowest real resource cost.

A simple illustration (from the prompt's assumptions) shows the mechanism. If carbon capture costs 1,500 NOK per tonne and fuel switching costs 500 NOK per tonne, then with a fixed subsidy budget of 1.5 billion NOK:

-   Targeted carbon-capture subsidy buys $1.5 \text{ billion} / 1{,}500 = 1{,}000{,}000$ tonnes CO$_2$ abatement.
-   Technology-neutral subsidy can buy $1.5 \text{ billion} / 500 = 3{,}000{,}000$ tonnes CO$_2$ abatement (if the cheaper measures are available at that scale).

If the main benefit is the emissions reduction itself, the technology-neutral policy generates larger benefits for the same public spending because it delivers more tonnes abated.

**Real costs and benefits**

-   **Real abatement (resource) costs:** A capture-only subsidy steers spending toward a higher-cost abatement technology (1,500 NOK/tonne in the example) rather than lower-cost measures (500 NOK/tonne). This raises the real resource cost per tonne abated relative to a technology-neutral policy that can fund the cheapest reductions first.
-   **Climate benefits from abatement:** The benefit of reduced CO$_2$ is increasing in total tonnes reduced. Holding the benefit per tonne fixed, a policy that achieves 3,000,000 tonnes rather than 1,000,000 tonnes yields larger total benefits.
-   **Administrative and implementation costs:** Targeted programs can require specialized monitoring of eligible equipment and performance; technology-neutral programs may require measurement of abatement across heterogeneous methods. Whichever approach has lower measurement/administration costs (for the same integrity) is preferred on this margin.
-   **Additional dynamic benefits (if present):** A capture subsidy could generate real benefits beyond current abatement, such as knowledge spillovers that reduce future capture costs (making later abatement cheaper) or accelerating deployment that would otherwise be delayed. These benefits can offset higher current resource costs.

Transfers note: subsidy payments themselves are not real resource costs; they matter because they change private incentives and therefore behavior.

**Conditional conclusion** The employee is right to worry about inefficiency when (i) there exist substantially cheaper abatement options (like fuel switching) that could have delivered the same emissions reductions at lower real cost, (ii) those options are scalable for NordCem (or in the relevant sector) within the policy's budget, and (iii) carbon capture does not generate significant additional benefits beyond the tonnes abated. In that case, a technology-neutral abatement subsidy dominates because it achieves more emissions reduction per krone and therefore higher total surplus for a given public budget.

Conversely, subsidizing carbon capture rather than general abatement can be efficient if carbon capture delivers extra benefits not captured by "tonnes today," such as large knowledge spillovers that lower future abatement costs, or if (despite higher unit costs) capture is the only practical way to achieve a needed level of reductions because other methods are limited, risky, or blocked by high upfront costs and liquidity constraints under a technology-neutral scheme.
:::
:::

::: {.examquestion data-question-id="cross_cutting-electricity-export-cables"}
NordEnergi AS er en mellomstor strømleverandør som selger kraft til både husholdninger og bedrifter. I 2024 opplevde selskapet store svingninger i strømprisene som følge av økt eksport, varierende tilsig til vannmagasinene og uforutsigbare værforhold. Flere kunder og industribedrifter mener prisene har vært urimelig høye, og det har oppstått en debatt om hvorvidt dagens markedsmodell for strøm fungerer etter hensikten.

Videre vurderer regjeringen å stanse utbygging av flere utenlandskabler for strømeksport, etter press fra industri og husholdninger som mener kablene har bidratt til høye strømpriser i Norge. Er dette en god idé? Diskuter ved hjelp av økonomisk teori.

::: {.goodanswer}
A good answer should use Cost--Benefit Analysis. Good answers could also draw on Market power. The analysis identifies the policy object (a stop in building additional export cables) and compares it to the baseline of continued integration with foreign markets. It then explains how cables change price formation and behavior: they expand arbitrage, link Norwegian prices more tightly to foreign scarcity, and change incentives for consumption, investment, and security of supply. A strong answer distinguishes transfers (higher/lower prices shifting surplus between consumers and producers) from real resource effects such as gains from trade, blackout risk, inefficient industrial shutdowns, and investment distortions. The conclusion is conditional on facts like how often Norway is import-constrained, how valuable the import option is in dry years, and whether market power or other frictions prevent the market model from working well.
:::

::: {.examplesolution}
To answer this question we will use Cost--Benefit Analysis, and (where relevant) Market power.

**Object and counterfactual** The object is a government decision to stop building additional foreign cables for electricity export. The relevant counterfactual is to allow further cable expansion, so Norway becomes more connected to neighboring markets and can both export more in surplus periods and import more in deficit periods. The policy question is not whether prices change, but whether the change increases total economic surplus once behavioral responses and real resource costs are included.

**Incentives and behavioral responses** More cable capacity tightens the link between Norwegian and foreign prices. When foreign prices are higher, the ability to export increases the opportunity cost of selling domestically, so domestic prices can rise; when Norway is short (e.g., low reservoir inflow), cables also allow imports that can limit extreme scarcity prices or even prevent rationing. Stopping cables weakens these arbitrage forces.

Behavioral responses matter:

-   Consumption: Higher prices (from more integration in tight periods) induce conservation and shifting of use to off-peak/low-price periods; stopping cables blunts those incentives and can raise consumption in scarce periods.
-   Production and investment: If producers expect better export opportunities, they have stronger incentives to maintain capacity and invest; stopping cables can reduce expected returns to such investments, potentially lowering future supply resilience.
-   Risk allocation: Cables can increase exposure to foreign price shocks, but also provide an "insurance" margin via imports in dry years. A cable stop reduces that insurance.

A simple numerical illustration clarifies transfers versus real gains from trade. Suppose producing 1 MWh costs 40. Domestic customers value it at 50, while foreign buyers value it at 80. Without export capacity, the MWh stays at home: surplus is $50-40=10$. With export capacity, exporting creates surplus $80-40=40$. Domestic customers lose the 10 surplus they would have gotten, but society gains 40 instead; net surplus rises by 30 (and the higher domestic price is mainly a transfer from domestic buyers to sellers). This is the core efficiency case for allowing trade, even though some domestic customers face higher prices.

**Real costs and benefits**

-   Gains from trade: Allowing exports when foreign willingness to pay exceeds domestic willingness to pay increases total surplus; stopping cables foregoes these gains.
-   Security of supply / shortage risk: Cables provide import capacity in deficit periods. Stopping expansion can increase the expected real harm from shortages (lost load, production stoppages), especially in "dry year" states.
-   Investment and maintenance incentives: Greater market access can strengthen incentives to invest in generation, storage flexibility, and grid reliability. A cable stop may reduce these incentives and raise long-run real costs (e.g., more expensive domestic backup solutions).
-   Volatility and adjustment costs: Greater integration can increase price volatility in Norway. Volatility creates real adjustment costs for some actors (e.g., inefficient shutdowns of otherwise productive industrial capacity, costly emergency adaptation). A cable stop may reduce some of these volatility-related costs, but at the expense of less import insurance.
-   Environmental and system-operation costs: If less trade forces more domestic high-cost/low-flexibility adjustments in tight periods, system operation can become more resource-intensive. Conversely, if exports lead to more domestic production in periods where it is socially costly (e.g., water value in reservoirs), that can be a real cost; the sign depends on system conditions.
-   Administrative and political economy costs: Intervention can create ongoing costs of regulation and lobbying over exceptions, allocation rules, or accompanying price measures.

Higher domestic prices due to cables are largely transfers from consumers to producers and do not themselves constitute a net social cost, but they can matter indirectly if they cause real production losses (e.g., inefficient industrial shutdowns) or if risk-sharing markets are incomplete.

Overall magnitude depends on how often Norway is constrained by domestic scarcity versus having surplus, and on how valuable the import option is in extreme states. If a cable stop materially increases the probability or severity of shortages, the expected real cost can be large.

**Market power and competitive constraints** If domestic producers have market power in tight periods, additional interconnection can act as a competitive constraint by bringing in imports and disciplining price-setting. In that case, stopping cables can increase the scope for market power and raise real misallocation (too little consumption by high-value users or inefficient rationing). If instead foreign markets are the source of market power (e.g., constrained import routes into a broader region), more integration may import those distortions; then the case for more cables is weaker. Which direction dominates is an empirical question about where competitive constraints are strongest.

**Conditional conclusion** A stop in building additional export cables is a good idea only under conditions where the real costs created by further integration (e.g., large volatility-induced shutdown costs, or importing market power/distortions) are likely to exceed the real gains from trade and the security-of-supply benefits of import capacity. If, as is often the case, higher prices mainly reflect scarcity and trade opportunities rather than pure market failure, then stopping cables mainly converts a surplus-increasing trade margin into a politically attractive but inefficient price reduction (a transfer), while increasing long-run scarcity risk and weakening investment incentives. The conclusion therefore turns on (i) the frequency and severity of scarcity states, (ii) the ability of households and industry to adjust/hedge, and (iii) whether market power or other frictions prevent prices from reflecting real scarcity.
:::
:::

::: {.examquestion data-question-id="cross_cutting-electricity-price-subsidies"}
NordEnergi AS is a medium-sized electricity supplier selling power to both households and businesses. In 2024, the company experienced large fluctuations in electricity prices due to increased exports, varying inflows to hydropower reservoirs, and unpredictable weather conditions. Several customers and industrial companies believe prices have been unreasonably high, and a debate has emerged about whether the current market model for electricity is working as intended.

As many struggle with high electricity prices, the government is considering introducing price support for households (\"electricity support\"), where the state covers part of the bill when the market price exceeds a certain level. Using economic theory, explain how such a scheme would affect price, quantity, and overall welfare in the electricity market. Discuss whether electricity price support is a good solution to the problem.

::: {.goodanswer}
A good answer should use Cost--Benefit Analysis. Good answers could also draw on the Legal Incentives Model to describe how a price support scheme changes households' incentives to conserve electricity when scarcity drives the market price up. The analysis identifies the policy object (state coverage of part of the bill above a threshold) and compares it to a baseline where consumers face the full market price. It explains how the subsidy wedges the consumer's marginal price away from the social marginal cost reflected in the market-clearing price, affecting both consumption and the price that clears the market. It then evaluates whether the distributional relief is achieved at the cost of higher real resource costs (more expensive generation/imports, weaker demand response, and administrative/enforcement costs), and states a conclusion that depends on market tightness, supply elasticity, and how well targeted the support is.
:::

::: {.examplesolution}
To answer this question we will use Cost--Benefit Analysis, supplemented by the Legal Incentives Model.

**Object and counterfactual** The object is a household "electricity price support" scheme where the state pays a share of the bill when the market price exceeds a threshold. The counterfactual is no support: households pay the full market price and therefore internalize scarcity through their usage decisions.

**Incentives and behavioral responses** The key mechanism is that the scheme lowers the marginal price households face when the market price is high. This weakens the incentive to reduce consumption in high-price (scarce) periods. In Legal Incentives Model terms, the policy reduces the "sanction" from consuming in scarcity: the household's private cost of an extra kWh is no longer the full market price but the subsidized price.

Two market outcomes follow.

1.  **Quantity:** When the consumer-facing marginal price is lower, households demand more electricity than they would at the full market price (less conservation, less shifting of consumption to off-peak).
2.  **Price that clears the market:** Because total demand is higher at any given market price, the market-clearing price tends to rise, especially when supply is tight in the short run (capacity constraints, limited import availability, hydropower constraints). A higher market price means the subsidy also becomes more expensive for the state and can raise prices paid by non-covered consumers (e.g., firms) if they are not included in the support.

A simple illustration: Suppose the market price in a scarcity hour is 2 NOK/kWh. The scheme covers 50% of the price above 1 NOK/kWh, so the household pays $1 + 0.5(2-1)=1.5$ NOK/kWh. The household therefore treats consumption as if electricity were 1.5 NOK/kWh, not 2. Relative to the counterfactual, more kWh are consumed in the very hours when the system is most costly to supply. If the system is tight, the extra demand pushes the market-clearing price above 2 NOK/kWh, raising both the fiscal cost and the resource cost of meeting demand.

**Real costs and benefits**

-   **Reduced expected harm from high bills (risk of non-payment, severe cutbacks in essential consumption):** The scheme can reduce real hardship costs for liquidity-constrained households by smoothing extreme price spikes and preventing inefficiently large reductions in other essential spending.
-   **Higher real production and procurement costs in scarcity periods:** Because the subsidy reduces demand response, more electricity must be produced/imported precisely when marginal supply is expensive (costly imports, activation of higher-cost generation, or using scarce water with an opportunity cost for later periods).
-   **Misallocation from weakened conservation and load shifting:** The policy encourages consumption in high-cost hours and reduces incentives to invest in efficient appliances, insulation, or demand response. This is a real efficiency loss when the market price is a useful scarcity signal.
-   **Administrative and implementation costs:** Metering, billing integration, eligibility rules, and verification generate real resource costs.
-   **Risk of non-price rationing or reliability measures when supply is fixed in the short run:** If physical supply cannot expand in peak scarcity, higher subsidized demand increases the need for costly rationing arrangements or emergency measures.

(Transfers are central for incentives but are not real resource costs: the subsidy payment itself largely reallocates money from taxpayers to electricity consumers and, indirectly via higher market-clearing prices, to producers.)

Whether the efficiency costs dominate depends strongly on the supply situation. When supply is very inelastic (typical in the short run), the main effect of the subsidy is to raise the market-clearing price and shift money, while also increasing costly consumption in the tightest periods. When supply is more elastic (more available imports/generation), quantity expands more, but then the added kWh come with real marginal cost that must be compared to the consumers' additional value from those kWh.

**Conditional conclusion** Electricity price support can be a reasonable tool for protecting households against extreme price spikes if (i) the main policy objective is distributional relief or hardship reduction, (ii) the scheme is tightly targeted to households with high marginal utility of income and limited ability to adjust, and (iii) it preserves at least some marginal price signal so that consumption still falls when electricity is truly scarce. It is less attractive as a general solution to "high prices" when the underlying problem is scarcity, because lowering the consumer-facing marginal price reduces conservation and tends to increase the market-clearing price and real supply costs. If the market is competitive and prices mainly reflect scarcity, broad price support trades short-run bill relief for weaker efficiency. If instead prices are elevated by limited competition or other frictions, the same subsidy risks being captured by producers through higher market-clearing prices, making it an especially costly way to help households.
:::
:::

Designing Good Contracts {#designing-contracts}
------------------------

::: {.chapterorientationbox}
**Foundations used:**

-   [Cost--Benefit Analysis](#cba)
-   [Transaction Costs](#transaction-costs)
-   [Information, Evidence, and Verifiability](#information-verifiability)
-   [Risk Aversion](#risk-aversion)

**Learning goal:** apply cost--benefit analysis to the design and interpretation of contractual clauses under real-world constraints.
:::

**Types of Questions You Should Be Able to Answer**

::: {.questionblock}
-   Should clause X be included in the contract?
-   How should an incomplete contract be interpreted by courts?
:::

::: {.activationquestion data-activation-id="designing-contracts-prereq" data-activation-type="radio"}
Only the costs and benefits to the decision-maker

Only the costs and benefits that can be easily measured in monetary terms

All real resource costs and benefits, regardless of who bears them

Only the costs and benefits that occur within the first year

Correct! Cost--benefit analysis includes all real resource costs and benefits (production, effort, harm prevented, etc.) regardless of who bears them. Pure transfers between parties are excluded because they don\'t affect total surplus---they just redistribute existing resources.

Not quite. Cost--benefit analysis aims to measure total surplus, which requires including all real resource costs and benefits to all parties. Pure transfers (payments from one party to another) don\'t affect total surplus and should be excluded.
:::

Many of the most important economic transactions in modern economies are governed by complex contracts. Mergers and acquisitions, large construction and infrastructure projects, shipping and energy contracts, and long-term supply agreements often involve large investments, multiple parties, and significant uncertainty about future events. Small contractual details can have large economic consequences.

Many students reading this book will find themselves working on such contracts, whether as managers, advisors, consultants, lawyers, or regulators. Even when contracts are drafted by legal specialists, business decisions about risk allocation, incentives, and enforcement play a central role in shaping their content. Understanding contracts therefore requires more than knowing legal doctrine; it requires understanding how contractual terms affect behavior and outcomes.

These contracts often run to hundreds of pages and include detailed provisions on liability, payment, termination, delay, force majeure, warranties, and dispute resolution. Law and economics provides a way to cut through this complexity. By focusing on incentives, information, and risk, it offers a simple framework for thinking systematically about why contracts are written the way they are and how they can be improved.

This chapter uses economic reasoning to analyze how contractual clauses allocate risk, create incentives, and deal with uncertainty. The goal is to evaluate contract terms using economic efficiency as a benchmark, while accounting for incentive, information, and enforcement constraints. The aim is not to teach contract drafting, but to provide a general method for assessing whether contractual clauses are likely to work well in practice.

Once you understand the logic developed in this chapter, you should be able to analyze almost any contractual clause using economic theory and assess whether it is likely to work well in practice. This is also how contract problems are assessed in this course: on the exam, you are expected to analyze an unfamiliar contract clause using the analytical method developed here.

::: {.activationquestion data-activation-id="designing-contracts-prediction" data-activation-type="radio"}
Yes, if the clause causes the contractor to internalize the social cost of delay and choose efficient timing

Yes, because penalties always improve contractor performance

No, because penalties are unfair to contractors who face unexpected difficulties

No, because the cost of delay should be borne by the buyer who benefits from timely completion

Correct! A delay penalty should be included if it aligns the contractor\'s private incentives with the social cost of delay, leading to efficient decisions about timing and effort. The key question is whether the behavioral change induced by the clause increases total surplus. You\'ll learn the systematic framework for analyzing such clauses in this chapter.

Good attempt! The answer depends on whether the clause changes behavior in a way that increases total surplus. This chapter will teach you a systematic method for analyzing contractual clauses by examining their incentive effects, costs, and benefits. Try applying that framework once you\'ve learned it.
:::

### What Does It Mean to Design a \"Good\" Contract?

From a legal perspective, a contract is often understood as a document that specifies rights, obligations, and remedies in the event of breach. From a law and economics perspective, a contract is something more: it is a device for shaping behavior.

The central question in contract design is not only what happens if something goes wrong, but how the contract affects behavior before anything goes wrong. Well-designed contracts encourage the parties to take desirable actions ex ante, such as effort, quality, timing, and information revelation.

### Efficiency as the Guiding Principle of Contract Design

To evaluate whether a contractual clause is good or bad, we need a clear normative benchmark. In this chapter, that benchmark is economic efficiency: does the contract maximize total surplus?

Total surplus is the sum of all benefits generated by the contractual relationship minus all real resource costs. A contractual clause is efficient if it increases total surplus, even if it makes one party worse off before prices, fees, or other transfers are adjusted.

A key implication of this perspective is that efficiency and distribution can be analyzed separately. Transfers between the parties affect who gets what, but they do not affect whether a clause is socially desirable. As long as a clause increases total surplus, the parties can in principle adjust prices or other terms to divide the gains from trade.

This separation allows us to focus on the content of contracts---what clauses should be included---without taking a position on bargaining power, fairness, or legal entitlements. Those considerations matter for distribution, not for efficiency.

Efficiency therefore provides the benchmark for evaluating contractual clauses. The next step is to develop a practical method for determining whether a specific clause increases total surplus.

### Cost--Benefit Analysis of Contract Clauses

Once efficiency is established as the normative benchmark, the next question is how to evaluate whether a specific contractual clause is efficient. The central analytical tool is cost--benefit analysis (CBA).

In contract design, the purpose of cost--benefit analysis is not to decide how much one party should pay the other. Instead, it is to determine whether a clause should be included at all---namely, whether it increases total surplus.

Contractual clauses create value only by changing behavior. They do not generate surplus directly, but by inducing one or both parties to act differently. Cost--benefit analysis makes this logic explicit by tracing how a clause affects real resource costs and benefits through its incentive effects.

At a high level, a cost--benefit analysis of a contractual clause asks:

1.  How does the clause change behavior?
2.  What real resource costs does this behavioral change create?
3.  What real resource benefits does it create?

A clause is efficient if the benefits from the induced behavioral changes exceed the associated costs.

Pure transfers between the parties should be ignored. If a clause merely shifts money from one party to the other, this affects distribution but not efficiency.

Finally, cost--benefit analysis must be applied to how a clause works in practice. Incentive effects depend on information, observability, and enforcement. The relevant question is therefore not whether a clause would be efficient in an idealized setting with perfect information and enforcement, but whether it increases total surplus given the institutional constraints under which it operates.

### Efficient Allocation of Tasks and Risks

A central problem in contract design is how to allocate tasks, risks, and responsibilities between contracting parties. Different allocations can lead to very different real resource costs, even when contracts are clear and enforceable.

From an economic perspective, efficient contract design assigns tasks and risks to the party that can carry them out or bear them at the lowest total cost. Throughout this book, we refer to this idea as the efficient allocation principle.

For practical purposes, the principle can be stated as a simple question:

> Who can reduce the relevant cost---through lower direct expense, better control, or improved behavior---at the lowest total cost?

This principle applies both to productive tasks and to the management of risks. When risks are controllable, efficiency favors assigning responsibility to the party best placed to influence outcomes. When risks are uncontrollable, contracts may trade off incentives against risk bearing, leading to partial rather than full allocation.

The efficient allocation of tasks and risks provides a unifying lens for analyzing many contractual clauses. The specific mechanisms through which contracts implement this principle are examined in the examples and applications that follow.

### Asymmetric Information

The analysis so far has assumed that relevant information about costs, risks, and behavior is effectively shared between the parties. In many contracts, however, one party knows more than the other---either before the contract is signed or after it is performed.

Asymmetric information does not prevent contracting, but it creates incentive problems that can distort behavior and reduce total surplus. The two canonical cases are adverse selection (private information before contracting) and moral hazard (hidden actions after contracting).

From a law and economics perspective, contractual clauses such as warranties, guarantees, disclosure obligations, and cost-sharing rules are best understood as responses to these problems. Their purpose is not to eliminate informational asymmetries, but to manage their consequences.

As elsewhere in this chapter, the relevant question is whether such clauses increase total surplus. The answer depends on a cost--benefit analysis of how they change behavior: improved incentives or information revelation must be weighed against costs such as weaker effort incentives, distorted choices, or reduced insurance.

Efficient contracts therefore often rely on partial rather than full insurance, or on imperfect screening and disclosure mechanisms. The specific tools used, and the trade-offs they involve, are examined in the examples that follow.

> Efficient contracts do not eliminate asymmetric information; they manage its consequences by using clauses whose incentive benefits outweigh their incentive costs.

### Verifiability and Enforcement

Efficiency provides a benchmark for what parties would like to achieve through a contract. Whether those goals can be achieved in practice, however, depends on limits of verifiability and enforcement.

A contractual clause can condition rights, obligations, or remedies only on facts that a court can verify using admissible evidence. Incentive effects therefore depend not only on what the parties observe, but on what can be proven ex post.

Many economically relevant variables---such as effort, care, diligence, or intent---are observable to the parties but difficult to verify in court. Anticipating this, contracts often avoid conditioning directly on such judgments.

Instead, contracts rely on verifiable proxies: delivery dates, quantities, documented procedures, certifications, test results, or other measurable milestones. These proxies are imperfect, but enforceable.

From an economic perspective, efficient contract design therefore trades off precision against enforceability. A coarse but verifiable clause may dominate a more precise clause that cannot be reliably enforced.

The role of verifiability is not to change the efficiency benchmark, but to constrain which incentive schemes can be implemented in practice. These constraints play a central role in evaluating contractual clauses and are examined further in the examples that follow.

> Efficient contract design trades off precision against enforceability, using verifiable proxies when direct conditioning on behavior or intent is not feasible.

### A General Recipe for Analyzing Contract Clauses {#contract-clause-recipe}

Most contract-law questions ask whether a particular clause should be included. A good answer follows a simple comparative logic.

1.  **Clause and counterfactual:** State the clause under consideration and the relevant counterfactual contractual arrangement it is compared to (the baseline).

2.  **Key assumptions:** State the key assumptions that are relevant for the analysis.

3.  **Incentive and behavioral effects:** Explain how behavior differs between the clause and the baseline (including whether a contract is made), under the stated assumptions.

4.  **Welfare effects:** Compare total surplus with and without the clause, focusing on real resource costs and benefits rather than transfers.

5.  **Verifiability:** Assess whether the clause can work in practice given what courts can verify.

6.  **Conditional conclusion:** Conclude whether the clause increases total surplus relative to the baseline, and under which assumptions this result holds. If the clause increases total surplus, it should be included, since the contract price or other transfers can in principle be adjusted to make both parties better off.

This structure is intentionally generic and reused verbatim in example solutions.

### Common Pitfalls When Analyzing Contract Clauses {#contract-pitfalls}

The recipe above describes how contract clause analysis **should** be done. In practice, exam answers tend to fail in a small number of predictable ways.

Many of these mistakes are special cases of the general pitfalls discussed in Common Pitfalls When Using CBA. However, contract clause questions pose a distinctive **design problem**: choosing among alternative private instruments under enforcement and verifiability constraints. As a result, some pitfalls occur with particular frequency and are worth flagging explicitly here.

1.  Ignoring verifiability

    Students often propose clauses that look efficient on paper but cannot work in practice because courts cannot verify the relevant facts.

    A clause conditioning on concepts such as "best efforts", "good faith", or "high-quality performance" may be ineffective if effort or quality is not verifiable. If a court cannot tell whether the condition has been met, the clause will not change behavior and therefore cannot improve efficiency.

    Always ask whether the clause can be enforced given informational and evidentiary constraints.

2.  Treating transfers as costs or benefits

    Many contract clauses change who pays whom, when, or under which circumstances. A common mistake is to treat the payment itself as a social cost or benefit.

    Transfers between the contracting parties cancel out in a welfare analysis. What matters is whether the clause changes behavior in ways that affect total surplus---for example by improving incentives, reducing risk-bearing costs, or avoiding inefficient breach.

3.  Ignoring behavioral responses

    Contract clauses change incentives, and parties respond.

    A penalty clause may reduce breach, but it may also discourage contract formation if it makes the contract too risky for one party. A warranty may improve product quality, but it may also raise costs and prices.

    Strong answers trace through **all** relevant behavioral effects, including participation, effort, precaution, and breach decisions.

4.  Confusing efficiency with individual preferences over clauses

    A very common mistake is to argue that because a clause makes one party worse off **in isolation**, that party should oppose the clause.

    This reasoning is incorrect. If a clause increases total surplus, the parties can in principle adjust the contract price or other terms so that **both** parties are better off. The relevant question is therefore not whether a clause hurts one party holding prices fixed, but whether it expands the size of the pie.

    Distributional effects matter for bargaining and acceptance, but they do not determine whether a clause is efficient.

5.  Jumping to conclusions without stating assumptions

    Conclusions about the efficiency of a contract clause almost always depend on assumptions about information, risk attitudes, enforcement, and outside options.

    Weak answers state a bottom-line conclusion ("the clause is good" or "the clause is bad") without explaining what it depends on. Strong answers make key assumptions explicit and briefly note how the conclusion would change if those assumptions fail.

    Being clear about assumptions is often more important than reaching a particular conclusion.

### Breach, Remedies, and Efficient Performance

Contracts specify not only what must be done, but also what happens if it is not done. **Breach** (*kontraktsbrudd*) occurs when a party fails to perform. From a law and economics perspective, remedies matter because they shape incentives before performance decisions are made.

The central question is whether remedies induce efficient performance decisions.

Performance is efficient when the value created exceeds the cost. Breach is efficient when performance would destroy value. An efficient remedy structure should therefore induce parties to perform when performance is efficient and to breach when performance is inefficient.

The standard remedy in contract law is **expectation damages** (*positiv kontraktsinteresse*), which require the breaching party to compensate the promisee for the loss from non-performance. Economically, this forces the promisor to compare the cost of performance with the cost of breach, leading to the logic of efficient breach.

From this perspective, remedies are part of contract design: they specify the cost of non-performance and determine whether parties internalize the consequences of breach.

> Efficient remedies induce performance when it is efficient and breach when it avoids waste.

### Interpreting Incomplete Contracts

Even carefully designed contracts are **incomplete** (*ufullstendige*). It is often too costly or impossible for the parties to specify in advance how every possible contingency should be handled. As a result, courts are frequently asked to interpret contracts that contain gaps, ambiguities, or internal inconsistencies.

From a law and economics perspective, the central question is how contracts should be interpreted in order to promote efficient behavior ex ante.

Contracts may be incomplete for many reasons---uncertainty about future events, high drafting and negotiation costs, limited foresight, or strategic ambiguity. Importantly, incompleteness does not imply failure. Leaving issues unresolved can itself be an efficient choice.

The economic approach to contract interpretation starts from a simple premise: rational parties would like their contract to be efficient. This leads to the following interpretive principle:

> When a contract is incomplete, courts should impute the term that the parties would have agreed to ex ante if they had bargained over the issue.

This principle focuses on efficiency rather than fairness or bargaining power. The court asks which allocation of risk or responsibility would minimize total expected costs, given the parties' positions and available information.

A crucial insight is that judicial interpretation affects incentives before disputes arise. If parties can predict how courts will fill gaps or resolve ambiguities, they will adjust their behavior accordingly. In this sense, contract interpretation is itself a form of contract design.

Interpreting contracts in an efficiency-oriented way therefore serves two functions: it resolves the dispute at hand and shapes incentives in future contractual relationships.

> Judicial interpretation that promotes efficiency today improves contractual behavior tomorrow.

### Assumptions and Robustness {#assumptions .unnumbered html_container_class="structural-section assumptions-section"}

::: {.assumptionbox data-title="Risk Aversion"}
The baseline analysis in this chapter assumes parties are risk neutral (evaluate outcomes based on expected values). When parties are ****risk averse****, efficient contracts trade off incentives against risk-bearing costs. This leads to partial risk allocation rather than full assignment: the party best able to control a risk bears some but not all of it, balancing improved incentives against insurance costs.
:::

::: {.awarenessbox data-title="Insurance and the Incentive–Insurance Tradeoff"}
When parties are risk averse, ****insurance**** is a natural response to contractual risk. By reducing the downside borne by the insured party, insurance lowers risk-bearing costs. However, insurance also weakens incentives to reduce the probability or severity of harm.

For this reason, efficient arrangements rarely rely on full insurance. Instead, insurance contracts typically include:

-   Deductibles (insured bears first €X of loss)
-   Co-insurance (insured bears Y% of loss above deductible)
-   Exclusions (certain risks not covered)
-   Monitoring requirements (insurer can inspect or audit)

These features preserve some exposure to loss, maintaining incentives for care while reducing risk-bearing costs. This illustrates how the incentive--insurance tradeoff created by risk aversion is managed in practice.
:::

### Worked Examples {#worked-examples .unnumbered html_container_class="structural-section worked-examples-section"}

1.  Example 1: Furniture Assembly [[ignore]{.smallcaps}]{.tag tag-name="ignore"}

    ::: {.workedexample data-title="Furniture Assembly"}
    Consider the purchase of a desk sold by a furniture retailer. The seller\'s standard offer is a fully assembled desk delivered to the buyer at a price of 3000. Under this arrangement, the seller assembles the desk before delivery.

    Suppose the seller\'s real resource cost of assembling the desk is 800, using tools and standardized processes. However, shipping and storing an assembled desk is costly: it takes up more space, requires careful handling, and increases transport costs. Assume that storage and delivery costs for an assembled desk are 700.

    Now consider an alternative contractual clause: flat-pack delivery. Under this option, the buyer assembles the desk at home. Suppose the buyer values the time and effort required for assembly at 900. Flat-pack delivery is cheaper to store and transport, with logistics costs of 200.

    Total real resource costs under the two arrangements are therefore:

    -   Assembled delivery: 800 (seller assembly) + 700 (assembled logistics) = 1500
    -   Flat-pack delivery: 900 (buyer assembly) + 200 (flat-pack logistics) = 1100

    Flat-pack delivery reduces total real costs by 400 relative to the seller\'s standard assembled offer. From an economic perspective, this means that offering a flat-pack option can increase total surplus.

    Whether both parties prefer the flat-pack clause depends on the price adjustment. Let $P$ denote the price of the flat-pack option.

    -   The buyer prefers flat-pack if: $$
         P + 900 < 3000 \quad \Leftrightarrow \quad P < 2100.
         $$

    -   The seller prefers flat-pack if: $$
         P - 200 > 1500 \quad \Leftrightarrow \quad P > 1700.
         $$

    There is therefore a range of prices---any $P$ between 1700 and 2100---for which both parties prefer flat-pack delivery. This range exists because flat-pack delivery increases total surplus by 400, and the contract price can be adjusted to divide that surplus.

    The key point is that whether assembly should be included in the contract depends on total real resource costs, not on any single margin in isolation.
    :::

2.  Example 2: Defect Liability [[ignore]{.smallcaps}]{.tag tag-name="ignore"}

    ::: {.workedexample data-title="Defect Liability"}
    In the furniture example, allocating a task affected costs but not behavior. In many contracts, however, allocating responsibility also affects how parties behave. Defect liability provides a simple and important illustration.

    One of the most common problems in contract design is how to ensure adequate quality. In many contractual relationships, one party chooses the quality of performance while another party bears part of the consequences of low quality.

    Consider a contractor who can choose between producing high quality and low quality. High quality requires higher upfront costs but reduces the expected costs of future repairs. Low quality is cheaper to produce but leads to higher expected repair costs.

    If the contractor does not bear the cost of repairs, they have an incentive to choose low quality even when high quality is socially cheaper. Assigning responsibility for defects to the contractor changes this allocation of responsibility and, as a result, changes behavior.

    Suppose:

    -   High quality costs 100 to produce and leads to expected repair costs of 10.
    -   Low quality costs 90 to produce but leads to expected repair costs of 30.

    From a social perspective:

    -   High quality: 100 + 10 = 110
    -   Low quality: 90 + 30 = 120

    High quality is therefore efficient.

    Without defect liability, the contractor compares only production costs and chooses low quality. With defect liability, the contractor internalizes expected repair costs and chooses high quality. Production costs rise by 10, but expected repair costs fall by 20, increasing total surplus.

    Any increase in the contract price to compensate the contractor is a transfer and does not affect efficiency.

    This example also illustrates an important limitation. Some defects arise from factors outside the contractor\'s control, such as poor maintenance after delivery. Efficient contracts therefore limit defect liability to construction defects and leave responsibility for maintenance-related defects with the party who controls maintenance.
    :::

3.  Example 3: Tunnel Construction and Geological Risk [[ignore]{.smallcaps}]{.tag tag-name="ignore"}

    ::: {.workedexample data-title="Tunnel Construction and Geological Risk"}
    Consider a public authority that tenders the construction of a road tunnel. The cost of construction depends critically on underground geological conditions. Before tendering the project, the authority conducts geological surveys and has better information about the likelihood of difficult ground conditions than potential contractors.

    If contractors suspect that the authority\'s information is incomplete or overly optimistic, they may respond by inflating their bids to protect themselves against the risk of unexpected cost overruns. This can lead to inefficiently high prices or, in extreme cases, deter participation altogether. The underlying problem is asymmetric information: the party with better information does not fully bear the consequences of inaccurate or misleading disclosure.

    One contractual response is a clause under which the authority bears the cost of additional excavation or reinforcement if actual geological conditions turn out to be worse than indicated by the survey. By shifting this risk to the informed party, the clause changes incentives before the contract is signed. The authority now internalizes the cost of providing inaccurate information and has stronger incentives to conduct careful surveys and disclose information truthfully. Contractors, in turn, can bid more aggressively when they trust the information provided.

    From a cost--benefit perspective, the benefit of the clause is improved information revelation and reduced bid padding, which can lower expected procurement costs and increase the likelihood that efficient projects are undertaken.

    The clause also imposes costs. By insulating the contractor from geological risk, it weakens incentives for cost control and efficient adaptation once construction begins. Contractors may exert less effort to minimize overruns when additional costs are borne by the authority. As a result, some inefficiencies may shift from the bidding stage to the performance stage.

    Whether the clause increases total surplus therefore depends on a trade-off. It is more likely to be efficient when information asymmetries are severe and inaccurate disclosure would otherwise lead to large bid distortions, and less likely to be efficient when cost control during construction is crucial and largely under the contractor\'s control. This explains why such clauses are often limited in scope, combined with monitoring requirements, or paired with cost-sharing rules rather than providing full insurance against geological risk.
    :::

4.  Example 4: Delay Penalties [[ignore]{.smallcaps}]{.tag tag-name="ignore"}

    ::: {.workedexample data-title="Delay Penalties"}
    Consider a large infrastructure project that must be completed by a target date. Delays impose real social costs, such as traffic congestion and coordination problems for other projects. The contractor controls the pace of work, but the buyer and third parties cannot observe the contractor\'s effort directly. The completion date, however, is observable and verifiable.

    Suppose that delaying completion by one day imposes a social cost of 2 million. Avoiding delay requires additional effort by the contractor.

    Assume the following for the purpose of analysis:

    -   If the contractor finishes on time, the cost of performance is 1,500 million.
    -   If the contractor finishes 100 days late, the cost of performance is 1,450 million.
    -   Each day of delay imposes a congestion cost of 2 million.

    From a social perspective:

    -   Finishing on time costs 1,500 million.
    -   Finishing 100 days late costs 1,450 + (100 × 2) = 1,650 million.

    Timely completion therefore minimizes total social cost.

    Without a delay penalty, the contractor compares only its private performance costs and chooses to finish late, saving 50 million. The costs imposed by delay are borne by others and do not affect the contractor\'s decision.

    Now suppose the contract includes a delay penalty of 2 million per day of delay. The contract price is adjusted so that the expected surplus is shared between the parties.

    Under this clause, delaying completion reduces the contractor\'s performance costs but triggers a penalty equal to the cost imposed by delay. The contractor therefore compares:

    -   the cost of accelerating completion, and
    -   the penalty avoided by doing so.

    With this clause in place, the contractor chooses to finish on time, because delaying would increase total costs. The delay penalty aligns the contractor\'s incentives with the effects of delay on total surplus.`\medskip`{=latex}

    **Force Majeure and Uncontrollable Delay**

    The analysis above assumes that delay is fully under the contractor\'s control. In many real-world projects, some delays are caused by uncontrollable events such as extreme weather, regulatory decisions, or supply-chain disruptions.

    When contractors are risk averse, penalizing delays caused by such events imposes risk-bearing costs without improving incentives. Even if the expected penalty can be priced into the contract, exposing the contractor to penalties for bad luck reduces total surplus by shifting risk to the party least able to insure against it.

    Force majeure clauses respond to this problem by excusing delays caused by specified uncontrollable events. By removing penalties for outcomes that effort cannot influence, these clauses preserve the incentive effects of delay penalties on controllable behavior while avoiding inefficient risk shifting.

    In this sense, force majeure clauses reflect the same economic logic as other contractual responses to moral hazard: incentives should be tied to outcomes that the relevant party can affect, while uncontrollable risk is efficiently allocated or excused.`\medskip`{=latex}

    **Multidimensional Effort**

    The analysis above assumes that the contractor\'s effort affects only the timing of completion. In many real-world projects, effort affects several dimensions at once, such as speed, quality, safety, or future maintenance costs. A delay penalty therefore targets only one margin of behavior: strong incentives to finish quickly may reduce effort along other, unpriced dimensions, increasing costs elsewhere. From a cost--benefit perspective, higher delay penalties strengthen timing incentives but may distort behavior on other margins, which explains why efficient contracts often combine delay penalties with additional clauses---such as defect liability, quality standards, or monitoring---rather than relying on a single high-powered incentive.
    :::

### Takeaways {#takeaways .unnumbered html_container_class="structural-section takeaways-section"}

-   Include a contractual clause if the behavioral changes it induces create real resource benefits that exceed real resource costs (ignore pure transfers between parties)
-   Allocate tasks, risks, and responsibilities to the party that can handle them at lowest total cost (efficient allocation principle / least-cost avoider)
-   Contractual responses to asymmetric information (warranties, guarantees, cost-sharing) trade off improved incentives or information revelation against incentive distortions or reduced insurance
-   Use verifiable proxies when direct conditioning on behavior or intent is not feasible (trade-off between precision and enforceability)
-   Expectation damages induce efficient breach decisions when the breaching party internalizes the harm caused to the other party
-   When interpreting incomplete contracts, impute the term that minimizes total expected costs (typically assigns responsibility to the least-cost avoider)

### Exam Questions {#exam-questions-designing .unnumbered html_container_class="structural-section exam-questions-section"}

::: {.examquestion data-question-id="contracts-carbon-capture-liability-clause"}
The cement company NordCem AS plans to install a carbon capture system at its plant in southern Norway to meet increasingly strict emission targets. NordCem has signed a letter of intent with CleanCarbon Technologies AS, a Norwegian technology company specializing in CO2 capture solutions for industrial applications.

The system promises to capture around 400,000 tonnes of CO2 per year---roughly 50% of NordCem\'s current emissions---using an amine-based chemical process. However, the actual capture rate depends on local operating conditions, such as kiln gas composition, temperature stability, and maintenance routines. If capture rates fall below expectations, NordCem risks exceeding its permitted emissions limits and will be required to purchase additional CO2 quotas under the EU Emissions Trading System (EU ETS), potentially at a high market price.

NordCem AS is considering including a clause in the contract stating that CleanCarbon Technologies AS must cover any additional CO2 quota costs NordCem incurs if the carbon capture system underperforms.

Which factors determine whether including such a liability clause is a good idea for NordCem AS? Discuss using economic theory.

::: {.goodanswer}
A good answer should use Cost--Benefit Analysis. Good answers could also draw on Adverse selection. The key determinants are whether shifting quota-cost liability to the technology supplier improves real outcomes by moving performance incentives and risk to the party that can prevent underperformance at lowest real cost, versus creating distorted incentives if performance depends on the cement plant's operations and maintenance. Strong answers identify how the clause screens or disciplines a supplier who may have private information about true expected capture rates, and how credibility is affected by the supplier's willingness to accept liability. They also recognize that enforceability turns on whether "underperformance" and its causes can be verified, and that better-targeted split-liability clauses may dominate a simple blanket promise.
:::

::: {.examplesolution}
To answer this question we will use Cost--Benefit Analysis, and Adverse selection.

**Object and counterfactual** The object is a contract clause making CleanCarbon pay NordCem's additional EU ETS quota costs if the capture system underperforms. The counterfactual is a contract without that clause, where NordCem bears quota costs from underperformance (possibly reflected in a lower contract price).

**Incentives and behavioral responses** The clause changes who internalizes the cost of underperformance. If CleanCarbon expects to pay for quota costs when capture is low, it has stronger incentives to invest in design quality, installation quality, and troubleshooting that improve realized capture. If, instead, the main driver of capture is NordCem's operating conditions (kiln gas composition management, temperature stability, and maintenance routines), the clause can weaken NordCem's incentives to do those things, because NordCem is partly insured against the consequences.

The clause can also address asymmetric information about expected performance. If CleanCarbon knows more than NordCem about the true reliability of the technology under realistic plant conditions, willingness to accept liability (or the price required to accept it) can act as a credibility device: a supplier expecting frequent shortfalls will demand a large price increase or refuse the clause, while a confident supplier can accept at lower added price.

A simple numerical illustration: if quota price is 100 per tonne and underperformance is 50,000 tonnes in a year, the private quota bill is 5,000,000. Assigning that liability to CleanCarbon creates a strong incentive to avoid that shortfall---if CleanCarbon can prevent it cheaply---but is wasteful if the only way to reduce shortfall is costly overengineering while NordCem could have reduced it through low-cost maintenance.

**Real costs and benefits**

-   **Precaution / performance-improvement costs (technology side):** likely increase because CleanCarbon will spend more on robust design, installation, and monitoring to avoid being liable; this is a real resource cost, but it can be efficient if it reduces costly shortfalls.
-   **Precaution / performance-improvement costs (operation side):** may decrease if NordCem becomes less careful in maintenance and operation due to reduced exposure; this is inefficient if NordCem is the low-cost avoider of underperformance.
-   **Abatement-cost efficiency in the ETS system:** if underperformance leads NordCem to buy additional quotas, the real social resource cost is the extra abatement undertaken elsewhere to free up quotas (or the production adjustments needed to reduce emissions). A clause is beneficial if it reduces expected shortfalls and therefore reduces these real abatement/adjustment costs.
-   **Risk of misallocated effort and "wrong-party" incentives:** if the clause makes CleanCarbon bear costs driven by NordCem's behavior, CleanCarbon may respond by excessive engineering, costly monitoring of NordCem, or refusing to contract---real costs that do not improve capture efficiently.
-   **Contracting and dispute costs:** the clause can increase bargaining, monitoring, and conflict costs, especially if parties litigate over whether shortfalls were "underperformance" or caused by NordCem's operation choices.

Quota payments themselves are transfers (NordCem pays another quota holder) and are not counted as real resource costs in the CBA, but they matter for incentives and for how abatement effort is allocated across firms.

**Verifiability and enforcement** The clause works only if underperformance and the triggering condition are verifiable. Measuring actual capture rates can be technically feasible, but attributing a shortfall to (i) technology/installation versus (ii) NordCem's maintenance and operating conditions may be hard to prove to a court. If causation is hard to verify, the clause can generate high dispute costs and weak incentives (because liability becomes unpredictable). This is why a more precise clause may dominate: for example, NordCem pays quota costs attributable to improper maintenance or operation, while CleanCarbon pays costs attributable to technological failure or improper installation---provided those categories can be verified using objective indicators and documentation.

**Conditional conclusion** Including the clause is a good idea for NordCem if (i) CleanCarbon is the party that can reduce expected quota-cost exposure at lowest real cost (through better technology, installation, and performance support), (ii) CleanCarbon has private information about true expected performance and the clause helps screen low-quality suppliers or makes performance claims credible, and (iii) capture performance and causation can be verified at reasonable cost. If instead underperformance is mainly driven by NordCem's own operating and maintenance choices, or if attribution is hard to verify so disputes are likely, the clause can be counterproductive; in that case a tailored, split-responsibility clause that conditions liability on verifiable causes is more likely to increase welfare.
:::
:::

::: {.examquestion data-question-id="contracts-carbon-capture-performance-clauses"}
The cement company NordCem AS plans to install a carbon capture system at its plant in southern Norway to meet increasingly strict emission targets. NordCem has signed a letter of intent with CleanCarbon Technologies AS, a Norwegian technology company specializing in CO2 capture solutions for industrial applications.

The system promises to capture around 400,000 tonnes of CO2 per year---roughly 50% of NordCem\'s current emissions---using an amine-based chemical process. However, the actual capture rate depends on local operating conditions, such as kiln gas composition, temperature stability, and maintenance routines. If capture rates fall below expectations, NordCem risks exceeding its permitted emissions limits and will be required to purchase additional CO2 quotas under the EU Emissions Trading System (EU ETS), potentially at a high market price.

What other types of clauses could NordCem AS include in the contract to ensure that the carbon capture system performs as promised? Explain your suggestions using economic theory.

::: {.goodanswer}
A good answer should use Adverse selection. Good answers could also draw on Moral hazard. The strongest answers identify why NordCem cannot perfectly observe or verify "quality" at signing (true technical capability) and why performance later also depends on choices taken after signing (operation, maintenance, troubleshooting). They then connect specific contract clauses to these problems by showing how clauses either (i) screen or signal quality before commitment, (ii) align incentives during operation by tying payoffs to verifiable outcomes, or (iii) allocate responsibility to the party who can control the relevant margin. Good answers also note that measuring capture performance is itself costly and imperfect, so contract design must balance stronger incentives against monitoring and dispute costs.
:::

::: {.examplesolution}
To answer this question we will use Adverse selection and Moral hazard, focusing on how contract terms can reduce hidden-quality and hidden-action problems that make "performance as promised" hard to guarantee.

**Object and counterfactual** NordCem is choosing contract clauses for a carbon-capture installation. The counterfactual is a simple fixed-price purchase/install contract with no special performance terms, where CleanCarbon is paid largely regardless of realized capture and disputes about causes of underperformance are handled only ex post.

**Incentives and behavioral responses** Because capture rates depend on local conditions and ongoing routines, NordCem faces two related risks.

-   **Hidden quality at contracting (adverse selection):** CleanCarbon may know more than NordCem about how robust the technology is under NordCem's kiln-gas composition, temperature variability, and realistic maintenance constraints. Without safeguards, CleanCarbon can overstate expected performance.
-   **Hidden actions after signing (moral hazard):** After installation, performance depends on effort and care (calibration, maintenance, troubleshooting). If CleanCarbon is paid regardless of performance, its incentive to incur these costly actions is weaker. If NordCem's own operation strongly affects performance, NordCem may also underinvest in the routines that protect capture efficiency unless it bears the consequences.

Clauses that strengthen performance incentives or improve information before final commitment address these problems:

1.  **Performance guarantee (e.g., guaranteed capture efficiency).** If CleanCarbon must stand behind a stated capture level, offering a strong guarantee can act as a **signal of product quality** and reduce adverse selection. A seller with low expected performance expects to pay more under the guarantee and therefore is less willing to offer it on the same terms. The guarantee also reduces CleanCarbon's incentive to "oversell" in the letter-of-intent stage.

2.  **Performance-based payment (pay tied to verified tonnes captured or verified capture rate).** This makes CleanCarbon's payoff increase with the output NordCem cares about, addressing moral hazard by aligning incentives to deliver a working system and to sustain performance (maintenance, adjustments, rapid repair). A simple illustration: if extra maintenance costs CleanCarbon $50$ but increases expected captured CO$_2$ enough to raise its performance payment by $80$, it will do the maintenance; under a fixed price, it would not.

3.  **Testing before final acceptance (independent third-party test before full payment / final handover).** This reduces asymmetric information about system quality at the acceptance stage. A credible test changes bargaining and incentives: CleanCarbon anticipates that low quality will be revealed before final payment, which pushes it toward delivering higher quality and away from strategic delay or "hand-over and hope" behavior.

4.  **Split liability for CO$_2$ quota costs (allocate based on cause of underperformance).** If underperformance is due to system failure, CleanCarbon pays; if due to poor operation by NordCem, NordCem pays. The economic logic is to place consequences on the party controlling the relevant margin. That improves incentives on both sides: CleanCarbon internalizes the costs of design/installation defects it can prevent, and NordCem internalizes the costs of poor routines it can prevent. This reduces wasteful blame-shifting and encourages each side to take the efficient precautions it controls.

5.  **Make CleanCarbon responsible for operation and maintenance after installation.** If CleanCarbon controls operation/maintenance, then performance is more directly "its" choice variable, and strong performance clauses become less problematic because responsibility and control are aligned. This reduces the moral-hazard concern that NordCem's (possibly unobservable) poor operation undermines capture rates while CleanCarbon is still being judged/paid on performance.

**Real costs and benefits**

-   **Expected performance shortfall (real compliance/abatement burden):** Better clauses reduce the expected gap between promised and realized capture, lowering the real resources NordCem must spend to meet emissions constraints (e.g., operational adjustments, additional abatement measures, downtime to fix problems).
-   **Precaution, operation, and maintenance costs:** Performance pay, guarantees, and shifting O&M responsibility can increase real effort and maintenance intensity. These are real costs, but they can be efficient if they prevent larger performance losses.
-   **Monitoring, measurement, and testing costs:** Third-party testing and ongoing verification require engineers, measurement equipment, and administrative effort. These costs rise with more demanding clauses, but they also reduce information problems and disputes.
-   **Dispute and renegotiation costs:** Performance-based clauses and split-liability rules can trigger disagreements about causation (system defect vs. operator behavior), which are real costs (time, experts, delay). Clear metrics and protocols can reduce these costs.
-   **Misallocation risk from distorted incentives:** If the contract puts too much weight on measured capture, CleanCarbon may focus narrowly on what is measured (or on short-run test performance) rather than durable performance, unless the clause is designed to reflect long-run outcomes.

Payments for CO$_2$ quotas (or damages triggered by quota costs) are largely **transfers** between parties or market participants, so they are not counted as real resource costs here. They matter because they shape incentives: making CleanCarbon bear some of the quota-cost consequence increases its incentive to prevent underperformance.

**Verifiability and enforcement** All of these clauses rely on measuring "performance." Capture rates and tonnes captured must be verifiable to avoid turning every underperformance event into a costly dispute. Third-party testing works because it creates a verifiable signal at a defined time. For ongoing performance-based payment or split liability, the contract should specify verifiable metrics (measurement method, sampling frequency, baseline operating conditions, documentation of maintenance routines). If measurement is noisy or manipulable, the expected "sanction" from a guarantee is effectively reduced (lower $p$ that underperformance is established), weakening deterrence and increasing dispute costs.

**Conditional conclusion** If capture performance can be measured and attributed with reasonably verifiable metrics, NordCem should combine (i) a performance guarantee and/or performance-based payment to address hidden quality and hidden effort, with (ii) third-party acceptance testing to reduce information gaps before full commitment. If underperformance is substantially driven by the operator's choices, split-liability rules or assigning operation/maintenance to CleanCarbon becomes important so that responsibility tracks control; otherwise strong performance clauses risk inefficient disputes and risk-shifting. The more expensive or unreliable monitoring is, the more valuable clear testing protocols and simpler, more verifiable triggers become relative to complex causation-based liability.
:::
:::

::: {.examquestion data-question-id="contracts-pharmaceutical-supply-damages"}
You advise Biotech Innovations Ltd., a pharmaceutical firm specializing in developing and manufacturing innovative drugs. They have just innovated a new drug, \"BioCureX,\" a breakthrough treatment for a rare genetic disorder. The active pharmaceutical ingredient required for BioCureX is exclusively supplied by PharmaChem Co. Biotech Innovations is about to sign a long-term supply agreement with PharmaChem. But they are worried that PharmaChem might fail to consistently supply the amount of the ingredient necessary for large-scale production.

The contract will include a clause stipulating the damages PharmaChem should pay Biotech Innovations if it fails to supply the ingredient. How large will you recommend these damages to be? Which factors determine your advice? Explain using economic theory. Pay specific attention to the fact that, after signing the contract, Biotech Innovations will enter into significant investments to expand its capacity to produce the drug and get it approved for commercial sale.

::: {.goodanswer}
A good answer should use Cost--Benefit Analysis. Good answers could also draw on Legal Incentives Model. The core content is an efficiency argument for setting contractual damages at (or close to) expectation damages so that PharmaChem supplies when (and only when) performance is socially worthwhile, rather than too often (inefficient performance) or too rarely (inefficient breach). Strong answers connect that level of damages to the parties' shared interest in maximizing total surplus (the "total pie"), which can then be split through the contract price, and they apply the logic to this case by identifying what counts as Biotech's expectancy loss when supply fails. The best answers also treat Biotech's post-contract investments as a reliance problem: damages that fully insure Biotech against all sunk investments can induce inefficient overinvestment when supply risk is material.
:::

::: {.examplesolution}
To answer this question we will use Cost--Benefit Analysis and the Legal Incentives Model, focusing on how the damages clause shapes performance, breach, and Biotech's post-signing investment incentives.

**Object and counterfactual** The object is a liquidated-damages clause: the amount PharmaChem must pay if it fails to supply the ingredient. The relevant counterfactual is (i) a lower-damages clause (including zero damages) that makes breach relatively cheap, or (ii) a higher-damages clause that makes breach very expensive, even when non-performance would save large real costs.

**Actors and decision margin**

-   PharmaChem chooses whether to perform (supply as promised) or breach (fail to supply) when supply is costly or difficult.
-   Biotech chooses how much to invest after signing (capacity expansion, regulatory approval efforts) given the risk of non-supply and the promised damage payment.

**Incentives and behavioral responses** Expectation damages put Biotech in (approximately) the position it would have been in if PharmaChem had performed. The economic rationale is that setting damages to Biotech's expectancy loss makes PharmaChem internalize the social loss from non-delivery and therefore choose performance versus breach efficiently.

A simple illustration shows why.

-   Let Biotech's value from timely delivery be $V=100$ (e.g., profits from selling BioCureX, net of downstream non-ingredient costs), and let the contract price for the ingredient be $P=40$.
-   Biotech's expectancy from performance is then $V-P=60$. So expectation damages are $D=60$.

PharmaChem compares:

-   Perform: payoff $P-C$, where $C$ is PharmaChem's real cost of supplying.
-   Breach: payoff $-D$.

So PharmaChem performs when $P-C \ge -D$, i.e. when $C \le P + D$. With expectation damages $D=V-P$, that condition becomes $C \le V$, which is exactly the efficiency test (supply when value $V$ exceeds cost $C$).

If damages are too high, PharmaChem supplies even when supply costs exceed the value created (inefficient performance). Example: if $D=120$ and $C=130$, then perform yields $40-130=-90$ while breach yields $-120$; PharmaChem performs even though $C(=130) > V(=100)$. If damages are too low, PharmaChem breaches even when supply is efficient (inefficient breach). Example: if $D=10$ and $C=90$, then perform yields $40-90=-50$ while breach yields $-10$; PharmaChem breaches even though $C(=90) < V(=100)$.

Why both parties would want this: an efficient damages rule maximizes total surplus from the relationship. Because the contract also sets a price $P$, the parties can split the resulting larger surplus between them (a Pareto improvement relative to an inefficient contract). So Biotech should not treat "higher damages" as automatically better; it can shrink the total pie by forcing costly performance in states where breach is efficient.

Investment complication (reliance): after signing, Biotech will make relationship-specific investments (capacity expansion and approval) that are valuable only if the ingredient arrives, especially because PharmaChem is the exclusive supplier. If damages promise reimbursement of all sunk investments whenever supply fails, Biotech can be pushed toward overinvestment: it captures the upside if supply occurs but is insured on the downside if supply fails. Efficient "hypothetical expectation damages" avoid this by compensating only the portion of lost profits and reliance that would have been efficient (surplus-increasing, i.e., Kaldor--Hicks efficient) given the known risk of non-supply and the available alternatives (here, very limited substitution).

**Real costs and benefits**

-   **Biotech's expected lost output (expected harm):** a higher damages clause reduces inefficient breach and thus lowers expected lost production and delayed patient access relative to a low-damages baseline.
-   **PharmaChem's real supply/contingency costs:** higher damages induce PharmaChem to spend more on backup capacity, inventories, quality control, and expedited shipping to avoid breach; these are real resource costs that rise with damages.
-   **Biotech's precaution and planning costs:** if damages are low, Biotech must spend more on contingency planning (e.g., idle capacity, alternative R&D paths, slower scaling) to protect itself from supply risk; expectation damages reduce the need for inefficient "self-insurance."
-   **Inefficient performance or inefficient breach:** damages that are too high create real waste when PharmaChem supplies at cost exceeding the value created; damages that are too low create real waste when breach occurs despite value exceeding cost.
-   **Inefficient investment (over- or under-reliance):** overcompensation of relationship-specific investments can lead to excessive capacity/approval spending that has low expected surplus given breach risk; undercompensation can lead to too little investment and underproduction even when expansion would be surplus-increasing.
-   **Dispute-resolution and administration costs:** more complex, state-contingent damage definitions (e.g., including lost profits, delay, and reliance) can raise measurement, auditing, and litigation costs compared to a simple number.

Transfers (the damage payment itself) are not a real cost in the cost--benefit sense, but the size and design of the transfer matter because they change performance and investment incentives.

Overall, the main trade-off is: raising damages improves performance incentives and protects efficient reliance, but also increases costly precaution by PharmaChem, increases the risk of inefficient forced performance in high-cost states, and can distort Biotech's investment incentives if it becomes "too insured" against supply risk.

**Verifiability and enforcement** Expectation damages require defining and proving what Biotech would have earned with timely supply (lost profits, delay losses, and the extent to which investments become unusable without the ingredient). In practice, some components (e.g., realized sales after approval) may be easier to verify than others (e.g., reputational losses, which should be tied to verifiable real effects like future lost sales or higher financing costs). If key losses are hard to verify, a liquidated amount (or a schedule tied to verifiable milestones such as regulatory stage, capacity installed, or committed sales) can reduce enforcement costs while approximating expectation damages.

**Conditional conclusion** I would recommend damages set to (a practicable approximation of) expectation damages: the amount that makes Biotech as well off as if PharmaChem had supplied, so that PharmaChem performs when $V \ge C$ and breaches when $V < C$. In this case, expectancy should include verifiable lost profits from delayed or foregone BioCureX sales and verifiable downstream losses caused by non-supply, and it may include some relationship-specific investments that become worthless because PharmaChem is the exclusive supplier. However, the damages clause should not automatically reimburse all investments Biotech chooses to make; otherwise Biotech may invest too early or too much given supply risk. A good contractual implementation is therefore "hypothetical expectation damages": compensate reliance only to the extent the investment was efficient given foreseeable non-supply risk (and possibly condition higher damages on verifiable milestones), with the exact level depending on (i) the magnitude and verifiability of lost profits and delay costs, (ii) the degree of supplier exclusivity and Biotech's ability to mitigate, (iii) the likelihood of non-supply and PharmaChem's ability to reduce it through costly precautions, and (iv) enforcement and measurement costs.
:::
:::

::: {.examquestion data-question-id="contracts-startup-damages-uncertain-cost"}
A start-up tech company develops AI-powered apps for its customers. Since the company is low on cash, it prefers to receive half the payment before it starts developing the app. The remaining half of the payment is paid when the company delivers the app to the customer.

A customer requests an app that the company fears could be difficult to develop. To reduce risks, the company wants to have the option to breach the contract and pay damages if the app turns out to be too costly to develop. The company wants to include a term in the contract that explicitly states the amount to be payed in damages in case of breach of contract. How large would you recommend this amount to be? Explain using economic theory.

::: {.goodanswer}
A good answer should use Cost--Benefit Analysis. Good answers could also draw on the Legal Incentives Model. The core content identifies the efficient-performance versus efficient-breach comparison by asking when the customer's valuation exceeds the developer's realized cost, and then explains how a stipulated damages amount shifts the developer's incentives at that margin. Strong answers connect the recommended amount to expectation damages (making the customer indifferent between performance and breach) and show why too-high damages can force inefficient performance when cost is high. The best answers also flag the reliance complication: if the customer makes complementary investments in anticipation of delivery, standard expectation damages may induce excessive reliance, motivating a lower "hypothetical" measure tied to foreseeable, non-excessive reliance.
:::

::: {.examplesolution}
To answer this question we will use Cost--Benefit Analysis and the Legal Incentives Model.

**Object and counterfactual** The object is a contractual term that fixes (liquidates) damages payable by the start-up if it breaches instead of delivering the app. The counterfactual is a contract without such a term (or with a different stipulated amount), so that the start-up's decision to perform or breach is governed by whatever consequences breach creates.

**Actors and decision margin** The key actor is the start-up, which will learn the realized development cost and then choose between (i) performing (developing and delivering the app) or (ii) breaching and paying the stipulated damages. The customer's relevant margin is whether to rely on the promise (e.g., invest in complementary technology) once the contract is signed.

**Incentives and behavioral responses** Use the Legal Incentives Model: after learning the realized cost, the start-up compares the private payoff from performance to the private payoff from breach. Performance creates value for the customer but costs the start-up the realized development cost; breach avoids that cost but triggers the sanction-like payment (damages) to the customer.

Using the numbers in the prompt sketch: the app is worth 120 to the customer. With probability 50% the cost is 80, and with probability 50% the cost is 150. If the cost is 150, performance is not efficient because it is not a Kaldor--Hicks improvement: the customer's gain (120) is below the start-up's real resource cost (150). Efficient behavior in that state is breach.

Therefore, the damages amount should be set so that the start-up performs if and only if realized cost is below the customer's valuation (120). If damages were set above 150, the start-up would be induced to perform even when cost is 150, because breaching would be even more expensive than completing the project. That would force inefficient performance. Even damages of 150 are "too high" in this sense, because they still make breach unattractive in the high-cost state where breach is socially preferred.

Setting damages equal to 120 makes breach privately costly by exactly the customer's lost value from non-delivery. Then the start-up will perform when cost is 80 (since 80 is below 120), and will breach when cost is 150 (since 150 is above 120). This aligns the start-up's decision with the Kaldor--Hicks criterion: produce if and only if value (120) exceeds cost.

This is the logic of expectation damages: damages that put the customer in the position it would have been in had performance occurred, here equal to the customer's valuation of receiving the app (120). With that clause, the contract induces efficient breach and efficient performance, and (because it maximizes total surplus) it leaves more value to be divided between the parties; exactly how they share that gain depends on their bargaining power.

One important complication is reliance. Suppose the customer can invest in complementary technology in reliance on delivery, raising the value of the app from 120 to 140. Standard expectation damages would then suggest damages of 140 upon breach (to make the customer indifferent between performance and damages). But that can be inefficient because it gives the customer too strong incentives to rely: the customer does not internalize that there is a 50% probability the start-up will breach (when cost turns out to be 150). It may be socially efficient for the customer to wait with the complementary investment until delivery is certain.

To correct that reliance incentive, the optimal damages level is "hypothetical expectation damages": the customer is compensated only for the hypothetical harm it would have suffered absent excessive reliance. For example, if it was socially optimal to wait to invest, the customer should receive only 120 in damages (not 140), even if the customer in fact chose to invest and thereby increased its own valuation. In the United States, the doctrine of foreseeability can be understood as implementing this idea by limiting damages to reliance the developer could reasonably expect the customer to undertake.

**Real costs and benefits**

-   **Development (precaution/production) costs:** Paying to develop the app is a real resource cost. The stipulated damages affect whether the start-up incurs the 80 cost (efficient) and whether it inefficiently incurs the 150 cost (inefficient if forced by overly high damages).
-   **Expected value created by performance (benefit to customer):** When the app is delivered, the customer receives value (120 in the baseline; potentially higher with complementary investment). The damages clause affects whether this value is realized in low-cost states and forgone in high-cost states.
-   **Reliance and complementary-investment costs:** If the customer invests in complementary technology, that investment is a real resource cost. Overly high damages (full reliance-based expectation damages when breach is likely) can induce inefficiently early or excessive investment.
-   **Waste from inefficient performance or inefficient reliance:** If damages are too high, the start-up may perform when cost exceeds value (wasteful). If damages are designed without regard to breach probability, the customer may rely too much (wasteful).

Damages payments themselves are transfers between the parties, not real resource costs. They matter because they change incentives: setting damages near 120 tends to avoid the large inefficiency of producing at cost 150 while still protecting the customer against opportunistic breach in the low-cost state.

**Conditional conclusion** If the only margin is the start-up's perform/breach choice after learning cost, the recommended stipulated damages amount is 120 (the customer's valuation), i.e., expectation damages, because it induces performance if and only if realized cost is below 120 and breach otherwise. If, however, the customer can make reliance investments that raise the value of performance (e.g., to 140) and those investments are socially excessive given the chance of breach, then "hypothetical expectation damages" are preferable---e.g., keeping damages at 120 to avoid encouraging over-reliance. The conclusion depends on whether reliance is important in the setting and whether it is efficient for the customer to invest before the start-up's cost uncertainty is resolved.
:::
:::

::: {.examquestion data-question-id="contracts-bareboat-charter-maintenance-responsibility"}
You are an advisor at an international shipping company that is considering entering into a long-term bareboat charter (lease) of a tanker from a shipowner. A \"bareboat\" charter means the vessel is leased without crew or equipment, so the charterer is responsible for operations, including manning, fuel, and all operating costs.

Your manager believes it may be beneficial to include a clause making the shipowner responsible for maintaining the tanker throughout the contract period. Conduct an economic analysis of this proposal. What would you advise your manager?

::: {.goodanswer}
A good answer should use Moral hazard. Good answers could also draw on the Coasean benchmark. The core analysis identifies how shifting maintenance responsibility from the bareboat charterer to the shipowner changes the charterer's incentives to treat the vessel carefully and to report problems early, given that the charterer controls day-to-day operations. It also identifies coordination and monitoring frictions when the party who must maintain the asset is not the party observing wear and tear in real time. Finally, it recognizes that the economic question is not "who pays" in isolation: the parties can (within limits) reprice the charter hire to reflect any risk and cost allocation, so the key issue is which allocation minimizes real resource costs given verifiability and enforcement constraints.
:::

::: {.examplesolution}
To answer this question we will use Moral hazard, and the Coasean benchmark.

**Object and counterfactual** The object is a proposed clause in a long-term bareboat charter making the shipowner responsible for maintenance throughout the contract period. The counterfactual is the typical bareboat allocation where the charterer (who operates the vessel) is responsible for maintenance and bears the operational consequences of poor upkeep.

**Actors and decision margin** Key actors are the shipowner (lessor) and the bareboat charterer (lessee/operator). The relevant margins are (i) the charterer's intensity of use and day-to-day care (how hard the vessel is run), and (ii) maintenance effort and timing (preventive upkeep vs deferral), including how quickly emerging problems are addressed.

**Incentives and behavioral responses** With charterer-responsible maintenance, the charterer internalizes more of the consequences of rough use and delayed upkeep, which tends to create strong incentives to maintain the vessel in a cost-effective way because the charterer directly sees problems and can fix them quickly.

If the owner is responsible for maintenance while the charterer controls operations, a Moral hazard problem can arise. The charterer can gain private operating benefits from "running the ship harder" (higher revenue, lower operational slack) while shifting part of the resulting wear-and-tear costs to the owner. For example, suppose the charterer can earn an extra $B=0.5$ (in arbitrary units) from more intensive use, but this increases expected maintenance/repair needs by $0.8$. If the owner pays for maintenance, the charterer will tend to choose the intensive use (since it captures $0.5$ while not bearing the $0.8$), even though it is socially inefficient.

There can also be a misalignment in maintenance timing and quality. The owner, paying the bill, may prefer cheaper or deferred maintenance if the immediate cost savings are large, while the charterer bears operational disruption (downtime) and safety/reliability risk during the charter period. Even if the owner cares about the vessel's long-run condition and residual value, the owner's incentives need not match the charterer's preference for high uptime and reliability during the contract period.

Finally, making the owner responsible typically requires more back-and-forth: the charterer observes issues and must coordinate approvals, shipyard scheduling, and scope of work with the owner. This can slow responses and increase the likelihood of inefficient delays.

**Real costs and benefits**

-   **Maintenance and repair resource costs:** Owner-responsible maintenance can increase real maintenance costs if the charterer overuses the vessel or takes less care (more breakdowns and heavier wear), compared to charterer-responsible maintenance.
-   **Operating/precaution costs (care in use):** Shifting maintenance away from the charterer weakens incentives for careful operation, increasing real expected wear and accident risk relative to the baseline.
-   **Downtime and disruption costs:** More coordination and slower decisions can increase time out of service and operational disruption costs during the charter period.
-   **Monitoring and coordination costs:** Owner responsibility increases the need to monitor charterer behavior and to coordinate maintenance decisions, creating additional real administrative and organizational costs.
-   **Expected harm from failures/accidents:** If weaker care incentives and delayed maintenance raise the probability of serious incidents, expected harm increases (even if liability transfers do not count as resource costs, the underlying harm does).

Overall, the main efficiency intuition is that the charterer is usually the lower-cost monitor and implementer of day-to-day maintenance because it operates the ship and observes condition continuously. Moving maintenance to the owner tends to raise real costs through (i) weaker care incentives and (ii) higher coordination/monitoring burdens, unless there are specific offsetting advantages (e.g., owner has uniquely low-cost access to maintenance capacity or expertise).

(Any changes in charter hire, reimbursements, or indemnities are largely transfers between the parties; they matter for incentives but are not counted as real costs or benefits.)

**Verifiability and enforcement** A central practical problem is that "proper use" and "adequate maintenance" are often hard to verify to a court. The charterer's operational choices (how intensely the vessel is run) may be observable to the parties but difficult to prove and attribute causally to later maintenance needs. This limits how well the owner can contractually prevent overuse or enforce "care" standards when the owner is on the hook for maintenance. Similarly, if the owner controls maintenance decisions, the charterer may struggle to enforce timely, high-quality maintenance if the contract terms are not tied to verifiable benchmarks. These verifiability limits make the moral-hazard/coordination concerns more severe.

**Transaction costs and private ordering** Under the Coasean benchmark, a voluntary clause allocating maintenance to the owner could be efficient if it reflects joint gains (e.g., the owner truly can maintain more cheaply or reliably). In that case, the parties can adjust the charter hire so that the owner is compensated for expected maintenance costs and the charterer pays for the improved service. But this benchmark is less reliable when transaction costs and information problems are large---here, especially the difficulty of specifying and enforcing verifiable standards for use and maintenance, and the ongoing coordination costs over a long contract period.

**Conditional conclusion** The default economic presumption favors the standard bareboat allocation where the charterer bears maintenance responsibility, because it aligns control (operation and day-to-day observation) with responsibility and reduces moral hazard and coordination costs. The proposed owner-maintenance clause is more attractive only if specific conditions hold---most importantly, that (i) the owner can perform maintenance substantially more cost-effectively than the charterer, and (ii) the contract can credibly limit overuse and ensure timely maintenance using verifiable triggers (or otherwise keep monitoring/coordination costs low). If those conditions do not hold, I would advise against the clause, even though the parties can partially reprice the charter to reflect the allocation, because repricing does not eliminate the underlying incentive and enforcement problems.
:::
:::

::: {.examquestion data-question-id="contracts-bareboat-charter-accident-liability"}
You are an advisor at an international shipping company that is considering entering into a long-term bareboat charter (lease) of a tanker from a shipowner. A "bareboat" charter means that the vessel is leased without crew or equipment, such that the chartering company is responsible for operations, including crewing, fuel, and all operating costs.

During the contract period, accidents may occur, such as collisions, shipwrecks, and groundings. Which factors affect who should bear the costs of such accidents? Explain using economic theory.

::: {.goodanswer}
A good answer should use Moral hazard. Good answers could also draw on Cost--Benefit Analysis. The key is to link accident-cost allocation to which party can most cheaply reduce accident risk (through crewing, maintenance, routing, and safety systems) versus which party is better positioned to bear or diversify residual risk (e.g., via insurance). A strong answer distinguishes operational accidents during the charter from pre-existing defects and normal wear, and explains how liability placement changes incentives to take care and to disclose vessel condition. It also notes that risk allocation will be priced into the charter rate, and that the efficient allocation can depend on verifiability, enforceability, and the functioning of insurance markets.
:::

::: {.examplesolution}
To answer this question we will use Moral hazard, and Cost--Benefit Analysis.

**Object and counterfactual** The object is the contract term(s) in a long-term bareboat charter that allocate the costs of collisions, groundings, and similar accidents between (i) the shipowner/lessor and (ii) the charterer/lessee, who operates the vessel. The counterfactual is an alternative allocation (e.g., owner bears more of the accident losses; charterer bears more; or the allocation is split by cause).

**Incentives and behavioral responses** Because a bareboat charter gives the charterer operational control, accident risk is strongly affected by the charterer's choices: crew quality, training, safety routines, maintenance while operating, routing, speed, and investment in navigation systems. If the charterer does not bear (most of) the accident cost, a moral hazard problem arises: the charterer captures the savings from cutting corners but pushes expected accident losses onto the owner.

A simple way to see the incentive is expected-value reasoning. Suppose "low care" saves the charterer $B=2$ (e.g., cheaper crew and fewer safety routines) but raises the accident probability from $p=0.01$ to $p=0.05$. If the accident cost that must be paid by the responsible party is $S=100$, then the increase in expected accident cost is $(0.05-0.01)\cdot 100=4$. If the charterer bears the loss, low care is not privately attractive ($B < 4$), so the charterer chooses higher care. If instead the owner bears the loss, the charterer compares only the private saving $B$ and will tend to choose low care even when it is inefficient.

By contrast, some accident-related losses are not mainly driven by the charterer's operational choices, especially:

-   latent defects or structural weaknesses that existed before delivery into the charter, and
-   normal wear from ordinary use that is not tied to negligent operation.

For these categories, placing the risk on the owner better aligns incentives: the owner has stronger incentives to invest in seaworthiness before delivery and to disclose known defects, while the charterer cannot efficiently reduce these risks through day-to-day operations.

**Real costs and benefits**

-   **Precaution and compliance costs (crew, routines, equipment):** Allocating operational accident losses to the charterer increases incentives to spend real resources on safety where the charterer is the low-cost risk reducer; allocating them to the owner weakens these incentives and can raise expected accident frequency/severity.
-   **Expected accident harm (repairs, downtime, cargo/third-party harm):** Efficient allocation reduces expected accident harm by inducing care by the party with control over the relevant margin (often the charterer for navigation/operation; the owner for pre-existing seaworthiness).
-   **Information and inspection costs:** If owners bear losses tied to latent defects, they may invest more in pre-delivery inspection/maintenance; if charterers bear too much of this risk, they may duplicate inspections or underinvest due to limited ability to detect defects.
-   **Enforcement and dispute costs:** Splitting losses by cause (operational vs. latent defect vs. force majeure) can lower moral hazard but can raise litigation and verification costs because parties will dispute causation.
-   **Risk-bearing and insolvency costs:** Concentrating large accident losses on a party that cannot absorb them can create real distortions (e.g., inefficiently low activity, or inability to pay leading to under-deterrence). Better risk spreading through insurance can reduce these real distortions.

Payments between owner and charterer (e.g., indemnities, higher/lower charter hire to compensate for liability) are transfers and are not real social costs, but they matter for incentives and for whether the parties will accept a given allocation.

**Verifiability and enforcement** Efficient "split-by-cause" clauses depend on what can be proven. Operational negligence (e.g., violation of safety procedures) may be easier to document than whether a defect was truly latent and pre-existing. If latent defects are hard to verify in court, putting too much on the owner may invite opportunistic claims by the charterer after an accident; if operational care is hard to verify, putting too much on the charterer may not generate the intended safety investments unless liability is strict or backed by observable proxies (e.g., certification, logbooks). These verifiability limits push toward allocations that rely on clearer, more documentable events.

**Conditional conclusion** An efficient allocation typically puts the costs of operational accidents on the charterer, because the charterer controls the main safety margins and bearing the loss mitigates moral hazard by inducing investment in competent crew and safety systems. Costs tied to latent defects and pre-charter seaworthiness should typically remain with the owner, because the owner is the low-cost avoider and has superior information about the vessel's condition at delivery; normal wear from ordinary use is also naturally treated as the owner's residual risk (or priced into hire) unless the charter specifies otherwise. Residual, non-controllable "force majeure"-type risks are efficiently assigned to the party that can bear and diversify them at lowest real cost, often through insurance, with the contract price adjusting to compensate whichever side takes on more risk. This conclusion is strongest when causation is reasonably verifiable and when insurance/solvency constraints do not undermine deterrence.
:::
:::

::: {.examquestion data-question-id="contracts-ma-warranties-indemnities"}
You are part of an advisory group assisting the owners of the company Norsk Teknologi AS in connection with an impending acquisition of the company by a larger foreign corporation, GlobalTech Inc. The acquisition is planned to take place through a Mergers and Acquisitions (M&A) transaction.

Norsk Teknologi AS operates in the development of technological solutions for industrial production and has experienced steady growth over the past ten years. Although the company has strong future prospects, the buyers are concerned about several risk factors:

1.  Possible future litigation related to patent claims by competitors concerning the technology.
2.  A possible future decline in demand for the technology the company offers.
3.  That the cultures of the two companies may prove difficult to reconcile.
4.  Possible future tax claims as a result of the company's tax planning having been close to the الحدود of legality.
5.  Possible future EU regulations that could render the technology unlawful.

GlobalTech Inc. wishes to include a warranties and indemnities clause under which the sellers would be liable in damages if the above risks materialize. However, the owners of Norsk Teknologi AS are skeptical about assuming extensive liability if such risks materialize after the acquisition, and they ask you for advice. What advice would you give? Which of the risks (if any) should the sellers assume indemnification liability for? Explain using economic theory.

::: {.goodanswer}
A good answer should use Cost--Benefit Analysis and Adverse selection. The central move is to treat warranties and indemnities as an instrument for allocating specific risks to the party who can best control them or best price them, and to ask when shifting liability increases total surplus so that the sellers can be compensated through a higher purchase price (a potential Pareto improvement). The analysis should distinguish risks tied to the pre-transaction history of Norsk Teknologi AS---where the sellers typically have superior information and can otherwise benefit from hiding or shading that information---from risks that mainly arise after closing and are largely controlled by GlobalTech's post-merger choices or by market/regulatory developments. Strong answers also pay attention to whether the relevant facts are verifiable (so liability can be enforced) and how the clause changes the buyer's discount for "unknown unknowns."
:::

::: {.examplesolution}
To answer this question we will use Cost--Benefit Analysis and Adverse selection.

**Object and counterfactual** The object is a "warranties and indemnities" clause that makes the sellers of Norsk Teknologi AS liable if specified risks materialize after closing. The counterfactual is a deal with limited or no seller liability for these future contingencies, so the buyer must bear (and price) the uncertainty.

**Incentives and behavioral responses** From an efficiency perspective, a risk-allocation clause is desirable if it increases total surplus: i.e., if shifting the risk to the sellers increases the buyer's willingness to pay by more than the expected real resource costs the sellers will incur when the risk materializes. If so, the deal can be a potential Pareto improvement (Kaldor--Hicks): the buyer pays a higher price, and the sellers accept liability but are compensated.

Adverse selection is key because the sellers typically know more about the firm's past actions and "latent" legal exposures than the buyer. Without warranties/indemnities, sellers have an incentive to downplay or withhold negative information about (i) the probability of patent disputes based on past development choices and documentation, and (ii) the probability of future tax claims based on past tax planning. If the buyer cannot trust the seller's statements, the buyer rationally discounts the firm's value to protect itself against worst-case hidden risks. A credible liability clause reduces this adverse-selection problem by making it costly for the seller to misrepresent or omit material information: if the risk was higher than disclosed, the seller must later pay.

By contrast, several listed risks are mainly determined by post-closing actions or external changes. Making the sellers liable for those risks does little to elicit better pre-sale information, and it can also distort incentives by shifting responsibility away from the party who will actually choose the relevant actions after closing.

A simple illustration: suppose the expected real resource cost of a pre-closing tax exposure is $pS = 0.2 \times 10 = 2$ (e.g., "2 million" in expected payments plus associated real compliance/litigation burden). If the absence of credible warranties causes the buyer to discount the price by 5 because it fears hidden tax issues, then adding the clause can increase total surplus by about 3: the buyer can pay up to 5 more, while the sellers expect 2 in costs. The extra 3 can be shared through the price, so seller liability need not make sellers worse off if priced correctly.

**Real costs and benefits**

-   **Information acquisition and disclosure costs:** Warranties/indemnities can increase due diligence and internal investigation costs (the parties spend resources to identify and document risks), but they also reduce wasteful "precautionary discounting" by the buyer driven by distrust.
-   **Expected harm from inefficient trade or mispricing:** Without credible protection against hidden pre-closing liabilities, the buyer may underpay, delay, or walk away from an otherwise efficient transaction. Credible seller liability reduces this expected inefficiency by making disclosed information more reliable.
-   **Precaution/compliance incentives tied to pre-closing conduct:** For risks rooted in the seller's past behavior (tax planning choices; IP clearance/documentation choices), seller liability can improve incentives to have taken (and documented) lawful/low-risk actions and to truthfully reveal what was done.
-   **Post-closing adaptation and management costs:** For risks driven by future demand changes, integration decisions, or future regulatory changes, shifting liability to sellers can reduce the buyer's incentive to invest in adaptation (product changes, compliance, organizational integration), potentially increasing real resource waste.
-   **Enforcement and dispute-resolution costs:** Broad, vague indemnities can generate costly disputes about causation and scope; narrower, well-defined categories reduce expected litigation/enforcement costs relative to a blanket "seller pays for any bad outcome."

(Any indemnity payment itself is a transfer between buyer and sellers and is not counted as a real resource cost; it matters because it changes incentives and credibility.)

**Verifiability and enforcement** The clause works best where the triggering facts are verifiable. "Tax planning near the legal boundary" and "risk of patent claims tied to pre-closing technology choices" can be anchored in verifiable records (tax filings, internal memos, product specifications, IP searches, correspondence). This makes it feasible to enforce seller liability and therefore to use it as a credibility device against adverse selection.

In contrast, "culture clash" and "future demand decline" are hard to verify as contractual breaches and are strongly influenced by GlobalTech's post-closing actions. "Future EU rules making the technology illegal" is verifiable as a change in law, but it is not a fact about the seller's pre-closing conduct; making sellers liable would largely insure the buyer against an external shock rather than solve an information problem, and it risks creating extensive scope disputes (what counts as "illegal," what adaptation was feasible, etc.).

**Conditional conclusion** Sellers should generally accept warranties/indemnities for risks that (i) are tied to the pre-closing history of Norsk Teknologi AS and (ii) are relatively verifiable---especially (1) patent disputes to the extent they stem from pre-closing development/IP clearance and (4) future tax claims arising from pre-closing tax planning. This reduces adverse selection and can raise the purchase price enough to compensate the sellers, increasing total surplus.

Sellers should generally resist (2) demand decline, (3) integration/culture problems, and (5) future EU regulatory changes as seller-liability items, because these are primarily post-closing/external risks that the buyer controls or must manage and where seller liability does less to improve pre-sale information and more to create enforcement disputes and weaken the buyer's adaptation incentives. This recommendation is strongest when the parties can clearly separate pre- vs post-closing causes in the contract and when enforcement costs are kept low through narrow, well-defined clauses.
:::
:::

::: {.examquestion data-question-id="contracts-insurance-fraud-detection"}
The company **TryggBolig AS** offers home contents insurance to private individuals. In recent years, more customers have chosen to go without insurance, while the number of large claim payouts has increased. The industry also reports a growing incidence of insurance fraud, particularly involving alleged thefts and fire damage. Some customers have had claims rejected because the company believes the damages are insufficiently documented.

The management of TryggBolig AS is now considering various measures to reduce fraud, strengthen profitability, and maintain trust in the company.

TryggBolig AS discovers that some customers systematically exaggerate losses to receive higher compensation. Discuss how the insurance company should design its responses and control procedures to reduce the extent of such behavior.

::: {.goodanswer}
A good answer should use Legal Incentives Model. Good answers could also draw on Cost--Benefit Analysis. The key is to treat systematic exaggeration of losses as a choice driven by the private gain from inflation versus the expected consequence, and to explain how the insurer can change that comparison by raising the probability of detection $p$, the sanction $S$, and/or reducing the gain from exaggeration. A strong answer also recognizes that tighter control routines are costly and can deter honest customers or delay legitimate payouts, so the insurer should discuss targeted controls (screening, audits, documentation) versus blanket frictions. Finally, the answer should connect credibility and verifiability---what can be proven and enforced in practice---to which reactions are likely to work.
:::

::: {.examplesolution}
To answer this question we will use Legal Incentives Model, and Cost--Benefit Analysis.

**Object and counterfactual** TryggBolig AS must choose (i) reactions to detected exaggeration and (ii) control routines that make exaggeration harder and riskier. The counterfactual is a more lenient regime with weaker documentation and fewer audits, where claimants expect a low chance of being challenged and little downside if they inflate.

**Actors and decision margin** The relevant actor is the insured customer filing a claim. The decision margin is how much to inflate the reported loss above the true loss (including whether to fabricate supporting information). The insurer chooses monitoring intensity and the menu of consequences when exaggeration is discovered.

**Incentives and behavioral responses** Under the Legal Incentives Model, exaggeration is attractive when the private benefit $B$ from inflating the claim exceeds the expected sanction $pS$, where $p$ is the probability the exaggeration is detected/proved and $S$ is the consequence conditional on detection.

-   Increasing $p$: stronger documentation requirements, random audits, specialized fraud investigation for flagged claims, and cross-checks (e.g., purchase receipts, serial numbers, fire reports) raise the chance that inflated amounts are detected and can be proven.
-   Increasing $S$: credible reactions such as denying the inflated part (or the whole claim when exaggeration is material), requiring repayment, cancelling coverage, and placing the customer in a higher-risk premium category increase the downside of trying.
-   Reducing $B$: contract design can reduce the marginal gain from exaggeration even when the claim is paid. For instance, higher deductibles and co-insurance mean an extra "invented" krone produces less extra payout, and payout caps or replacement-by-voucher policies narrow the scope for overstatement.

A simple illustration: suppose inflating a claim yields $B = 10{,}000$ (extra payout if not challenged). If TryggBolig only detects/proves exaggeration with $p=0.10$ and the expected consequence is $S=50{,}000$ (repayment and other penalties), then $pS = 5{,}000 < B$, so exaggeration remains attractive. Deterrence can come from raising $p$ (more audits) or $S$ (clearer, tougher reactions), or by shrinking $B$ (e.g., co-insurance so that the same inflation produces less extra payout).

The insurer should also anticipate offsetting behavioral responses. Very strict routines can increase customer effort costs and delays, and can push honest, low-risk customers to go uninsured or to choose other insurers, weakening the risk pool and further harming profitability.

**Real costs and benefits**

-   **Investigation and monitoring costs:** More audits, documentation checks, and specialist personnel increase real resource use relative to a lenient regime.
-   **Claim-processing delay and administrative burden:** Tighter routines can slow payouts and raise time/effort costs for both the insurer and honest customers (including repeated documentation requests).
-   **Wasteful fraud effort:** Stronger deterrence reduces resources spent by claimants on inflating claims (fabricating narratives, staging losses, searching for fake documentation).
-   **Risk-bearing and insurance-market participation:** Reducing systematic exaggeration can improve pricing and trust, which can increase take-up of insurance and reduce uninsured risk-bearing; conversely, overly aggressive controls can reduce take-up and increase inefficient self-insurance.
-   **Dispute-resolution costs:** More denials and challenges can increase complaints and formal disputes, which are real costs even when the underlying payment is a transfer.

Insurance payouts, premium changes, and repayments are transfers and are not counted as real social costs or benefits. They matter here because they shape incentives ($B$ and $S$) and participation decisions.

Overall, the efficient policy balances marginal deterrence gains from reduced fraud and reduced wasteful behavior against marginal monitoring, delay, and dispute costs. Targeted controls (focused on suspicious claims) often dominate blanket frictions because they raise $p$ for high-risk cases while reducing burdens on honest claimants.

**Verifiability and enforcement** Deterrence depends on whether exaggeration is verifiable: the insurer must be able to document the discrepancy using evidence that would withstand challenge. If proof is hard (e.g., cash purchases, no serial numbers, ambiguous fire causation), then raising $p$ may be expensive and error-prone. In that setting, TryggBolig should rely relatively more on (i) contract terms that reduce $B$ mechanically (deductibles/co-insurance/caps, replacement-value rules), and (ii) reactions that are enforceable without proving intent beyond the discrepancy (e.g., denying the unverifiable portion, requiring standardized proof for high-value items). Conversely, if documentation is feasible at low cost (digital receipts, standardized inventories, third-party reports), then investments that raise $p$ through audits and verification can be cost-effective and allow a lower $S$ while still achieving deterrence.

**Conditional conclusion** TryggBolig should design a package that (1) raises the expected consequence of exaggeration $pS$ and/or (2) reduces the gain $B$, while minimizing burdens on honest claimants. If reliable verification is feasible, the company should emphasize higher $p$ through targeted audits and documentation coupled with predictable, escalating sanctions (deny inflated amounts, repayment, cancellation/premium increases). If verification is inherently difficult or costly, the company should put more weight on reducing $B$ via deductibles/co-insurance/caps and on simple, enforceable reactions tied to missing proof, because attempts to raise $p$ in low-verifiability settings risk high monitoring costs and costly false positives that can drive good customers out of the pool.
:::
:::

::: {.examquestion data-question-id="contracts-insurance-security-requirement"}
Selskapet **TryggBolig AS** tilbyr innboforsikring til privatpersoner. De siste årene har flere kunder valgt å stå uten forsikring, samtidig som antallet store skadeutbetalinger har økt. Bransjen rapporterer også om økende forekomst av forsikringssvindel, særlig ved påståtte tyverier og brannskader.

TryggBolig AS vurderer å innføre en klausul i forsikringsavtalen som krever at alle kunder installerer en FG-godkjent sikkerhetslås til en kostnad på minst 7 000 kroner. Installasjonen vil i mange tilfeller kreve utskifting av dør. Hvilke faktorer avgjør om TryggBolig burde inkludere en slik klausul. Diskuter ved hjelp av økonomisk teori.

::: {.goodanswer}
A good answer should use Cost--Benefit Analysis. Good answers could also draw on Moral hazard. The key issue is whether a mandatory FG-approved lock (including frequent door replacement) reduces expected theft-related payouts and fraud-related losses by more than it increases real resource costs for customers and the insurer. Strong answers identify how the clause changes customers' precaution incentives and who is most affected (high-value households and high-theft locations versus low-risk customers), because heterogeneity determines whether a uniform requirement is efficient or instead drives desirable customers out of the pool. Good answers also recognize that the clause only works if installation is cheaply verifiable and enforceable in underwriting and claims handling.
:::

::: {.examplesolution}
To answer this question we will use Cost--Benefit Analysis, and Moral hazard.

**Object and counterfactual** TryggBolig is considering adding a contract clause requiring every policyholder to install an FG-approved security lock costing at least NOK 7,000, often requiring door replacement. The relevant counterfactual is the current contract without this mandatory minimum-security requirement (customers choose their own level of home security).

**Incentives and behavioral responses** The clause forces higher precaution. If customers otherwise underinvest in security because they do not bear the full expected cost of theft (the insurer pays), the clause can reduce a moral-hazard problem by imposing a minimum standard. The main behavioral channel is a reduced probability of theft, and potentially fewer "easy" fraudulent theft and fire claims if stronger security makes staged losses harder to carry out or easier to dispute. However, a uniform NOK 7,000+ requirement also changes who buys insurance: some low-risk customers (or customers with low insured value) may drop coverage because the up-front cost exceeds their expected benefit from reduced theft risk, worsening the insurer's pool and reducing risk-sharing for those customers.

**Real costs and benefits**

-   **Precaution/compliance costs (real resource costs):** Customers spend at least NOK 7,000 on the lock and, in many cases, additional resources on replacing the door and installation time/hassle. This is the main cost and varies across homes (some need a full door change; others do not).
-   **Reduced expected harm from theft (real resource benefit):** If the lock materially lowers the probability of theft, real losses from theft (stolen goods, damage to the home, disruption) fall. This is larger when households have higher at-risk value and face higher baseline theft risk.
-   **Reduced resources spent on fraud and disputes (real resource benefit):** If fraud is less frequent or easier to detect, fewer resources are wasted on investigations, claims processing, and contested cases (and fewer real losses from deliberately caused fires/thefts).
-   **Administrative and monitoring costs (real resource cost):** The insurer may need procedures to check compliance (documentation, inspections, handling exemptions), which consumes resources.

A simple way to discipline the comparison is expected-value reasoning. The clause is socially attractive for a given household when the expected reduction in theft-related losses exceeds the real compliance and administration cost. For example, if the baseline theft probability is $p=0.04$ and the lock reduces it to $p=0.01$, the probability drop is 0.03. If the relevant at-risk value (expected loss conditional on theft) is NOK 300,000, the expected reduction in loss is $0.03 \times 300{,}000 = 9{,}000$, which can justify a NOK 7,000 lock (and even some monitoring cost). But if the at-risk value is NOK 100,000, the expected reduction is only $0.03 \times 100{,}000 = 3{,}000$, so a universal requirement would be inefficient for that customer type. (Any premium reduction or shifted payouts are transfers between insurer and customer and are not counted as real costs/benefits, though they matter for incentives to buy insurance and comply.)

**Verifiability and enforcement** The clause only changes behavior if compliance is verifiable and can be enforced in practice. If TryggBolig cannot cheaply verify installation (or whether the lock is actually used), customers may not comply while still being covered, so the intended reduction in theft risk and fraud will not occur. Conversely, if FG-approval and documented installation provide clear proof, the insurer can condition coverage/claims on compliance, raising the effective probability $p$ that non-compliance is detected and sanctioned (e.g., by reduced payout), which strengthens deterrence but can increase monitoring and dispute costs.

**Conditional conclusion** TryggBolig should include the clause if, for the relevant customers, the reduction in expected theft and fraud-related losses is larger than the real resource costs of installation/door replacement plus the insurer's added verification costs. The conclusion is therefore likely to depend on (i) how much the lock reduces the probability of theft and fraudulent claims, and (ii) the level of at-risk value in the home. If risk and value are very heterogeneous, a uniform clause for all customers is less likely to be efficient than a targeted requirement focused on high-risk locations or high insured values; otherwise the clause may drive low-risk/low-value customers out of the pool while forcing them to buy precautions whose expected benefit is below NOK 7,000.
:::
:::

::: {.examquestion data-question-id="contracts-electricity-pricing-structure"}
NordEnergi AS er en mellomstor strømleverandør som selger kraft til både husholdninger og bedrifter. I 2024 opplevde selskapet store svingninger i strømprisene som følge av økt eksport, varierende tilsig til vannmagasinene og uforutsigbare værforhold. Flere kunder og industribedrifter mener prisene har vært urimelig høye, og det har oppstått en debatt om hvorvidt dagens markedsmodell for strøm fungerer etter hensikten.

Et stort industrikonsern, NordMetall, ønsker å forhandle en egen strømavtale med NordEnergi. Kunden krever forutsigbare priser, men ønsker samtidig å kunne dra nytte av lave spotpriser når markedet faller. Du representerer NordEnergi, og skal foreslå en prisstruktur for avtalen --- for eksempel en fastprisavtale, en spotprisavtale eller en kombinasjon. Hvilken prisstruktur vil du foreslå, og hvorfor? Diskuter ved hjelp av økonomisk teori.

::: {.goodanswer}
A good answer should use Cost--Benefit Analysis. Good answers could also draw on Moral hazard. The strongest answers identify NordMetall's key decision margin (how much electricity-intensive production to run when prices are high versus low) and explain how different price structures change that margin. They also recognize the core trade-off between allocative efficiency (using more power when it is cheap and less when it is scarce) and risk-bearing/predictability for a customer that dislikes large price swings. Finally, they connect the recommendation to the supplier's perspective by noting that "insurance" against spot volatility must be priced, and that any hybrid structure must balance the customer's desire for upside participation with the supplier's need to control exposure.
:::

::: {.examplesolution}
To answer this question we will use Cost--Benefit Analysis, and Moral hazard.

**Object and counterfactual** NordEnergi must propose a pricing structure for a bilateral electricity contract with NordMetall. The relevant counterfactuals are (i) a pure spot-price contract (NordMetall pays the market price each hour/day), and (ii) a pure fixed-price contract (NordMetall pays a constant price per kWh, regardless of spot movements). A natural candidate structure is a hybrid: a fixed price for a contracted "base" quantity (to create predictability) combined with spot pricing (or spot with a cap) for incremental consumption (to preserve incentives and allow participation in low spot prices).

**Incentives and behavioral responses** The key behavioral response is NordMetall's production/consumption choice on "cheap" versus "expensive" days. Use the instructor's numbers: spot is $0.40$ kr/kWh on cheap days and $1.20$ kr/kWh on expensive days. NordMetall can choose to use $50{,}000$ kWh or $100{,}000$ kWh per day. The first $50{,}000$ kWh generates $1.50$ kr/kWh in revenue for the firm; the next $50{,}000$ kWh generates only $0.60$ kr/kWh in revenue.

-   Under **spot pricing**, NordMetall internalizes the real scarcity of electricity. On cheap days, the incremental margin for the second block is $0.60 - 0.40 = 0.20$ kr/kWh, so using $100{,}000$ kWh is efficient for the firm. On expensive days, the incremental margin for the second block is $0.60 - 1.20 = -0.60$ kr/kWh, so it will reduce to $50{,}000$ kWh. Thus spot pricing gives an incentive to shift consumption away from high-price periods and toward low-price periods, which is exactly the desired demand response when the system is tight.

-   Under a **fixed price**, the firm faces the same marginal price on cheap and expensive days. If the fixed price is set around an average level, NordMetall will tend to choose the same consumption every day. In the example, a fixed price above $0.60$ kr/kWh would lead NordMetall to use only $50{,}000$ kWh even on cheap days (foregoing valuable production when power is abundant). A fixed price below $0.60$ could lead to $100{,}000$ kWh even on expensive days (running electricity-intensive production when power is socially scarce). Either way, compared to spot pricing, fixed pricing blunts the incentive to adjust output across states of the world.

This is a moral-hazard-type problem in the sense that NordMetall's post-contract usage choice is the key action the contract should motivate. A contract that fully insures NordMetall against high prices also insures it against the need to economize on electricity when it is expensive.

A **hybrid** structure targets both concerns. A fixed-price block for a baseline quantity provides predictability for operations that cannot easily be adjusted, while spot pricing (or spot with a cap) on incremental usage preserves incentives at the margin and lets NordMetall benefit when spot prices are low.

**Real costs and benefits**

-   **Misallocation of electricity across time (inefficient production/consumption patterns):** Pure fixed price tends to increase misallocation (too much use in expensive periods and/or too little use in cheap periods). Pure spot reduces misallocation by inducing load shifting. A hybrid reduces misallocation relative to pure fixed price because at least marginal units face scarcity pricing.
-   **Costly production distortions from price risk (risk-bearing costs):** Pure spot exposes NordMetall to large and unpredictable input cost swings, which can lead to conservative production planning, inefficient shutdowns, or expensive internal hedging. A fixed-price component reduces these real distortions by stabilizing the cost of baseline operations.
-   **Hedging and contract-administration costs:** Any fixed-price promise requires NordEnergi to manage its own exposure (through procurement/hedging, reserves, and risk management). These are real resource costs that rise as more volume is put on fixed terms; a hybrid limits these costs by keeping only a base quantity fixed.
-   **System reliability and scarcity management (as a real benefit):** When prices reflect scarcity, demand reductions on expensive days can reduce strain on the system and the need for costly adjustments elsewhere. Hybrid and spot pricing support this more than pure fixed pricing.

Note: the price paid (fixed vs spot) is mainly a transfer between NordMetall and NordEnergi; it is not itself a real resource cost. But the transfer matters for incentives and for how much risk each party bears.

**Conditional conclusion** A sensible proposal for NordEnergi is a hybrid contract: a fixed price for a contracted baseline quantity (to provide the predictability NordMetall demands) and spot pricing for additional consumption (optionally with a pre-agreed cap if NordMetall's risk concerns are strong and NordEnergi charges for that insurance). This is preferred when (i) NordMetall can adjust at least some production margin in response to prices (so marginal spot exposure creates real efficiency gains), and (ii) full spot exposure would impose meaningful risk-bearing costs on the firm. If instead NordMetall cannot adjust production at all in the short run, the incentive benefit from spot exposure is smaller, and a larger fixed-price share (with an explicit risk premium) becomes more attractive.
:::
:::

Exam
====

Exam Questions {#exam-questions}
--------------

This chapter explains how exam questions in GRA6296 are structured and how you should approach them. The purpose is not to provide templates or formulaic answers, but to make explicit the economic reasoning the exam is designed to test.

Unlike exams that focus on doctrinal recall or precise calculations, law and economics exams ask you to reason about decisions under legal constraints. You are typically expected to:

-   identify the relevant economic problem,
-   select and apply appropriate analytical tools,
-   explain key trade-offs and incentive effects,
-   and reach a clear, conditional conclusion.

In most cases, the hardest part of an exam question is not the analysis itself, but recognizing what kind of question you are being asked. Most mistakes occur because students answer a different question than the one posed.

### Why Exam Questions in Law and Economics Are Different

Law and economics exam questions rarely have a single correct answer. Instead, they reward answers that are:

-   well structured,
-   grounded in economic reasoning,
-   explicit about assumptions,
-   and clear about what the conclusion depends on.

You are usually not expected to compute an optimal number, solve a formal model, or reach a definitive yes/no verdict. Instead, you are expected to explain what would matter for the answer, why it would matter, and how different assumptions would change the conclusion.

A good answer therefore shows judgment, not certainty. It demonstrates that you understand how legal rules affect incentives, behavior, and outcomes.

### The Three Types of Exam Questions

Most exam questions in this course fall into one of three recurring types:

1.  **Legal rules, institutions, and interpretation**
2.  **Ex ante incentive design (contracts and governance)**
3.  **Private behavior under legal incentives**

Each type is defined by a different decision-maker and a different decision problem. As a result, each type calls for a slightly different way of structuring your answer.

Recognizing which type of question you are facing is often the most important first step toward a high-quality exam answer. The sections below explain each type in detail and provide practical guidance for how to approach them under exam conditions.

### Type 1: Legal Rules, Institutions, and Interpretation

**Core question:** How do legal rules or institutions affect behavior and welfare, and how should they be designed, justified, or interpreted?

This type includes questions that ask:

-   why a legal rule exists (or should exist),
-   whether a rule or policy is well designed,
-   how a statute, legal standard, or doctrine should be interpreted in light of its incentive effects.

Typical exam formulations include:

-   "Why is activity X illegal?"
-   "Which factors determine whether rule X is a good law?"
-   "Would strict liability be an efficient rule?"
-   "How should statute X be interpreted using economic reasoning?"
-   "How should a negligence standard be applied in this case?"

From an economic perspective, these questions all involve the same underlying task. A legislator, regulator, or court is implicitly choosing among alternative legal rules or interpretations. Your task is to compare these alternatives by asking how they affect behavior **ex ante** and whether they lead to better overall outcomes.

1.  How to Approach Type 1 Questions

    Type 1 questions ask you to evaluate, justify, or interpret legal rules or institutions. Although such questions may appear doctrinal, their economic core is usually a comparison between alternative rules or interpretations.

    In most cases, the appropriate analytical tool is a cost--benefit perspective, as developed in the chapter on cost--benefit analysis.

    When answering a Type 1 question, you should:

    -   Be clear about what rule or interpretation is being considered and what it is compared to.
    -   Ask how each alternative affects behavior **ex ante**.
    -   Identify the main real-world costs and benefits created by these behavioral changes.
    -   Explain which factors determine whether the benefits outweigh the costs.
    -   Draw conditional conclusions, stating clearly what the answer depends on.

    You are not expected to repeat a full cost--benefit analysis mechanically. Instead, you should apply the logic of cost--benefit reasoning to the specific legal context of the question.

    For a step-by-step explanation of cost--benefit reasoning, see the section A Practical Recipe for Cost--Benefit Analysis in the foundations chapter on cost--benefit analysis. For common mistakes to avoid when using CBA, see Common Pitfalls When Using CBA.

### Type 2: Ex Ante Incentive Design (Contracts and Corporate Governance)

**Core question:** How should private parties design or interpret the rules governing their relationship in order to maximize the total surplus it generates?

Type 2 questions concern **ex ante** choices about how a relationship is structured. These choices may take the form of explicit contract terms, governance mechanisms, or default rules applied by courts when contracts are incomplete.

They include questions that ask:

-   whether a contractual clause or governance mechanism should be adopted,
-   how risk, liability, authority, or control should be allocated,
-   how contracts or governance arrangements should be interpreted when there are gaps or ambiguities.

The key economic insight is that efficient design maximizes **total surplus**. If a clause, rule, or interpretation increases total surplus, the parties can adjust prices, compensation, or control rights so that all parties are better off. First maximize the pie, then divide it.

1.  How to Approach Type 2 Questions

    Type 2 questions are answered by analyzing how alternative arrangements affect incentives **before** uncertainty is resolved. The focus is not on who benefits under a particular realization, but on how behavior changes under different designs.

    In most cases, the relevant analysis follows the [contract-design logic developed in the contracts chapter](#contract-clause-recipe). That framework focuses on:

    -   how a clause or mechanism changes behavior,
    -   which real resource costs and benefits are created,
    -   how information problems affect incentives,
    -   and how enforcement and commitment limits constrain feasible design.

    For common mistakes to avoid in contract analysis, see Common Pitfalls When Analyzing Contract Clauses.

    The same reasoning applies to corporate governance questions, even when the mechanisms involved are not formal contracts. Rather than introducing a separate method, governance questions reuse the same ex ante incentive-design logic in a different institutional setting.

### Type 3: Private Behavior under Legal Incentives

**Core question:** Given the existing legal and institutional environment, how will rational private actors behave?

Type 3 questions concern strategic behavior. The legal rules and institutions are taken as given. Your task is not to evaluate whether the law is good or bad, but to analyze how it shapes incentives, credibility, bargaining power, and outcomes.

These questions arise in several recurring business situations, including decisions about whether to enter or exit a relationship, how to respond to suspected opportunism, whether threats or promises are credible, and whether to rely on legal enforcement or informal mechanisms such as reputation.

They include questions that ask:

-   whether a party should trust another party,
-   whether to enter, exit, or continue a relationship,
-   whether to sue, settle, or continue bargaining,
-   whether to enforce or tolerate opportunism,
-   whether a threat, promise, or strategy is credible.

Typical exam formulations include:

-   "Should you trust the investment adviser?"
-   "Is the threat of a lawsuit credible?"
-   "Should management be sued or tolerated?"
-   "Which factors determine the size of a settlement?"

Although these situations look different, the underlying logic is the same. Private actors choose strategies by comparing expected payoffs, taking into account enforcement probabilities, sanctions, litigation costs, reputation, and future interaction.

1.  How to Approach Type 3 Questions

    Type 3 questions typically require strategic reasoning about how parties behave under legal constraints. This requires analyzing credibility, backward reasoning, and bargaining power---concepts introduced in the foundations chapters on transaction costs, self-enforcement, and information.

    1.  Step 1: Identify the decision-maker and the decision

        Start by identifying:

        -   who is making a choice, and
        -   what decision they face.

        Examples:

        -   Should you trust the investment adviser?
        -   Should the firm sue, settle, or walk away?
        -   Should a patent troll file a lawsuit?
        -   Should a firm comply, resist, or renegotiate?

        A clear answer always begins by stating whose decision is being analyzed.

    2.  Step 2: Take the legal environment as given

        Briefly describe the relevant legal and institutional background, such as:

        -   liability rules,
        -   burden of proof,
        -   fee-shifting rules,
        -   available remedies,
        -   enforcement probabilities.

        Do not evaluate the law. Treat it as fixed and focus on how it affects payoffs and incentives.

    3.  Step 3: Identify actions and responses

        List:

        -   the options available to the decision-maker, and
        -   how other parties are likely to respond.

        You do not need to draw a formal game tree, but your reasoning should be consistent with one.

    4.  Step 4: Compare expected payoffs

        This is the core step.

        For each relevant option, ask:

        -   what are the expected benefits?
        -   what are the expected costs?
        -   how do probabilities, sanctions, damages, and legal costs enter?

        Exact numbers are rarely required. What matters is comparative expected-value reasoning.

    5.  Step 5: Assess credibility and commitment (if relevant)

        If the question involves threats, promises, or warnings, ask:

        -   is the threat or promise credible?
        -   would the actor actually carry it out when the time comes?
        -   are there reasons to bluff or delay?

        Credibility depends on whether the action would be optimal **ex post**, given the legal environment.

    6.  Step 6: Analyze bargaining and outside options (if relevant)

        If the situation involves negotiation or settlement, identify:

        -   each party's disagreement payoff,
        -   outside options,
        -   how legal costs, delay, and risk affect bargaining power.

        This explains who concedes, who holds out, and how surplus is divided.

    7.  Step 7: Draw a conditional conclusion

        Conclude by explaining:

        -   which action is optimal under which conditions,
        -   which parameters matter most (probabilities, costs, wealth, enforcement).

        Avoid absolute answers. Strong answers explain how behavior would change if key factors change.

        Used correctly, this recipe allows you to analyze diverse Type 3 questions in a disciplined way, even when the setting involves trust, litigation, reputation, or market power.

### How to Identify the Question Type on the Exam

A useful first step on the exam is to ask:

-   Is the question evaluating a legal rule or its interpretation? → Type 1
-   Is the question about designing or interpreting a contract? → Type 2
-   Is the question about how private actors behave given the law? → Type 3

Identifying the question type early helps you choose the right structure and avoid irrelevant arguments.

### Final Advice for the Exam

Strong exam answers in law and economics share a few common features:

-   They are clearly structured.
-   They focus on incentives and behavior, not labels or doctrine.
-   They explain what the answer depends on.
-   They give conditional conclusions rather than absolute claims.
-   They make assumptions explicit.

The purpose of the exam is not to reward memorization, but to test your ability to apply economic reasoning to legal problems in a disciplined way. This chapter is intended to make that expectation as transparent as possible.
