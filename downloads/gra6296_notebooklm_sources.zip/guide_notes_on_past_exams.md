# Note on Past Exams and Solutions

The past exam questions in this notebook illustrate the *style and structure* of assessment in this course.

The accompanying solutions are **explanatory and diagnostic**, not templates to be memorized. They show:
- how relevant economic models are identified,
- which assumptions matter,
- how conclusions depend on those assumptions.

Future exams will use **new fact patterns**. Successful answers require reasoning, not recall.
