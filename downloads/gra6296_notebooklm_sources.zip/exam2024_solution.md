# Grading Guidelines
## GRA 62961 Economic Analysis of Topics in Law
**Spring 2024**

## General Guidelines

There are many potential answers to these questions and the candidates should be graded based on the extent to which they demonstrate that they have understood the course material. The students have received the following guidelines for answering the exam:

> It is your task to demonstrate that you have understood the course material. Answer the questions in a way that demonstrates your understanding:
>
> 1. Use concrete examples related to the question. (If your examples are connected to the specific case discussed in the question, you show that you are not just rephrasing material from the slides or from the book, but that you have *understood* it).
> 2. It is a good idea to use concrete numerical examples to make your points
> 3. Explicitly use the theory discussed in the course in your answers. Example, if your answer relies on cost-benefit analysis, explicitly state that you use cost-benefit analysis and explain why it is relevant.
> 4. Explicitly state the assumptions behind your analysis. If possible, also state how your conclusions would change if your assumptions do not hold.
> 5. Do not quote directly from the book or from the slides, but use your own words. If you need to cite from the book or the slides make sure this is properly cited. For example, "The criminal maximizes the net benefits of the crime" (Cooter et al 2012).

## Question 1

You advise Biotech Innovations Ltd., a phramaceutical firm specializing in developing and manufacturing innovative drugs. They have just innovated a new drug, "BioCureX," a breakthrough treatment for a rare genetic disorder. The active pharmaceutical ingredient required for BioCureX is exclusively supplied by PharmaChem Co. Biotech Innovations is about to sign a long-term supply agreement with PharmaChem. But they are worried that PharmaChem might fail to consistently supply the amount of the ingredient necessary for large scale production.

**30 points.** The contract will include a clause stipulating the damages PharmaChem should pay Biotech Innovations if it fails to supply the ingredient. How large will you recommend these damages to be? Which factors determine your advice? Explain using economic theory. Pay specific attention to the fact that, after signing the contract, Biotech Innovations will enter into significant investments to expand its capacity to produce the drug and get it approved for commercial sale.

### Guidelines

A good answer should use the economic theory of contracts and argue that expectation damages---Biotech Innovations being put into a position such that it is as well off as if PharmaChem had followed the contract---is the best advice. An answer should ideally explain (i) why expectation damages is the most efficient level of damages, and (ii) why both Biotech Innovations and PharmaChem want the most efficient possible contract. For (ii), one can argue that maximizing the "total pie" makes it possible to make both sides better off than in any other agreement (Pareto efficiency). One can explain (i), for instance, by showing in numerical examples that if damages are too high (too low), PharmaChem has incentives to supply (to not supply) the goods even when the benefit of doing so is below (above) the cost. The students should also be able to explain what expectation damages imply in this specific case (e.g., lost profits, reputational damage, unrecoverable investments due to not having the ingredient, etc). In particular, the "investments to expand its capacity to produce the drug and get it approved for commercial sale" might be part of these damages. Since the ingredient is exclusively supplied by PharmaChem, Biotech Innovations is unable to derive value from these investments by changing to another supplier. The best answers should realize that Biotech Innovations should not necessarily be compensated for all their investments. If the company is compensated for all lost investments, it might make investments that are not Kaldor-Hicks efficient. For instance, if there is a large chance that PharmaChem obtains problems with delivering the ingredient, it might be efficient that Biotech Innovations waits with their investments until these uncertainties are resolved. But if the company is compensated for all lost investments, they might not wait. "Hypothetical expectation damages"---where the firm is only compensated for investments that are Kaldor-Hicks efficient avoids this problem.

## Question 2

**20 points.** If PharmaChem does not supply the ingredient as promised, nobody can be held criminally liable. Why is breach of contract not a crime? Explain using economic theory.

### Guidelines

A good answer should explain why certain acts are considered crimes, and why these reasons might not apply to breach of contract. For instance, consider the case of theft. Since there is a chance that a criminal gets away with theft, the possibility of the victim of suing the criminal for damages in a civil case is not sufficient to deter the criminal. Most other crimes share this characteristic---the probability of detection being less than 100%. One can argue that contract breaches will very often be detected. The victim being compensated is thus sufficient to prevent (inefficient) breaches of contracts. Good answers could also argue that expectation damages give contractors incentives to breach if and only if this is Kaldor-Hicks efficient. Harsher punishments (such as prison sentences, additional fines, or punitive damages) could thus lead to the fulfillment of contracts that, according to the Kaldor-Hicks criterion, should have been breached. One can also argue that punishments such as fines and prison sentences for contract breaches could discourage people from entering into contracts (which is inefficient according to the Coase Theorem). Some students could argue that certain contract breaches are hard to detect, in which case punishments stronger than expectation damages could be justifiable.

## Question 3

**30 points.** You want to include one of the following clauses in the contract:

- **Clause A:** "In the event of any dispute arising from or relating to this contract, including any legal action or proceeding, the prevailing party shall be entitled to recover its reasonable attorneys' fees and court costs incurred in connection with such dispute."
- **Clause B:** "Each party shall bear its own attorneys' fees, costs, and expenses incurred in connection with any dispute arising from or relating to this contract, including any legal action or proceeding."

Which of these two clauses would you recommend to Biotech Innovations? Explain why using economic theory.

### Guidelines

A good answer should be able to reason about the effects of these clauses on (i) settlement bargaining in case of a dispute, (ii) PharmaChem's incentives to not breach the contract, and (iii) the overall efficiency of the contract. The student should recommend the rule that they deem most efficient since a more efficient contract increases the "total pie" and can make both Biotech Innovations and PharmaChem better off. To discuss (i) and (ii), the student can, for instance, set up a game tree. One possible analysis could be as follows. First, argue that Clause A gives Biotech Innovations a stronger bargaining position if there is a legal dispute: Assuming that the probability of Biotech Innovations winning in court is above 50%, the value of a lawsuit is higher for Biotech Innovations under Clause A than under Clause B. Similarly, the cost of the lawsuit for PharmaChem is higher under Clause A than under Clause B. Under Nash bargaining, Biotech Innovations can thus obtain a better settlement under Clause A. If the cost of the lawsuit is high and the amount owed by PharmaChem is low, Biotech Innovations' threat of a lawsuit might not even be credible under Clause B. Then, argue that PharmaChem has stronger incentives to supply the ingredient under Clause A. Part (iii) is not obvious, and there are many ways in which the student can discuss this. For instance, under the assumption of Nash bargaining, Clause A might lead to too large settlements (even larger than what PharmaChem owes). This again can give PharmaChem too strong incentives to supply the ingredient (even when it is Kaldor-Hicks efficient to not supply the ingredient). Very good students could go on to discuss the interaction between the level of damages in Question 1 and the choice between Clause A and B.

## Question 4

**20 points.** Both sides sign the contract. After a while, it turns out PharmaChem has been supplying the wrong quality of the ingredient, making the drug ineffective. Biotech Innovations claims PharmaChem has violated the terms of the contract and threatens to sue for damages. You are tasked to find a lawyer to represent Biotech Innovations in a legal dispute with PharmaChem. Which lawyer would you recommend to use? On which contractual terms would you recommend the lawyer to be engaged? Explain using economic theory.

### Guidelines

We have discussed the contracting of lawyers in the lectures, so this should be a relatively straightforward question (especially since this is an open-book exam). The students should advise to contract either (i) lawyers with a good reputation, (ii) lawyers the firm has a long-term business relationship with, or (iii) an in-house lawyer. The economic explanation is agency issues in the provision of legal services: It is hard for Biotech Innovations to assess the quality of the legal services they receive, lawyers could have incentives to overbill hours, etc. Relational contracts or reputations can be seen as possible solutions to these agency problems. Ideally, the students should explain why and when repeated interactions and reputational mechanisms could work using economic theory (e.g., repeated games). Regarding the contractual terms, the students could discuss hourly billing and contingency fees (or other arrangements where the lawyer is paid more if the case ends in "success"). Hourly billing could lead the lawyer to bill too many hours, work inefficiently, and advise against settlements. Contingency fees could lead to the lawyer working efficiently but for too few hours and being too eager to settle. The student should explain this using examples or otherwise. Ideally, the students should discuss these issues in relation to the Biotech Innovations and PharmaChem dispute ("use concrete examples related to the question") to show that they are able to apply the insights from the lectures to this particular setting.
