# Grading Guidelines
## GRA 62961 Economic Analysis of Topics in Law
**Spring 2025**

## General Guidelines

There are many potential answers to these questions and the candidates should be graded based on the extent to which they demonstrate that they have understood the course material. The students have received the following guidelines for answering the exam:

> It is your task to demonstrate that you have understood the course material. Answer the questions in a way that demonstrates your understanding:
>
> 1. Use concrete examples related to the question. (If your examples are connected to the specific case discussed in the question, you show that you are not just rephrasing material from the slides or from the book, but that you have *understood* it).
> 2. It is a good idea to use concrete numerical examples to make your points
> 3. Explicitly use the theory discussed in the course in your answers. Example, if your answer relies on cost-benefit analysis, explicitly state that you use cost-benefit analysis and explain why it is relevant.
> 4. Explicitly state the assumptions behind your analysis. If possible, also state how your conclusions would change if your assumptions do not hold.
> 5. Do not quote directly from the book or from the slides, but use your own words. If you need to cite from the book or the slides make sure this is properly cited. For example, "The criminal maximizes the net benefits of the crime" (Cooter et al 2012).

---

## Question 1

The cement company NordCem AS plans to install a carbon capture system at its plant in southern Norway to meet increasingly strict emission targets. NordCem has signed a letter of intent with CleanCarbon Technologies AS, a Norwegian technology company specializing in CO2 capture solutions for industrial applications.

The system promises to capture around 400,000 tonnes of CO2 per year—roughly 50% of NordCem's current emissions—using an amine-based chemical process. However, the actual capture rate depends on local operating conditions, such as kiln gas composition, temperature stability, and maintenance routines. If capture rates fall below expectations, NordCem risks exceeding its permitted emissions limits and will be required to purchase additional CO2 quotas under the EU Emissions Trading System (EU ETS), potentially at a high market price.

**25 points.** NordCem AS is considering including a clause in the contract stating that CleanCarbon Technologies AS must cover any additional CO2 quota costs NordCem incurs if the carbon capture system underperforms.

Which factors determine whether including such a liability clause is a good idea for NordCem AS? Discuss using economic theory.

### Guidelines

Students are expected to conduct a cost-benefit analysis (CBA) of the proposed clause, considering the costs and benefits for both NordCem and CleanCarbon Technologies. The clause should be included if it increases total welfare, as both parties can then be made better off by adjusting the contract price.

Students should also discuss the problem of asymmetric information, and how the clause could help reassure NordCem that CleanCarbon Technologies' claims about the system's performance are credible. (If the system were unreliable, CleanCarbon Technologies would likely be unwilling to accept a clause that makes them responsible for covering additional CO2 quota costs.)

#### Example of Cost-Benefit Analysis

| **Benefits of including the clause**     | **Costs of including the clause**            |
|------------------------------------------|----------------------------------------------|
| B1. Lower quota costs?                   | C1. CleanCarbon invests more in the system   |
| B2. NordCem spends less on maintenance   |                                              |

If CleanCarbon Technologies is made responsible for covering the additional CO2 quota costs, they will likely have stronger incentives to invest in improving the carbon capture system to avoid underperformance. This creates a cost (C1) for CleanCarbon but also a benefit (B1) for the system's overall effectiveness.

Giving CleanCarbon full responsibility would weaken NordCem's incentives to ensure the system operates properly. For example, they may reduce effort on temperature stability or routine maintenance, since they would no longer bear the financial consequences of underperformance. This reduces NordCem's maintenance effort (benefit B2) but may increase the risk of underperformance and higher quota costs compared to a situation where NordCem also had strong incentives to maintain the system.

Therefore, it is not certain that the clause would lead to lower quota costs. This is particularly true if NordCem plays an important role in ensuring that the system operates effectively in practice.

In general, whether the clause is a good or a bad idea depends on which party can most effectively control the additional CO2 quota costs.

To see this let's consider a numerical example. Assume:

1. CleanCarbon Technologies can invest 10 million NOK to improve the system.
2. NordCem can spend 10 million NOK to operate the system effectively.
3. The cost in additional CO2 quotas depends on their actions:
   - 0 million NOK if both NordCem operates effectively and CleanCarbon invests.
   - 10 million NOK if NordCem operates effectively but CleanCarbon does not invest.
   - 20 million NOK if NordCem does not operate effectively but CleanCarbon invests.
   - 40 million NOK if neither NordCem operates effectively nor CleanCarbon invests.

Without the clause, CleanCarbon Technologies would have no incentive to invest in improving the system, as they would not bear the cost of additional CO2 quotas. However, NordCem would have an incentive to operate the system effectively: careful operation would reduce the expected quota cost from 40 million NOK to 10 million NOK. The benefit from careful operation is therefore 40 - 10 = 30 million NOK, which exceeds the operation cost of 10 million NOK. Thus, the total expected cost would be 10 + 10 = 20 million NOK.

With the clause, CleanCarbon Technologies would have an incentive to invest in improving the system. However, NordCem would no longer have an incentive to operate the system effectively. As a result, the quota costs would end up at 20 million NOK. The total expected cost would then be 20 + 10 = 30 million NOK. Thus, under these assumptions, the clause would increase total costs and should therefore not be included.

Under different assumptions, this conclusion might change. For example, suppose the quota costs are:

- 20 million NOK if NordCem operates effectively but CleanCarbon does not invest.
- 10 million NOK if NordCem does not operate effectively but CleanCarbon invests.

In that case, the clause would reduce total costs and should be included. The reason is that CleanCarbon Technologies is now the party best positioned to reduce the CO2 quota costs at the lowest cost—in other words, CleanCarbon is the "least-cost avoider".

The factors determining whether including the liability clause is a good idea for NordCem AS are thus:

1. Which party can most efficiently control the cost of additional quotas:
   - If CleanCarbon's investments in developing and installing the system are the key factors for system performance, then including the clause is likely beneficial.
   - If the system's effectiveness heavily depends on NordCem's effort in maintenance or operation, the clause might be counterproductive.

2. Whether CleanCarbon possesses significant private information about the system's effectiveness.

Note that there may be even better clauses that provide *both* parties with incentives to reduce CO2 quota costs. For example, a clause could specify that NordCem is responsible for costs resulting from improper maintenance, while CleanCarbon Technologies is responsible for costs arising from technological failures or improper installation. (See Question 2.)

## Question 2

**25 points.** What other types of clauses could NordCem AS include in the contract to ensure that the carbon capture system performs as promised? Explain your suggestions using economic theory.

### Guidelines

Students may propose a variety of clauses. Grading should focus on whether the student shows understanding of relevant economic theories and applies them meaningfully. A strong answer should discuss at least two different clauses.

#### Example Clauses and Related Economic Theory

1. **Performance Guarantee**
   - CleanCarbon guarantees the system's capture rate (e.g., 90% CO2 capture efficiency).
   - *Theory:* Reduces problems of asymmetric information; signals product quality.

2. **Performance-Based Payment**
   - CleanCarbon's payment is tied to the actual performance of the system (e.g., amount of CO2 captured).
   - *Theory:* Aligns incentives to deliver a functioning system and to avoid hidden effort problems.

3. **Testing Before Final Acceptance**
   - Require independent third-party testing of the system's performance before full payment or final acceptance.
   - *Theory:* Reduces asymmetric information about system quality.

4. **Split Liability for CO2 Quota Costs**
   - Liability for additional CO2 quota costs is assigned based on the cause of underperformance:
     - If the underperformance is due to a system failure, CleanCarbon Technologies pays.
     - If it is due to poor operation by NordCem, NordCem pays.
   - *Theory:* Aligns incentives by ensuring that each party is responsible for the outcomes they can control.

5. **CleanCarbon Responsible for Operation**
   - CleanCarbon is made responsible for operating and maintaining the carbon capture system after installation.
   - *Theory:* If CleanCarbon controls both operation and maintenance, it is less problematic to include the Question 1 clause, as they then have full control over the system's effectiveness.


## Question 3

**25 points.** An employee at NordCem AS criticizes the government's large subsidies for carbon capture and says:
> "I don't really understand the government's thinking. They are spending billions to subsidize carbon capture here, but we don't get any support if we want to cut emissions in other, much cheaper ways—like switching fuels or producing different types of cement."

Under what conditions is the employee right to worry that subsidizing carbon capture—rather than supporting emissions reductions more generally—leads to an inefficient use of public resources? Discuss using economic theory.


### Guidelines

Students are expected to apply cost-benefit analysis (CBA) to assess under what conditions targeted subsidies for carbon capture could lead to an inefficient use of public funds compared to technology-neutral subsidies that support emissions reductions regardless of the method used.

Here is an example analysis. Assume:

- Carbon capture costs 1,500 NOK per tonne of CO2.
- Fuel switching costs 500 NOK per tonne of CO2.

Consider the following two policy options:
1. Carbon capture subsidy: The government covers NordCem's carbon capture costs.
2. Technology-neutral subsidy: The government subsidizes NordCem's CO2 abatement costs, regardless of the method used.

Suppose the government has a budget of 1.5 billion NOK to spend on subsidies. The resulting emission reductions under each policy would then be:

- **Carbon capture subsidy:** 1.5 billion / 1,500 = 1,000,000 tonnes of CO2.
- **Technology-neutral subsidy:** 1.5 billion / 500 = 3,000,000 tonnes of CO2.

The technology-neutral subsidy therefore achieves a greater reduction in emissions for the same cost. It represents a Kaldor-Hicks improvement over the carbon capture subsidy and is thus preferred according to cost-benefit analysis.

The example above illustrates that the employee's concern is justified under fairly general conditions. For a carbon capture subsidy to be preferable to a technology-neutral subsidy, it must generate additional benefits beyond the immediate reduction in emissions. Strong answers may speculate on what such additional benefits could be. For example, a carbon capture subsidy might create valuable knowledge spillovers that lower future costs of carbon capture technology. Alternatively, subsidies could be justified if carbon capture is the most efficient abatement method, but firms would be reluctant to invest under a technology-neutral subsidy due to perceived risks, high upfront costs, or liquidity constraints.

A rigorous analysis of learning externalities, firm risk preferences, or liquidity constraints is not expected.

## Question 4

**25 points.** CleanCarbon Technologies has delayed the delivery of the carbon capture system that NordCem AS ordered. As a result, NordCem has been forced to pay for additional CO2 quotas to cover emissions that would have been captured if the system had been operational on time. CleanCarbon refuses to compensate NordCem for these costs, and NordCem is considering filing a lawsuit. However, going to court would be expensive and could take a long time to resolve.

Which factors determine whether NordCem AS will file a lawsuit, whether the case will settle or proceed to court, and the likely size of any settlement? Discuss using economic theory.

### Guidelines

Students should use economic reasoning to discuss:
- What determines NordCem's incentives to sue.
- What determines whether the case settles or goes to court.
- What determines the size of a possible settlement.

#### Incentives to Sue

Students should argue that NordCem has an incentive to sue if the expected value of suing exceeds the cost of suing. If they are risk neutral, they have an incentive to sue if:

**Probability of winning × Damages awarded > Probability of losing × Legal costs**

The probability that NordCem will sue is thus:
- Increasing in the probability of winning.
- Increasing in the size of awarded damages (e.g., the cost of additional CO2 quotas).
- Decreasing in legal costs (e.g., court fees and lawyers' fees).

**Numerical example**

- NordCem's additional CO2 quota costs = 20 million NOK.
- Legal costs = 5 million NOK.
- Probability of NordCem winning = 70%.

Expected value of lawsuit:
- 0.7 × 20M NOK – 0.3 × 5M NOK = 12.5 million NOK.

With these numbers, NordCem would have an incentive to sue.

#### Settlement vs. Lawsuit

Students should discuss that even if pursuing a lawsuit is profitable, the parties might still prefer to settle out of court.

Using the numbers from the previous example, NordCem would be willing to accept any settlement above 12.5 million NOK (the expected value of the lawsuit). For CleanCarbon Technologies, the expected cost of the lawsuit is 0.7 × 20M + 0.7 × 5M = 17.5 million NOK. They would therefore be willing to pay any settlement amount below 17.5 million NOK. There is thus a wide range of settlement values that both sides would prefer over going to court.

We would therefore expect the dispute to be settled. Moreover, the higher the legal costs, the broader the range of possible settlement values.

They could, however, end up in court if:

1. **Both sides are overly optimistic.** For example, if CleanCarbon Technologies believes they have a 90% chance of winning, they would only be willing to settle for up to 2.5 million NOK (0.1 × 20M + 0.1 × 5M). In that case, there would be no settlement amount that both parties prefer over litigation. However, such large differences in beliefs are likely to be rare. If CleanCarbon has strong evidence or arguments in its favor, it has an incentive to share this information with NordCem to avoid a costly trial.

2. **There is a bargaining failure, such as due to asymmetric information about preferences.** For instance, NordCem might believe that CleanCarbon is highly risk-averse or fears reputational damage from a lawsuit, and therefore would be willing to pay a large settlement. NordCem might then demand a high settlement offer, even if doing so increases the risk that negotiations break down and the case proceeds to court.

Other reasons for going to court could include a desire to obtain a legal precedent or clarification of uncertain law.

#### Size of Settlement

Students are expected to use Nash bargaining theory to discuss the likely size of the settlement. In the numerical example above, the Nash bargaining solution is given by:

**(NordCem's Expected Value of Lawsuit + CleanCarbon's Expected Cost of Lawsuit) / 2**

Substituting in the values:

= (0.7 × 20M - 0.3 × 5M + 0.7 × 20M + 0.7 × 5M) / 2
= 0.7 × 20M + (0.7 - 0.3) × 5M / 2

Thus, the settlement value is increasing in:
1. The probability that NordCem wins the lawsuit (0.7).
2. The amount awarded if NordCem wins (20M NOK).
3. The legal costs (5M NOK), provided that the probability of NordCem winning is greater than 50%.

This analysis assumes that the parties value the lawsuit purely according to its expected monetary value. However, the subjective value of the lawsuit may also depend on:

1. Patience (lawsuits delay payments)
2. Risk preferences (lawsuits are risky)
3. Reputational concerns (a lawsuit might damage CleanCarbon's reputation if it reveals negative information publicly, rejecting a settlement offer might help signal toughness, etc).

These factors also affect the likely outcome of the settlement negotiations. For example, if CleanCarbon expects to suffer a reputational cost of 10 million NOK from a public lawsuit, the Nash bargaining solution would increase by 10M / 2 = 5M.
