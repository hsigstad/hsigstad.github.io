# How to Use This Notebook in *Law and Economics*

## 1. Purpose of this Notebook

This NotebookLM workspace supports a course in **Law and Economics** taught at a business school for students with **limited formal training in economics**.

The purpose of the course — and of this notebook — is to help students develop a **transferable analytical skill**:  
**applying economic reasoning to legal and business problems**.

This notebook is **not** a replacement for lectures, readings, or independent thinking. It is a learning aid designed to help you understand and practice the kind of reasoning the course teaches.

---

## 2. What This Course Is About

This course uses economic reasoning to analyze legal and business problems such as:

- How should an M&A transaction be structured?
- When should auditors be held liable for corporate misconduct?
- How should the law respond to anticompetitive behavior?
- How do liability rules affect precaution and risk-taking?

The core analytical framework is the **economic analysis of law (law and economics)**. Rather than focusing on legal doctrine or case law, the course emphasizes how legal rules operate **in practice** — how they shape incentives, allocate risk, and affect behavior under uncertainty.

Students learn a **small set of foundational economic models** and practice applying (instantiating) these models across diverse legal domains, including:
- Contracts and private ordering
- Corporate governance
- Tort law
- Competition (antitrust) law
- Regulation and enforcement

---

## 3. What the Exam Tests (Very Important)

The exam does **not** test memorization of doctrine or familiarity with specific cases.

Instead, it tests whether you can:

1. **Recognize** which economic model applies to a new, unseen problem  
2. **Instantiate** that model in a specific legal or business context  
3. **State assumptions explicitly**  
4. **Derive conclusions** using economic logic  
5. **Explain how conclusions change** when assumptions are weakened or violated  

This notebook should help you practice exactly this sequence.

---

## 4. How to Think About Economic Models in This Course

In this course, economic models are treated as:
- **Simplifying tools**, not literal descriptions of reality  
- Ways to clarify **incentives, tradeoffs, and strategic behavior**  
- Frameworks for disciplined reasoning, not mechanical answer generators  

Good economic analysis:
- Makes assumptions explicit  
- Explains *why* a result follows  
- Is clear about the limits of the conclusion  

The goal is **structured reasoning**, not mathematical sophistication.

---

## 5. How This Notebook Should Explain Things

When you ask questions, this notebook is expected to:

- Prefer **intuition over equations**
- Use **legal and business examples**
- Avoid unnecessary technical jargon
- Explain assumptions clearly
- Focus on **incentives, information problems, risk, and strategic interaction**
- Highlight where results depend on strong assumptions

If multiple interpretations are plausible, the notebook should explain the alternatives and what drives the differences.

---

## 6. Appropriate Uses of This Notebook

Appropriate uses include:

- Clarifying confusing passages in the readings or slides  
- Asking “why does this model predict X?”  
- Requesting alternative examples or applications  
- Checking your understanding after doing the reading  
- Practicing how to apply a model to a hypothetical scenario  

This notebook is especially useful for:
- Translating abstract models into concrete legal reasoning  
- Stress-testing arguments by changing assumptions  

---

## 7. Inappropriate Uses

This notebook should **not** be used to:

- Generate answers for exams or graded assignments to submit  
- Replace doing the assigned readings  
- Provide legal advice  
- Produce polished exam answers without your own reasoning  

Using the notebook effectively requires **active engagement**, not passive copying.

---

## 8. A Final Note on Learning Strategy

Economic analysis of law is a skill that improves through practice.

You will often feel uncertain about:
- Which model applies  
- Whether assumptions are realistic  
- How confident a conclusion should be  

This uncertainty is normal and productive. The purpose of this notebook is to help you **reason more clearly**, not to eliminate judgment or debate.

---

*Use this notebook as a thinking partner — not an answer key.*
