1. Tax Auditing
===============

To verify that firms and individuals pay their taxes, the tax authority conducts tax audits. Assume you are in charge of designing a tax audit program where you randomly select firms and individuals to be audited. You also determine the level of punishment if tax evasion is detected. How would you design an optimal tax audit program? Which factors would affect the design of the system? Use economic theory and give concrete examples.

What a Good Answer Should Include
---------------------------------

A good answer should use the economic theory of crime and cost-benefit analysis. The core of the analysis is how audit probability $p$ and the sanction $f$ jointly shape a taxpayer's choice to evade when the private benefit $y$ (tax saved) is compared to the expected sanction $pf$, and how the authority can vary $p$ and $f$ across observable groups to get deterrence at lowest real resource cost. A key constraint to be discussed is that not all taxpayers can pay large fines, so detection probability must be sufficiently high, for such groups.

Example Answer
--------------

A good answer should use the economic theory of crime and cost-benefit analysis. Here is an example of a possible answer.

First, consider the incentives of a tax payer owing an amount of taxes $T$. For simplicity, assume the tax payer can choose to either pay the tax or to declare that she has \"no income\" in an attempt to evade taxes. Let $p$ be the probability that the tax payer is audited and $f$ the punishment if the tax evasion is detected. For simplicity, assume that the tax evasion is detected if there is an audit.

She will then evade taxes if

$$ T > pf $$

In words, she will evade taxes if the amount she owes is larger than the probability of detection times the punishment. To deter the individual from evading taxes, the tax auditing program must be such that $pf > T$. Thus individuals that likely owe a lot of taxes must be audited with a high probability and/or punished by a lot. If the tax payer is able to pay a large fine, it is cheapest to obtain deterrence by selecting a large fine and a small audit probability, since auditing is costly. If the tax payer is not able to pay a large fine, we have to choose between auditing with a high probability (which is costly) and issue a fine the tax payer is able to pay, or use imprisonment as punishment. Imprisonment has large social costs so it might be better to increase the audit probability. This depends, however, on the cost of auditing versus the cost of imprisonment. It also depends on whether perfect deterrence can be obtained: If everyone is deterred from tax evasion, nobody has to go to prison, so we do not actually have to pay the social cost of imprisonment. Then a low audit probability with imprisonment as a punishment can be efficient. Finally, we have to think about the social cost of tax evasion. It might not be worth trying to deter all tax evasion. For instance, it might not be worth it auditing tax payers who likely owe very little in taxes. Paying €1000 to prevent someone from evading €100 in taxes is not worth it. Here is an example of a cost-benefit analysis

  Costs              Benefits
  ------------------ ----------------------
  Audit costs        Reducing tax evasion
  Punishment costs   

One should increase the audit probability and/or punishment as long as the benefits in terms of reduced tax evasion compensates for these costs. To sum up, the optimal system will

-   Audit and/or punish individuals likely to owe large sums of taxes more
-   Everyone should be audited with some probability. Thus the audit program must be randomized.
-   The audit probability should be relatively low and fines should be high as long as the individual is able to pay the fine
-   Individuals unlikely to be able to pay large fines should be audited with a higher probability and face smaller fines
-   Imprisonment could be cost effective if the threat of imprisonment is sufficient to deter a large share from tax evasion

One can also discuss

-   Long versus short prison sentences (as discussed in lecture)
-   The effects of different auditing strategies on inequality/fairness. Auditing with a low probability means that some are punished a lot but others are able to get away with their crime. This might not be desirable. The Kaldor-Hicks criterion does not take into account inequality. In reality, we care about inequality.
-   That we assumed the tax payer is risk neutral. If the tax payer is risk averse, less punishment is required.
-   What if an audit only discovers the tax evasion with some probability?
-   The social cost of tax evasion is not equal the amount of taxes evaded. It is probably less, since the tax evader benefits from it. E.g., an evasion of €100 costs the state €100 and benefits the individual €100. Tax evasion does, however, have social costs: €100 collected in taxes will (hopefully) be spent on something that is worth more than €100 to society (to provide public goods, infrastructure, etc). Also, one aim of the tax system is to redistribute from the rich to the poor. Cost-benefit analysis is blind to inequality, so it does not take into account this benefit.

2. Enforcement, Compliance, and Firm Liability
==============================================

Large financial institutions can face substantial penalties for failures in their anti--money laundering (AML) systems. A well-known real-world example is the enforcement actions against Danske Bank following large-scale money laundering through its Estonian operations. In that case, very large fines were imposed on the bank, even though neither senior management nor the firm's owners were directly involved in the misconduct at the Estonian subsidiary.

(a) Ensuring Employee Compliance
--------------------------------

Suppose a bank faces a large monetary sanction if employees fail to comply with required anti--money laundering procedures, such as customer due diligence and reporting obligations, even in the absence of direct involvement by senior management.

Analyze how the bank should ensure that its employees comply with required anti--money laundering procedures under this liability regime. In your answer, discuss which factors determine how the firm should design its compliance arrangements. Use economic theory.

What a Good Answer Should Include
---------------------------------

A good answer should use the economic theory of crime and cost-benefit analysis. The analysis should center on the employee's incentive to comply, comparing the private gain from cutting corners $y$ to the expected internal downside $pf$. A strong answer highlights that the bank can act on all three terms: raise $p$ through monitoring and verifiable documentation, raise $f$ through credible internal discipline, and also reduce $y$ by changing compensation, sales targets, and promotion criteria so that compliance is rewarded and noncompliance is not implicitly subsidized. The key determinants include the magnitude and likelihood of the external penalty, the observability/verifiability of AML steps, monitoring and enforcement costs at scale, and the extent to which the bank's own high-powered sales incentives inflate $y$ and thereby force costly increases in $p$ and $f$.

Example Solution
----------------

Under a regime where the bank is sanctioned when employees violate AML duties (even without senior involvement), the bank effectively bears the expected external sanction from employee noncompliance. The bank therefore has a direct incentive to reduce the probability that violations occur and to increase the probability that violations are detected early.

****Deterrence at the employee level**** Each employee compares the private benefit of cutting corners $y$ (saved time, higher sales commissions, avoiding "difficult" customers, meeting aggressive targets) to the expected internal downside. To make compliance privately optimal, the bank can work on both sides of the comparison: it can reduce $y$ by changing bonuses, targets, and promotion criteria so that revenue is not earned (or is not kept) when AML steps are skipped, and it can increase the expected internal downside $pf$. The key deterrence object on the sanction side is $pf$, where $p$ is the probability the bank detects a violation and $f$ is the internal consequence (loss/clawback of bonus, demotion, termination, etc.). If the bank cannot credibly impose a large $f$ (because employees are "judgment-proof" or firing is costly), it must rely more on raising $p$ through monitoring and verifiable documentation; if monitoring is costly, it becomes even more valuable to compress $y$ by weakening "high-powered" sales rewards that make shortcuts attractive.

(Illustration) If an employee gains $y=1$ from skipping checks and the bank's internal detection probability is $p=0.1$, deterrence via sanctions alone requires $f>10$. If such a penalty is not credible or would be too costly, the bank can (i) invest to raise $p$ so a smaller $f$ suffices, and/or (ii) redesign pay so the shortcut no longer yields $y=1$ (for example, by conditioning bonuses on verified completion of AML steps or by clawing back commissions when files later fail compliance review), which reduces how much $pf$ is needed in the first place.

****Designing the compliance arrangement: choosing $y$, $p$, and $f$**** Because monitoring and enforcement are costly (transaction costs), the bank should increase compliance inputs up to the point where the marginal cost of additional controls equals the marginal benefit from lowering the bank's expected external sanction (and other losses such as reputational damage). The bank has three levers:

-   Adjust $y$ (benefits from noncompliance): reduce the payoff to shortcuts by tying bonuses and targets to compliance-verified activity (not just volume), delaying payout until checks clear, using clawbacks for later-discovered breaches, and avoiding sales metrics that implicitly reward ignoring red flags.
-   Raise $p$ efficiently: automated flags, independent compliance review, random audits, dual control/separation of duties, and mandatory recordkeeping that makes compliance steps verifiable after the fact.
-   Choose a credible $f$: clear, escalating discipline for documented breaches, loss/clawback of variable pay, and promotion criteria that reward compliant performance rather than only short-term volume.

****Key determinants of the optimal mix****

1.  ****Magnitude and likelihood of the external sanction:**** Larger or more likely external sanctions justify stronger internal arrangements---either more investment in detection $p$, tougher credible consequences $f$, and/or stronger reduction of $y$ by weakening incentives for risky growth.
2.  ****Observability and verifiability of AML tasks:**** If tasks can be documented and checked cheaply, the bank can (a) raise $p$ at low cost and (b) make pay conditional on verifiable compliance, directly shrinking $y$. If violations are hard to verify, both $p$ and pay-contingencies become harder, pushing the bank toward process design that creates verifiable steps.
3.  ****Monitoring costs and organizational scale:**** In large, dispersed institutions, monitoring is costly; this increases the value of standardization and central oversight, but also increases the value of reducing $y$ so that the bank does not have to "buy" deterrence mainly through expensive increases in $p$.
4.  ****Strength of sales incentives and target pressure (the size of $y$):**** High-powered bonuses and aggressive targets can inflate $y$ and make noncompliance privately attractive. Rebalancing compensation toward compliance-verified measures can lower $y$ and reduce the needed intensity of $p$ and $f$.
5.  ****Credibility and side effects of internal sanctions:**** Very harsh sanctions may be costly (litigation, morale, concealment). Where $f$ is limited, deterrence must come more from raising $p$ and, importantly, from lowering $y$ by removing the internal rewards from cutting corners.

****Bottom line****

With firm-level liability for employee AML failures, the bank should treat compliance as an internal enforcement problem using all three levers: reduce employees' private gains from cutting corners $y$ through compensation and targets, raise the probability of detection $p$ through verifiable procedures and monitoring, and impose credible internal consequences $f$ when violations are detected. The optimal design depends on the expected external sanction, the cost of increasing $p$, the feasibility of imposing $f$, and how the bank's own incentive scheme affects $y$ and thus the cost of achieving deterrence.

(b) Firm liability
------------------

Why might policymakers impose large fines on the firm for failures to comply with AML obligations by individual employees or subsidiaries, even when neither firm owners nor top management were directly involved? Why not rely solely on sanctions against the individual employees who engaged in the misconduct? Discuss using economic theory.

What a Good Answer Should Include
---------------------------------

A good answer should apply cost--benefit analysis and the economic theory of crime (deterrence). It should explain how firm-level liability changes the firm's incentives to invest in AML controls by making the firm internalize the expected cost of employee misconduct.

The analysis should discuss why it may be cheaper for the state to rely on firm liability rather than directly monitoring individual employees. A strong answer explains this both in terms of information advantages (the bank observes employee behavior and internal processes more cheaply than the state) and instrument choice (the bank has more enforcement levers). In particular, the bank can not only increase detection $p$ and internal sanctions $f$, but also reduce employees' private gain from noncompliance $y$ through the design of compensation, targets, and promotion criteria.

Good answers should recognize the judgment-proof constraint on individual employees: if feasible individual sanctions are limited, achieving deterrence through individual liability alone would require a high---and costly---probability of detection. Because firms can pay large fines, holding the firm liable allows deterrence to be achieved with a lower public detection probability, reducing enforcement costs for the state.

Finally, a complete answer should make clear that both public monitoring costs and the firm's internal compliance costs must be included in the cost--benefit analysis, and that the optimal liability rule balances these costs against the reduction in expected harm from AML violations.

Example Solution
----------------

To answer this question we use cost--benefit analysis and the economic theory of crime.

**Key elements in the CBA**: The policy problem is to choose the liability regime that minimizes total expected social costs. These include:

-   **Expected harm**: the social cost of residual money laundering that is not prevented.
-   **Public enforcement costs**: monitoring, investigations, and prosecutions by the state.
-   **Private compliance costs**: the bank's spending on AML precautions (systems, monitoring, audits, training).

Fines themselves are mainly transfers between the firm and the state and are therefore not real resource costs; they matter only through how they change incentives.

**Individual vs. firm liability**: If liability were imposed only on individual employees, the bank could save on compliance spending. However, individual employees are typically judgment-proof: there is a cap on how large a fine they can pay. As a result, deterrence would require a high probability of detection $p$, which is costly for the state to achieve through monitoring and investigations.

By contrast, firms can pay large fines. This allows deterrence to be achieved with a lower public detection probability, reducing public enforcement costs.

**Short numerical example**: Suppose an employee gains $y=10$ from ignoring AML rules. The maximum feasible individual fine is $f=20$. To deter misconduct through individual liability alone, the state would need a detection probability of $p=0.5$, so that the expected sanction $pf$ is at least 10. Achieving such a high detection probability is very costly because violations are hidden and proof is complex. Now suppose the firm can ensure employee compliance by investing in internal AML controls at a cost of 5 per employee (monitoring, training, and audit trails). If a firm-level fine of $f=200$ applies with a public detection probability of only $p=0.05$, the expected sanction is $pf=10$, which exceeds the cost of compliance. The firm therefore invests in compliance, employees comply, and expected laundering harm is reduced---while the state only needs a low detection probability.

**Why firm liability is cost-effective**: It is often cheaper for the bank to ensure employee compliance than for the state to monitor employees directly. The bank has an information advantage---it observes internal processes and behavior more cheaply---and it has more instruments. In addition to monitoring and discipline, it can reduce employees' private gain $y$ from noncompliance by designing compensation, targets, and promotion criteria that do not reward cutting corners. These internal levers can lower expected harm at lower total cost than relying on public enforcement alone.

**Role of public monitoring**: Public monitoring is still necessary. For the firm to have incentives to invest in compliance, there must be a positive probability that violations are detected externally. However, because firms can pay large fines, this probability can be relatively low compared to an individual-liability regime.

**Why include subsidiaries**: If liability were limited to subsidiaries, firms could concentrate risky activities in thinly capitalized units that cannot pay large fines, undermining deterrence. Consolidated firm liability prevents organizational structure from diluting expected sanctions.

**Bottom line**: Firm liability is justified when it lowers total expected social costs by inducing cost-effective private precautions and allowing deterrence with a lower public detection probability. Individual-only liability often fails because sanctions are capped, making effective deterrence rely on expensive monitoring and still risking under-deterrence.

3. Beyond Reasonable Doubt
==========================

In criminal cases, defendants should not be convicted unless their guilt is established \"beyond reasonable doubt\" (utover enhver rimelig tvil). This could lead to situations that seem unjust. For example, assume \"beyond reasonable doubt\" means 99% sure. Then we can have the following cases:

-   Due to strong DNA evidence (e.g., from bodily fluids), the judge is 99% sure that defendant A committed homicide and sentences him/her to 21 years of prison

-   Due to weaker DNA evidence (e.g., \"touch DNA\"), the judge is 98% sure that defendant B committed homicide and aqcuits him/her

A small change in the probability of guilt generates a very large difference in punishment. Why do we treat A and B so differently? Why should we punish B with zero years of prison? Why not just punish B a bit less than A due to the lower likelihood of guilt? Discuss using economic theory.

Example Answer
--------------

A good answer should use the economic theory of crime and cost-benefit analysis. Here is an example of a possible answer.

For the sake of simplicity, assume there is a 40% probability that the defendant leaves strong DNA evidence, a 40% probability that the defendant leaves weak DNA evidence, and a 20% probability that the defendant leaves no evidence.

Consider the following possible rules:

Rule 1

:   21 years for strong DNA and 0 years for weak DNA

Rule 2

:   14 years for strong DNA and 7 years for weak DNA

Note that these two rules give the same cost to society (measured by the expected years that someone has to spend in prison):

$$ 21 \times 0.4 + 0 \times 0.4 = 8.4 = 14 \times 0.4 + 7 \times 0.4 $$

The key difference between the two rules is, however, that Rule 2 leads to more punishment of innocents (weak DNA evidence leads to a 2% probability of punishing an innocent). This fact could decrease deterrence. To see this, assume someone is contemplating homicide and worries about the expected years in prison.

-   Rule 1 gives expected years in prison of \$21  × 0.40  × 0.99 = 8.3 \$
-   Rule 2 gives expected years in prison of \$14  × 0.40  × 0.99 + 7  × 0.40  × 0.98 = 8.29 \$

Rule 1 thus leads to stronger incentives to abstain from homicide. (Though the difference is very small in this example). Rule 1 is thus better: It causes more deterrence at the same cost as Rule 2. In terms of cost-benefit analysis, the two rules have the same costs, but Rule 1 has more benefits in terms of reduced crime.

In general, for a given amount of punishment (e.g., sum of years of prison) it is always optimal to target the punishment on the defendants most likely to be guilty. Thus it is optimal to have large punishments for those guilty \"beyond reasonable doubt\" and no punishment for defendants with a \"reasonable doubt\". Exactly where this cutoff is (e.g., whether at 99% or 95%) might depend on the setting.

Note that we did not reach this conclusion because we assumed that we cared more about the suffering of innocent prisoners than guilty prisoners. We assumed we cared equally about their suffering.

Our conclusion relied on two important assumptions:

1.  **Assumption 1:** Defendants care about the expected years in prison
    -   In reality, defendants might be more deterred by a 80% probability of a 10 year sentence than a 40% probability of a 20 year sentence. Thus, Rule 2 might, in practice, lead to more deterrence (and thus be preferred).
2.  **Assumption 2:** The cost for society of punishment equals the sum of years that someone has to spend in prison
    -   In reality, society might also care about inequality. Rule 1 leads to more inequality (defendant A spends 21 years in prison and defendant B spends 0 years). Preferences for inequality could be another reason to prefer Rule 2.
