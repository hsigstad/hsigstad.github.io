# Lecture Transcript: 6Tort

## About This Document

This is a transcript of lectures from the course **GRA6296 - Economic Analysis of Topics in Law** at BI Norwegian Business School, taught by Henrik Sigstad.

**Slide deck:** 6tort.pdf
**Lecture date(s):** January 27, 2026, February 03, 2026

This transcript has been cleaned for readability. The original was auto-generated from lecture recordings using OpenAI Whisper.

---

## January 27, 2026

### Slide 7 - The Auditing Case

Okay, here is my complete numerical example. You audit a firm's financial statement. You know that investors will invest one million euros if you issue an unqualified opinion. If you say that the statement is correct and you're reasonably sure it is, the investors will invest one million.

If the firm turns out to be a fraud, all this money is lost. You know that 5% of all the firms in the country are frauds, so fraud is quite common.

The firm claims it has one billion euros divided equally across 1,000 bank accounts. If the firm is a fraud, 20% of the bank accounts are fake. If it's honest, then all are true. It costs 100 euros to verify one account. With these assumptions, I will calculate the optimal audit in this case using cost-benefit analysis.

This assumes that fraud is quite prevalent, so we might expect a bit more auditing than we would otherwise. We also assume that the cost of verifying an account is reasonable, but maybe it's high nowadays. Perhaps you just send an email; it's not that costly. I'm not sure.

### Slide 11 - The Optimal Number of Accounts To Verify

Okay, here is the picture. These are the bank accounts. The fraudulent firms will have zero in 20% of the bank accounts.

The honest firm will have one million in all of them.

You start with the firm. You don't know anything, and you decide how many of these accounts to check.

Let's assume that you check one bank account and the money is there.

How sure are you that the firm is not a fraud after checking just one account?

You can discuss with your neighbor briefly before you answer.

I don't expect you to do the math here.

Okay.

I'm going to show the responses now, so if you want to submit before seeing them, you can do it now.

All right, very good. Four of you guessed 96%. That's cheating, but three of you got it right.

You already think it's 95% sure that it's not a fraud because we start with a situation where only 5% of firms are fraud. If you don't know anything about the firm, you think it's 95% sure that this is not a fraud. After checking one account, it turns out you're a little bit more sure. You're 96% sure in this case after checking one account.

You don't have to do the math here because it's a bit difficult. You're not required to calculate these exact numbers.

Now let's assume that you checked five accounts and they all contain the cash they claim to have.

Here is the formula that I don't require you to know, but just to be totally transparent, this is how you calculate this probability after seeing N accounts where the money is all there. This is the probability that the firm is not a fraud.

You can apply this formula. After checking one account, the probability that the firm is a fraud is 4%. After checking five accounts, the probability is 1.7% that it's a fraud. By checking more accounts, you reduce the probability that this is a fraud.

It will look something like this. The probability of the firm being a fraud decreases as the number of accounts checked increases. If you check 40, then it's very close to zero.

So we want to calculate the benefit of checking accounts and compare it to the cost. That's the cost-benefit analysis we're going to do. The benefit of verifying accounts is first the decrease in the probability of fraud. When you check the fifth account, the probability of fraud goes down by 0.4 percentage points, from 2.1% to 1.7%.

The benefit of that is multiplied by what the investors are going to invest. The investors here are going to invest 1 million. 1 million times 0.4 percentage points is 4,000.

That's the expected benefit of checking the fifth account.

The cost of verifying the account is easy; it's 100 euros by assumption.

### Slide 12 - The Optimal Number of Accounts To Verify

The benefit of checking one more account, the 11th account, is still 900 euros, which is higher than the cost. So you should continue checking accounts all the way until 21.

### Slide 36 - The Auditor’s Best Strategy Under Strict Liability

After checking 21 accounts, the probability that the firm is a fraud is 0.05%. It's extremely low. You could reduce this probability by checking more accounts, but it's not worth it because the benefit would be 97 euros and the cost would be 100 euros. This gives us the optimal number of accounts to check if we care about reducing the total cost. We're reducing the total cost of fraud plus the cost of actually doing the audit. Even though there are 1,000 accounts, you should only verify 21. Checking more than that is too costly for society. We shouldn't force auditors to check everything because after checking 21, we're extremely sure that this is not fraud. It's not reasonable to check more because it's costly, and the costs outweigh the benefits. All right, so we're going to continue this discussion next week, and we're going to connect to torts.

## February 03, 2026

### Slide 2 - Chapter 6

Great. That was it about auditing. Now we're going to talk about tort law using the auditing case as an example.

The reason we have this auditing case is that we're going to use it in tort law. It's also an interesting case because some of you might end up working with it.

I'm not an expert on auditing, so if you're going into that profession, you should not trust everything I say.

### Slide 3 - II. An Economic Theory of Tort Liability

This is chapter six in the book.

### Slide 4 - An Accident

Okay.

This is the second section of that chapter. This is an accident. In this case, you can sue the person who crashed into your car. That's tort law. There are many other kinds of accidents, and for each of these accidents, there will also be precaution.

### Slide 5 - Examples of Accidents and Precaution

For example, the precaution when hitting another car is to be more careful when parking.

These are examples of accidents and the kind of precaution that the injurer can take. Sometimes the victim can also engage in precaution. For instance, if the victim parked the car in a very inconvenient way and the other driver crashed into it, the victim might also share some blame.

### Slide 6 - An Economic Theory of Tort Liability

We will consider both the precaution of the injurer and the precaution of the victim.

This is the economic theory. It's the same notation we used for the auditing case, but it can be applied more generally. X can represent the level of precaution. In our case, it was the number of bank accounts verified. W is the cost per unit of precaution, which in our case was the cost of checking one more account. A is the harm from an accident. In our case, the accident would be undetected fraud, leading to investors losing money. So A is the money that the investor loses in case of fraud. However, A can represent any kind of harm in this general theory of tort. P is the probability of an accident. The more careful you are, the less likely the probability of an accident. In the auditing case, the more accounts you verify, the lower the probability of undetected fraud. We will think about the optimal precaution that minimizes the total cost of precaution and accidents. In the auditing case, we're minimizing the total cost of the audit and the cost of fraud.

So this is the framework translated to our auditing case. On the exam, you should be able to apply this framework to any kind of tort setting or any setting where there is some precaution and some accidents, like in the auditing case.

### Slide 9 - Other Examples of Auditor Precaution

Here is the example of auditor precaution, checking many transactions. External confirmation, such as checking bank accounts, was the example we used, but there could be other ways of engaging in a more careful audit.

### Slide 10 - The Optimal Level of Precaution

There will be an optimal level of precaution, as in the case with audits. X star was 21 accounts. For any other tort setting, there will be an optimal level of precaution. For example, driving at one kilometer per hour is too much precaution. That's very costly for society, even though it would reduce accidents to zero. So in these settings, there will be an optimal level of precaution, and we will think about what that optimal level is.

This is the picture from the book, basically the same as I showed you in the auditing case. There will be the cost of accidents here, which is the probability of accidents times the loss when there's an accident, and the cost of precaution, which is the cost per unit of precaution times how much precaution you're engaging in. We sum these two lines to get the total cost of precaution and accidents. The optimal level of precaution is the one that minimizes this total cost.

### Slide 13 - How Can We Ensure Optimal Precaution?

The question we will consider when talking about tort law is how we can ensure optimal precaution and how we can design tort law to encourage people to engage in this optimal level of precaution. Our hope is that tort law is structured to ensure that people are not engaging in too much precaution, but also not too little.

Whether that's the case in practice is an empirical question. I won't be able to answer that. However, there are ways in which the basic structure of tort law can be explained as aiming to give incentives for optimal precaution. This will be a lens through which to understand tort law.

### Slide 14 - Strict Liability (objektivt ansvar)

Let's talk about strict liability, which is objektivt ansvar in Norwegian, and then we will discuss negligence, uaktsomhet, in the next lecture.

### Slide 15 - Strict Liability (objektivt ansvar)

Strict liability means that the injurer is liable for any harm caused to the victim, regardless of whether the injurer was precautious or not. In some settings, this is the standard. For auditing, that's not the standard. But for other kinds of settings, there is strict liability.

Even if you were precautious, you will still be liable for the harm you cause to anyone else.

### Slide 16 - Strict Liability (objektivt ansvar)

In the auditing case, auditors are liable for any harm they cause investors. If there is fraud, like in the Wirecard case, the auditors are liable for the full cost of that fraud. That's a potential rule. In practice, auditors are only liable if they did not conduct a careful audit. But you can imagine a world where auditors are liable no matter what. If there's fraud, the auditor is liable.

### Slide 17 - Strict Liability (objektivt ansvar)

In this rule, if there is an accident, the injurer will compensate. The victim will pay D equal to the harm in damages. The victim will be perfectly compensated for the harm. In the auditing case, the auditing company, KPMG or Ernst & Young, will compensate the investors for everything they lost, regardless of whether the auditing company did a good or bad audit.

### Slide 19 - How Should Damages Be Calculated?

An important thing to think about is how damages should be calculated. We'll discuss later what this rule does to incentives for precaution or for conducting a good audit. But first, let's talk about how these damages should be calculated.

### Slide 20 - How Should Damages Be Calculated?

We could have an entire course on just that, but here’s a brief overview. It's not obvious how to do it. Assume that an investor held 100 shares in Wirecard since 2017.

In 2020, the stock price collapsed from €150 per share to zero. How much should the investor receive in damages? The damages should compensate the investor for the losses.

### Slide 21 - Mentimeter

Should it be 15,000, less than 15,000, more than 15,000, or is it impossible to know? Talk to your neighbor and then answer once you have something.

### Slide 25 - The Share Price Was €50 in 2017

In 2017, the stock price was about 50 euros per stock. The amount that the investor lost was 50 times 100. But you also have to consider what the investor would have gained in an alternative investment, like the general rise of the stock market during that period. The number is going to be much less than 15,000.

### Slide 26 - Calculating Damages

If Ernst & Young had done its job, they would have discovered the fraud before 2017. The investor would not have invested in Wirecard because they would have understood it was a fraud. They would have invested the money somewhere else.

The same position as they would have been without the tort, where the tort is what Ernst & Young was doing: a bad audit.

Assuming that the return on these alternative stocks would have been 10% per year, the loss would have been 6,655 euros.

This is how you would calculate damages in this case. It's not obvious how we calculate damages, and we could have an entire course about it in tort cases. But I'm just going to show you this example. On the exam, you have to think about what the actual damages are in this case.

### Slide 27 - Correct Answer

Thank you.

Some think it should be less than 15,000, while others think it should be 15,000. Why 15,000? Probably because the investor had 100 shares worth 150, and the value went to zero. 150 times 100 is 15,000.

That is the logic for those who selected 15,000. However, the correct answer is less than 15,000. Can anyone explain why? Yes.

The share price of 150 was inflated because it was a fraudulent firm. Investors should be compensated accordingly. So, the share price of 150 was partially due to a boom caused by fake profit statements, and the investor shouldn't be compensated the full amount. Instead, the investor should be compensated for what they lost, considering that they had also gained a lot since 2017 due to this fake rise in the share price. The general aim of damages in tort is to put the injured party in the same position they would have been if the tort had not occurred. The key question is, in which position would the investor have been if Ernst & Young had done its job?

### Slide 40 - Strict Liability Gives the Auditor Optimal Incentives

We're running out of time. I think it's better to stop here and just tell you that next week we're going to talk about how strict liability gives auditors incentives to do a good audit and whether strict liability gives the auditor incentives to audit too much, too little, or the optimal amount.

### Slide 41 - Next lecture: Negligence

You probably cannot start with the second assignment by now because we didn't reach this part. So you can hold off on answering the first assignment until after the next lecture. See you next week.
