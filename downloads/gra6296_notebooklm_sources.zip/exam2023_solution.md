# GRA6296 Exam Solution Example
**Spring 2023**
**Author:** Henrik Sigstad

## General Guidelines

There are many potential answers to these questions and the candidates should be graded based on the extent to which they demonstrate that they have understood the course material. The students have received the following guidelines for answering the exam:

> It is your task to demonstrate that you have understood the course material. Answer the questions in a way that demonstrates your understanding:
>
> 1. Use concrete examples related to the question. (If your examples are connected to the specific case discussed in the question you show that you have not just memorized the course material, but that you have *understood* it)
> 2. It is a good idea to use concrete numerical examples to make your points
> 3. Explicitly use the theory discussed in the course in your answers. Example, if your answer relies on cost-benefit analysis, explicitly state that you use cost-benefit analysis and explain why it is relevant.
> 4. Explicitly state the assumptions behind your analysis. If possible, also state how your conclusions would change if your assumptions do not hold.

## Question 1

A start-up tech company develops AI-powered apps for its customers. Since the company is low on cash, it prefers to receive half the payment before it starts developing the app. The remaining half of the payment is paid when the company delivers the app to the customer.

**10 points.** A potential customer wants to develop an app but is worried that the company will break its promise and not deliver the app after receiving the first half of the payment. Is the potential customer right to worry? Explain using economic theory.

### Example answer

One can think of this setting as a game where the customer first decides whether to pay the first half, the company then decides whether to deliver the app, and finally the customer decides whether to pay the remaining half of the payment. As a concrete example, assume the app costs 80 to develop and is sold for 100. The customer is then supposed to pay 50 up front and 50 when the app is delivered. If the company faces no legal or reputational consequences for not keeping its promises, the company will not have incentives to deliver the app after receiving the first 50. Even if the customer can be trusted to pay the last 50, the company will lose 30 by developing the app. In this case, the customer is right to worry that the company will break its promise.

## Question 2

**40 points.** To attract customers, the company needs to convince customers that its promises of delivering apps are trustworthy. How can the company increase its customers' trust in the promises? Think of as many solutions as possible. For each solution, explain which factors determine whether the solution is likely to work and why these factors matter. Use economic theory and give concrete examples.

### Example answer

As mentioned in the answer to Question 1, the company could have incentives to deliver the app if they face legal or reputational consequences from not holding its promises. The company can thus increase its customers' trust in them by increasing the legal or reputational consequences from not holding its promises. I will consider three such ways: (i) signing a formal contract enforceable in court, (ii) increasing reputational incentives, and (iii) building relationships with customers.

#### Formal contracts

With a formal contract, the customer can sue the company for not delivering the app. The threat of a lawsuit might be sufficient to give the company incentives to deliver the app. Signing a formal contract can thus increase the customers' trust in the company's promises. For this to work, it is necessary that the customer has sufficient incentives to sue in case of breach of contract and that the punishment for breach of contract is sufficiently high.

To think about which factors increase the likelihood that formal contracts will work, consider the following simple example. Assume the cost of a lawsuit is 20, payed by the loser of the lawsuit. Assume the customer wins with probability 90% if the company has not kept its promise. If the company wins, the judge awards expectation damages of 120 (assuming the customer values the app at 120). In this case, the customer has incentives to sue. Suing gives 0.9 × 120 - 0.1 × 20 = 106 in expectation. Assume the parties settle (no asymmetric information) through Nash bargaining. The value of the lawsuit for the customer is 106. The customer will accept any settlement above this. The cost of the lawsuit is 0.9 × 140 = 126 for the company. The company will accept any settlement below this. The Nash bargaining solution is in the middle: (106+126)/2 = 116. If the company does not develop the app, the customer will credibly threaten to sue and the company is forced to settle at 116. Developing the app costs 80. Thus the company prefers to develop the app. In this case, the formal contract makes the company trustworthy.

There are situations, however, where a formal contract might not give the company sufficient incentives. For instance, if a lawsuit takes a long time and the parties are very impatient (strong preference for cash now as opposed to in the future---perhaps due to credit constraints). In particular, assume the lawsuit takes four years, paying 120 in expectation damages after four years (including an interest adjustment) is equivalent to paying 60 now for the company, and receiving 120 after four years is equivalent to receiving 60 now for the customer. Then the value of the lawsuit is 0.9 × 60 - 0.1 × 20 = 52 for the customer and 0.9 × (-80) = 72 for the company. They then settle at (72+52)/2 = 62. In that case, the company has incentives to not deliver the app, save 80, and instead pay 62 in settlement.

Another situation in which formal contracts can fail to give sufficient incentives is when the customer does not have incentives to sue (and thus can not credibly threaten to sue). This can happen when the customer has to pay its own legal fees even when they win (see the answer to Question 4), the customer is risk averse (lawsuits are risky), or when the probability of winning in court is low (e.g., due to judicial errors or lack of evidence).

#### Reputations

If the company cheats on one customer by not delivering the specified app, future potential customers might be reluctant to deal with the company. In other words, the company has incentives to keep its promises to maintain its reputation. For reputational incentives to work well, potential customers needs a way to learn about the past behavior of the company. To increase their reputational incentives (and their trustworthiness), the company can thus seek to make information about their behavior more accessible. For instance, the company might choose to operate in online marketplaces where they can be rated by their customers. Customers can then trust the company more: They know the company has incentives to keep their promises to avoid bad ratings. This is more likely to work if the consequence of a bad rating for the company is high (e.g., many potential customers check the site and regard it as trustworthy) and the temptation to cheat is low (e.g., the app they have promised is relatively cheap to develop so they gain little by cheating).

#### Relationships

If a customer has a long term relationship with the company, the company might have incentives to keep their promises with respect to this customer to not destroy the relationship. As a concrete example, assume there is always a 90% chance that the customer will need a new app from the company in the future. Since the company profits 20 from each app, the value of the relationship with this customer is 0.9 × 20 + 0.9² × 20 + 0.9³ × 20 + .... Since this value is larger than what the company can get from cheating (30), the company has incentives to keep its promises with respect to this customer. This customer can thus trust the company.

Such a relational contract is more likely to work if (i) the temptation to cheat is low (e.g., each individual app is small), (ii) the likelihood of future collaborations is high, and (iii) the company's profit from each app is high. The company can thus increase the chance that a relational contract works by for instance splitting up each app into smaller parts (and pay after each part is completed) and make sure that both they and the customer invest in increasing the profitability of their partnership.

#### Paying in the end

A final solution is to let the customer pay everything in the end, after receiving the app. The company then has incentives to develop the app: By developing the app at cost 80 they receive 100 in payment. Their customers can thus trust the company to develop the app. This solution requires the company to trust that the customer will pay after receiving the app. If the company does not trust the customer to pay, they can use escrow: A trusted third party (the escrow agent) receives the payment from the customer. The payment is released to the company after the customer receives the app.

## Question 3

**25 points.** A customer requests an app that the company fears could be difficult to develop. To reduce risks, the company wants to have the option to breach the contract and pay damages if the app turns out to be too costly to develop. The company wants to include a term in the contract that explicitly states the amount to be payed in damages in case of breach of contract. How large would you recommend this amount to be? Explain using economic theory.


### Example answer

Assume the app is worth 120 to the customer. With probability 50% it costs 80 to develop the app, but with 50% it costs 150 to develop the app. If the cost is 150, it is not worth it to develop the app. (Formally, it is not a Kaldor-Hicks improvement: The customer's gain of 120 is lower than the company's cost of 150.) Breach of contract is thus optimal in that case. If the amount to be payed in case of breach is above 150, the company is incentivized to develop the app even when it is costly. An amount of 150 is thus too high and is inefficient. Ideally, the contract should incentivize the company to develop the app if and only if the cost is below 120. Only in that case is it worth it (a Kaldor-Hicks improvement) to develop the app. Thus, I would recommend this amount to be 120, the customer's valuation of the app. This value corresponds to "expectation damages", a level of damages that makes the customer indifferent between receiving the app and receiving the amount payed in damages. This amount ensures that the contract is always Kaldor-Hicks efficient: The app will be produced if and only if it is Kaldor-Hicks efficient to do so. Since efficient contracts create the most value, both the customer and the company can be made better off from this increase in efficiency. (Exactly how they share the gain depends on their bargaining power.)

One complication to this argument arises if for instance the customer can invest in complementary technology, *relying* on the company's promise to develop the app. Investing in complementary technology can increase the value of the app for the customer, from 120 to say 140. Under standard expectation damages, the customer should then be compensated with 140 for breach of contract. This might not be efficient, however. In particular, the customer gets too strong incentives to rely on the contract---the customer does not take into account the 50% probability of breach. It might be socially efficient to wait with investing in the complementary technology until the company has delivered the app. To give the customer right incentives to rely on the contract, the optimal level of damages is instead "hypothetical expectation damages"---the customer is compensated only for the "hypothetical harm" that it would have suffered if it had not over-relied. For instance, if it was socially optimal to wait investing in the complementary technology, the customer should be awarded only 120 in damages not 140. In the United States, the doctrine of foreseeability can be seen as an implementation of this rule. According to that doctrine, the customer will only be compensated for reliance that the company could "reasonably" expect the customer to take.

## Question 4

**25 points.** Assume the company wants to expand to the United States. There, each party to a lawsuit pays its own legal fees irrespective of the outcome of the case. How does this change in the legal environment affect the company's incentives to keep its promises? Which factors does your answer depend on? Explain using economic theory.

### Example answer

Assume the cost of a lawsuit is 20. In Norway, the loser typically pays this cost. Assume that in the United States, each party pays 10 irrespective of the outcome of the case. Assume the customer wins with probability 90% if the company has not kept its promise. If the company wins, the judge awards expectation damages of 120 (assuming that the customer values the app at 120). Assume the parties settle (no asymmetric information) through Nash bargaining. To compare the two rules, consider the following table

|                               | Norway                        | United States              |
|-------------------------------|-------------------------------|----------------------------|
| Legal fees                    | 20 paid by loser              | 10 paid by each            |
| Value of lawsuit for customer | 0.9 × 120 - 0.1 × 20 = 106    | 0.9 × 120 - 10 = 98        |
| Cost of lawsuit for company   | 0.9 × 120 + 0.9 × 20 = 126    | 0.9 × 120 + 10 = 118       |
| Settlement (Nash bargaining)  | (106+126)/2 = 116             | (98+118)/2 = 108           |

In the US, the lawsuit is less attractive for the customer and more attractive to the company. The company's bargaining position is thus strengthened and they settle at a lower value. In this example, the company still has incentives to keep its promises (develop the app at cost 80 instead of settling at 108). The US rule, however, has a tendency to decrease the company's incentives. For other numbers, the company might not have sufficient incentives to keep its promises. For instance, if the customer's valuation of the app is 105 and the cost of developing the app is 95, we get:

|                               | Norway                          | United States                |
|-------------------------------|---------------------------------|------------------------------|
| Legal fees                    | 20 paid by loser                | 20 paid by each              |
| Value of lawsuit for customer | 0.9 × 105 - 0.1 × 20 = 92.5     | 0.9 × 105 - 10 = 84.5        |
| Cost of lawsuit for company   | 0.9 × 105 + 0.9 × 20 = 112.5    | 0.9 × 105 + 10 = 104.5       |
| Settlement (Nash bargaining)  | (92.5+112.5)/2 = 102.5          | (84.5+104.5)/2 = 94.5        |

In this case, the company can not be trusted to develop the app (at least based only on legal incentives). From this example, we see that moving to the US might reduce the trustworthiness of the company in developing apps where the customer's valuation of the app is not much above the cost of developing it.

Another key observation is that if the cost of the lawsuit becomes excessively high compared to the disputed amount, the customer might not have incentives to sue. For instance, if the cost of the lawsuit is 1000, the customer gets 0.9 × 120 - 1000 = -892 from suing. The customer's threat of suing is not credible. The formal contract does then not provide the company with incentives to deliver the app. Note that this can also happen if the value of the app is low. If the value of the app is 10, the customer gets 0.9 × 10 - 10 = -1 from suing.

To conclude, moving to the US reduces the company's incentives to keep its promises. This is especially the case when (i) the cost of lawsuits are high, (ii) the value of an app is small, (iii) the customer's valuation (and thus expectation damages) is not much higher than the cost of developing the app.
