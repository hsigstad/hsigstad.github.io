# Lecture Transcript: 3Why Criminal Law

## About This Document

This is a transcript of lectures from the course **GRA6296 - Economic Analysis of Topics in Law** at BI Norwegian Business School, taught by Henrik Sigstad.

**Slide deck:** 3why_criminal_law.pdf
**Lecture date(s):** January 13, 2026, January 20, 2026

This transcript has been cleaned for readability. The original was auto-generated from lecture recordings using OpenAI Whisper.

---

## January 13, 2026

### Slide 2 - How To Prevent Fraud

All right, so after the break, we're going to talk about what I alluded to: the best way of fighting crimes in terms of increasing the probability of detection versus increasing the punishment.

### Slide 9 - Chapter 12.II.A

Before we continue, let me briefly talk more about cost-benefit analysis and whether we can use it in a criminal law setting. Here is an example where you might think it’s not such a good idea. Think about Robin Hood, who took from the rich and gave to the poor. That is a crime, and in terms of cost-benefit analysis, it decreases the value in society because the rich need to spend a lot of money to protect themselves from Robin Hood, and Robin Hood needs to hide in the woods. There are many costs here, even though whatever Robin Hood steals from the rich is given to the poor. The amount stolen is not the real cost of that theft; the social cost includes the rich not feeling safe about their properties and not investing. So in terms of cost-benefit analysis, we should make what Robin Hood was doing a crime. However, Robin Hood was also redistributing wealth, which increases equality in society. So maybe we should allow those crimes because they benefit the poor. This suggests that cost-benefit analysis may not be a good tool in criminal settings. The counter-argument is that it might be better to make that a crime and then redistribute wealth in a more efficient way through the tax system. We could tax the rich and transfer to the poor instead of letting the poor steal from the rich, as that theft is very socially costly, while taxation may be less so. This is a more efficient way of redistribution. If you agree with that counter-argument, then we can say that we can use cost-benefit analysis in criminal law when thinking about redistribution through the tax and benefit system. This is one way to argue for using cost-benefit analysis here, even though there are many distributional issues in criminal law, as many criminals are poor.

Right.

You might disagree with what I just said, but this is the justification for using cost-benefit analysis.

### Slide 10 - A Simple Model

Let's go to the question: what is the best way of deterring crime? Think about the punishment. The fine can be 10, and the probability of detection is one, meaning you will always be detected and have to pay the fine of 10. The expected punishment is 10. However, there could be another way to create the same level of deterrence, which is to have a 50% probability of detection and a punishment of 20. So, 20 times 50% is also 10.

You could also have a 10% chance of being detected and a 100 fine, which also gives an expected punishment of 10. All four of these different ways of fighting crime provide the same deterrence. If the profit from committing the crime is lower than 10, then you wouldn't do it.

These ways of fighting crime are equally effective in terms of preventing it.

But which one should we choose? Should we go for a 10% chance of a 10-euro fine or a 100% chance of a 20-euro fine with a 50% probability? Talk briefly to your neighbors before you answer and think about the economics of this, the cost-benefit analysis.

Thank you.

Thank you.

Okay, so I'll give you one minute more to respond, and then I'm going to show the answers.

Thank you.

All right. Interesting. You went for the extremes: either 100% probability of detection or the lowest possible. Can anyone try to defend any of these options?

Even if you cannot connect it to economic theory, what is the reason for selecting this one or that one?

Yes.

Good point. The fine is quite small, so if the benefit of committing this crime is higher than 10, you're going to do it and just take the fine. If you're risk neutral and the benefit of the crime is 11 euros with a 10% chance of a 100 fine, that gives an expected cost of 10 euros. You're going to commit the crime under this punishment regime if and only if the benefit exceeds the cost. Whether a crime happens or not is independent of which option you choose, under the assumption of risk neutrality.

Okay. Does anyone else want to attempt to defend one of these?

Or maybe we can just say that they are equally good; we don't care, they're just exactly the same.

But that's not the answer.

One of these is better in terms of cost-benefit. It gives more benefits at a lower cost.

Of course, you have to assume something about what those costs and benefits are. It's not a complete set of assumptions here.

Let me say, anyone, last chance?

Is the...

So you think 10% is more expensive? Yes. In terms of which costs? Who is paying this cost? Society, with the resources it costs to detect.

Okay, but why would 10% detection... So think about detecting people who don't pay their tickets in the metro system. Having a 10% probability of detection means that you check every 10 trains. But here you have to check all of the trains, which seems more costly.

But I think it's right to think about which one of these is more costly, like 10% or 100%. I think the answer is the opposite: this one is more expensive than this one. If you want to make the probability of detection 100%, you need to check everyone on the metro. Here, you only need to check every 10%.

Of course, if you check fewer people on the metro, you need to have a higher fine once you get detected. So you need to have a 100 euro fine instead of a 10 euro fine.

Anyone have different perspectives?

So this is my answer: according to the theory so far, it's better to have a low probability of detection and a high fine than a low fine and a high probability of detection. This approach saves resources in society because having a very high detection rate requires a lot of police costs and detection costs.

And the fine is really... it's higher here, but that's not the cost. It's a cost for the criminal to pay this fine, but the state will keep that 100 euro and can spend it on something, right?

So, the 90% of crimes going undetected raises an important question. If this is enough to deter crime, consider a crime with a benefit of eight euros. If the probability of detection on the metro is very high, then no one will commit the crime because the 10% chance of a 100 euro fine is enough to make everyone pay for their ticket. The ticket costs only eight euros. This 10% detection rate doesn't necessarily mean many crimes are happening without detection. However, some people might have a very high benefit from not paying the ticket and won't be deterred. In that case, you would only detect 10% of them, and the others would remain unpunished. Is that a problem? It could be seen as a problem because it creates inequality; some people get away with it while others do not. If we care about inequality, this situation might be worse than one where everyone is treated equally.

Let me try to translate this. The idea is that if it's possible to achieve a 100% detection rate, it must be very cheap to do so. The fact that you can actually achieve this means it is cheaper than other methods. If these crimes are not the same, some are much easier to detect. We want crimes that are easy to detect. However, for a given crime with a specific cost of detection, a higher detection probability will naturally be more costly.

More comments?

This is what I mentioned earlier. Gary Becker, a famous economist and one of the founders of law and economics, argued that it's optimal to impose a very high fine with a very low probability of detection. This is the best way to fight crime. Now, let's think about this. Do you see any problems with that argument? We just discussed that having extremely high fines and a small probability of detection is much cheaper than having a high detection probability. Can you identify any issues with that argument?

You can discuss with your neighbor if you want, and when you have something, you can raise your hand.

I'm just going to wait until I see a hand. Continue discussing, but eventually, I want to see someone raise their hand.

Yes, Alexander.

Okay, so let me translate that to English. The point was that there's not a proportionality between the severity of the crime and the punishment. If you have a very small crime, like not paying your ticket on the metro, and the fine is one million, it doesn't feel proportional.

The punishment can be very severe. I think that's a valid point. We can think about this from an inequality perspective. This is going to be extremely bad for the few unlucky people who are caught and will suffer a lot. There may not be ways to really compensate them through the tax system. So, you should consider the inequality issue when you have these extremely high fines.

Of course, if the fine is high enough, you never have to actually impose it because people will behave and pay their ticket in the end.

There is this idea in law that the fine should be proportional to the crime somehow.

Why that is the case can probably be explained by law and economics, but we don't have that explanation yet. One can argue that, according to the law, the punishment should be proportional. We want to explain that using economic theory, but it's correct that the law typically has this idea that the punishment should be proportional. Can anyone see any other problems with this argument? Why don't we see that in practice? We don't see extremely high fines for not paying the ticket on the metro and very low probability of detection.

Yep.

Yeah.

This is an argument that people aren't completely rational and risk-neutral. There are theories in what's called behavioral economics where people...

have shown that people don't really care about extremely small probabilities. If an event happens with an extremely small probability, you kind of ignore it. If there's an extremely small probability of having to pay a 100 billion fine, you ignore that too. Even in expectation, you have to pay 10 in fines, but you tend to ignore these very small probabilities. That's one way of rephrasing what you said. We are not going to cover those behavioral economic theories in this course, but that's my way of connecting these ideas to economics.

Other reasons why this is not going to be possible in practice.

### Slide 28 - Reason 1: The CEO Might Not Be Able to Pay Damages

You haven't mentioned the problem I'm going to talk about. So last chance, anyone who wants to try? The problem I'm going to discuss is that not everyone can actually pay a fine. If you can't pay that fine, there's a limit to how high the fine can be. A lot of people can't pay it. You can't have a very small probability of detection because there's a limit to how high the fine can be. You cannot fine people more than what they have or their future earnings.

Most criminals won't be able to pay a very high fine. If you're unable to pay the fine, typically you have to be sent to prison for criminal offenses. Imprisonment is extremely costly. A fine is good because it doesn't have a social cost. In terms of cost-benefit analysis, the cost is that the criminal has to pay the fine, but the benefit is that the state gains this value and can use it to pay for schools or other needs. Paying a fine is not socially costly, but imprisonment is extremely costly for society. The cost includes maintaining prisons. In Norway, the cost of having a person imprisoned for a year is about one million Norwegian kroner. It's very expensive to maintain prisons. It's also costly for the criminal to be incapacitated. While that's the punishment, it leads to a gain for the state, but imprisonment doesn't provide any benefit for the state. Unless you have people working in prison jobs, which we don't do, there's no benefit to having people in prison. Imprisonment is extremely costly and has no benefit. We want to rely on fines as much as possible. If you think about the picture we saw, there is a 100% detection probability with a punishment of a 1,000 fine, or a 10% probability with a 100,000 fine. Many people can't pay that, so you have to put them in prison instead to achieve the same deterrence. For example, 15 days of prison would be much more costly than having a 25% detection rate. Even though this is more costly in terms of policing, it's much more costly in terms of punishment if you actually have to punish people. So it's likely better to have a higher detection probability so you can have a fine that people can actually pay.

I already mentioned this, so let me skip it. You already saw the answer, but it's not easy because if this is really deterring people, if they aren't committing this crime because of the 10% probability of spending 15 days in prison, then you don't have to carry out the punishment. This seems extremely costly, but if you can deter everyone and no one commits the crime anymore, you don't have to do that. It could still be optimal to have a low detection probability and threaten imprisonment, but if that's enough to ensure that no one commits the crime, you won't have to carry out that very costly punishment.

This is why it's not possible to tell what is optimal here. It depends on whether you're able to deter a substantial number of people or if you actually have to carry out the punishment.

Okay.

What if fines are not possible at all? Think of a crime that has a lot of benefits for the criminal. You cannot devise a fine that is high enough to deter that criminal. You have to rely on imprisonment. What is the optimal number of years in prison for this crime? We can discuss whether to have a one-year imprisonment with a high probability of detection or a 10-year imprisonment with a low probability of detection. It could be the case that all of these strategies give the same level of deterrence, meaning the same people will commit the crime under each rule. The social cost per day of prison is one thousand euros. What is the best way to handle this? Try to answer this question and feel free to discuss with your neighbors before you respond.

Thank you.

Thank you.

I'm going to give you one minute to respond, and then I'll show your answer.

You have 10 seconds left if you want to submit your response.

Okay, safe bet to say not possible to tell.

So let me...

tell you my first take. Ten years of prison sounds much costlier than one year of prison, right? Each year of imprisonment is very costly. So it seems like 10 years of prison will be much costlier for society. But remember, this is only a 10% detection rate. Only 10% of the criminals will be in prison. If you count the total number of person prison years, this will be the same. For example, say there are 10 criminals. They will each serve one year in prison, so this will be 10 years in total. In the other case, there's only one criminal, but that person will serve 10 years in prison. So this is also 10 years in total as the prison cost for both scenarios. Alexander? No.

Yeah, so definitely. This is like 100%, 50%, 25%, and 10%. I should have added that here maybe so it was clear.

So in terms of the actual punishment cost, this is the same.

Then we have to think about the policing cost. A 10% probability of detection is cheaper than a 100% probability of detection. Again, we have the Gary Becker result that a low probability of detection is better and cheaper for society than having high prison sentences.

Yep.

The point of having imprisonment is the deterrence effect, meaning that people are not committing the crime. We hope that we don't have to carry out the punishment at all, but for some criminals, they may not be deterred, and we have to actually carry out the punishment. Then we have to think about the punishment cost.

You could say that we never have to put people in prison because people are not going to commit the crime. In that case, it doesn't matter what you do here. It does matter in terms of policing cost, but we don't have to think about the punishment cost.

Okay, so this is Gary Becker again. His argument for fines can be applied to prison sentences as well.

Can you see a problem with this argument for imprisonment? I won't give you much time for this because I want to finish this slide deck today. But I'll give you about one minute to talk. I hope at least one hand goes up. If not, I'll tell you what the problem is with this argument.

Thank you.

Does anyone want to guess what I have in mind, or maybe you have other ideas about what the problem is with this argument? We don't see large imprisonments for all kinds of crimes in practice.

We also don't have very small detection rates. Who knows what a detection rate is? What we do see is that we don't have very large prison sentences for all kinds of crime. We have this proportionality principle where the punishment is proportional to the crime.

Let me tell you the problem. The problem is this.

Assume there's life imprisonment for robbing a bank. This person has just robbed the bank, and the policeman is chasing him. The criminal can escape by killing the policeman. Would the criminal do that? Yes, because there is no additional punishment. There's already life imprisonment for this. So killing someone on top of that doesn't add to the punishment. The problem with having very large fines or long imprisonment for small crimes is that if you fear getting caught, you have incentives to commit more crimes to avoid detection. Similarly, if you've engaged in one crime and know you're going to be detected, you might engage in more crimes because the additional punishment doesn't really matter if you're going to get life imprisonment in the end. In Norway, there's a cap of 21 years. In other countries, it could be life imprisonment, but there's still a cap. We cannot have large imprisonment sentences for all kinds of crimes because that can lead to situations like this. In the end, we need to have moderate detection probabilities. This argument from Gary Becker doesn't really apply in practice. We need to invest in policing and have a sufficient detection probability. Just having very large punishments won't work. I presented Gary Becker's argument for why we might want small probability detection and high punishment, but then I gave you the counterargument. This counterargument implies that we need to invest sufficiently in the probability of detection.

Back to Wirecard. Should we spend more effort detecting fraud? Should we increase the detection rate?

Let me check how much I have left of this slide deck to see if I can finish.

Yep.

We don't have time to talk about this, but you can think about which factors determine whether prosecutors or police should spend more time detecting fraud. One thing to consider is whether we're reaching a limit where the punishments are too high, so the fines are so high that criminals cannot pay them. Maybe we want to increase the detection rate to impose fines instead of imprisonment for fraud. Or even if we accept that we need imprisonment for fraud because fines won't be sufficient, we need to think about...

Whether this imprisonment sentence needs to be very high to deter fraud creates a problem for the CEO, who may commit more crimes to cover up the fraud. These are factors to think about when deciding whether to increase the effort in detecting crime compared to just increasing the punishment.

If this CEO is able to pay huge fines, then it's acceptable to have a small probability of detection.

But this is unlikely to be true, so you likely want to have a decent detection probability.

### Slide 33 - Next Lecture

Next lecture, we're going to talk about other ways of preventing fraud, like tort law, where investors can sue the CEO, and what I call non-legal punishment, which includes things like reputation and social sanctions. We'll discuss that next week. By now, you should have everything you need for the first assignment, so you can start it. I've given you the whole theory that you need for the assignment. See you next week.

## January 20, 2026

### Slide 2 - How To Prevent Fraud

Today we're going to start talking about the first assignment. I'm not going to give you the solutions, but we will discuss it a bit, and I'll give you some help along the way. Then we'll start comparing tort law and criminal law in the second part of the lecture. Just to remind you, the assignments are practice exam questions. The questions on this assignment could have been on the exam. The assignments are mandatory, so you have to do them. This is also a way to practice for the exam. Make sure to use these opportunities to practice and actually attempt the assignments. As I said in the last lecture, I'm trying to teach you a skill, and the only way to learn a skill is to practice. You won't learn what I want you to learn in this course without doing these assignments. You also won't do well on the exam without practicing.

I will always have guidelines to remind you how to answer the questions. I'll give you example solutions so you can see how they could look. The point is that you have to show that you understand the theories and the material in your answer. If you say something very vague or general, I won't be convinced that you understand the material. This is an open book exam, so you could just copy something from the book or your general notes. If you use general language without connecting it to the specific case, I won't be convinced that you actually understand it. Any questions?

Regarding whether you have to cite sources on the exam, you don't have to worry about that. However, if you quote something exactly from the book or the slides, you should cite it. You don't need to specify where the theory comes from in the book. Is that clear? Don't worry about citation. I wouldn't recommend just quoting something from the book, as it wouldn't earn you any points. You should use the theory and apply it to the case. There's no way you'll find something in the book about the specific case on the exam, so there's no reason to copy from the book.

You have to demonstrate that you can apply these theories in a new setting. Show how the theory fits in that context. Use examples connected to the case to illustrate your understanding of how it fits.

It might be a good idea to use a concrete numerical example to show exactly how you're thinking. If you use vague words, it won't be clear how you're thinking. A concrete numerical example will clarify your thought process.

Using a numerical example doesn't guarantee a good grade. However, if the example shows that you've understood the material, it can lead to a good grade.

I want you to explicitly state the theories you're using. For example, if you're using cost-benefit analysis, you should say, "I'm using cost-benefit analysis here."

You often have to make assumptions. The questions on the exam and assignments are open-ended. I won't provide all the possible assumptions you need to make. Typically, you might say, "We assume that the persons are risk neutral," or something similar. I'll show you examples later on how to do that, but you always need some assumptions to solve the problems. It's helpful to clearly state your assumptions, and if you want a very good grade, you can discuss what happens if those assumptions change.

It will be clearer once you see the example solutions that I'm going to post.

Any questions?

Okay, so I suggest we do the following. Hopefully, you have already started thinking about these questions, or maybe some of you have answered them, but probably many of you have not. I want you to sit together in a group and discuss the first question. I'll be walking around to hear what you're thinking. After that, we'll have a discussion together about a good way to approach this question. I will clear up any misunderstandings or confusions. You can sit in groups of two to four. You can either sit in the groups you're going to submit answers with or in any group you want. All right, we will spend some time on this discussion.

Okay, excellent. That's right. It's obvious that you have to use them.

That's what I mean.

### Slide 11 - Mentimeter

Go to menti.com and answer this question. Do you think in this model that the CEO will steal the 100? Will the CEO engage in fraud or not, given this possibility of a lawsuit?

I'll give you one minute to respond. You can talk to your neighbor if you want.

The answer, everyone says yes.

That's wrong.

### Slide 12 - Chapter 3.VII

All right. From talking to some of the groups, it looks like you're all on the right track. For those who didn't see this, the theories you need to use in this question are the theory of the rational criminal, the economic theory of crime, or the Gary Becker model. This theory suggests that people will pay their taxes if the probability of detection is high enough and the fine for not paying is high enough. The second theory to use is cost-benefit analysis to figure out the best way to approach this. The groups I talked to already saw that, which is great. Your task is to write this up in a way that identifies which factors are important. Look at the wording of the question: which factors would affect the design of the system? You need to list factors. For example, if the cost of auditing is very high, then you might want to have a lower probability of detection. I'm not saying that's right or wrong, but your answer must lead to factors that affect the design. You should say something like, if the cost of auditing is high, then you might rely more on higher fines and a higher probability of detection.

Great, so any questions on this?

It's nice that many of you already see how to approach this. We haven't covered tax auditing in the course so far, but you all realize this is very similar to the fraud setting. It's not fraud, but it's a different kind of crime or bad behavior, and the same kind of theory applies. Your grade on the exam will depend on whether you identify which theories to use and apply them effectively to identify the relevant factors in these specific settings.

So, any questions?

I'm going to read a random sample of your responses. You won't get individual feedback, but I'll read some random samples and give you general feedback on how you did.

I think we should spend some time on this second question as well. You can discuss both A and B together. I think B is trickier. If you find A easy, you can move on to B.

But if you have time, you can discuss both.

Let me read this first, and then I'll slide down so you can see A and B. You can continue discussing question two.

But there is a bit different because you have more time. You can also change and ignore the bias.

All right. Let's talk a little bit together. I think for 2A, the people I was talking to had the same idea of using a similar theory to...

theories as in question one.

Think about the incentives for employees to not comply with AML. They might have incentives to do so to attract customers and get bonuses. Management will have some monitoring of their employees to check that they're actually complying. They would spend some money on that monitoring and have some punishment for employees if they don't follow the rules. Of course, there are many things you can change in this system. You can increase the monitoring or increase the punishment.

There are probably some regulations that say what you can and cannot do. For example, can you fire people or not? Maybe you cannot impose a fine on your employees. So it's a bit of a different setting, but you can think of different sanctions.

In this setting, there's also the possibility to change the profit from this crime or whatever the incentives are for employees to not comply in the first place. If you give them a lot of bonuses for getting new customers, you also give them incentives to not comply with AML if they can get a very big customer that may be doing some shady things, like in the Estonia case. The Estonian branch of Danske Bank was extremely profitable because they had all these Russian oligarchs using that bank to enter their money into Europe.

Here again, it's about the factors. Make sure that your answer contains some factors that matter.

It's not like there is one compliance system that is always the best. It may depend on some factors, like how difficult it is to monitor employees, what kind of punishments you can legally impose, like can you fire them if they don't comply, or just not give them bonuses? What kinds of punishment can you apply? Also, what can you do for their incentives? How many people actually want to launder their money, and how big of an issue is this? These are just some examples of factors that might determine the optimal design of this system.

One interesting thing about this question is that you can use cost-benefit analysis even in this setting. This is a limited cost-benefit analysis. You can take into account the costs and benefits of the firm only, of the bank.

We can apply the same idea to the bank by looking at the costs and benefits for the bank. The costs for the bank may include fines they have to pay if they don't comply. The benefit is that they avoid those fines. The costs also include monitoring and other expenses. You can apply this same idea within the firm to think about incentives in the same way we discussed in question one, focusing on the cost-benefit analysis for society as a whole.

Question 2A is a different setting. It may be harder to see how to use this same theory here compared to question 1. Question 2B is the most interesting question.

Why might policymakers impose large fines on the firm for failures to comply with obligations, even if this is only done by one branch or certain individuals? Why not just fine those individuals or impose sanctions against those employees? Does anyone have ideas on how to tackle this question or how to think about it?

This is not obvious. Typically, you think the person committing misconduct should be held responsible, not the top management or the owners of the firm. Why should they be held accountable for something an employee did?

You could imagine a scenario where firms are not liable for what their employees do. If an employee violates the law, that's their problem, and they face the consequences. That's one way to design the law, but that's not how the law is designed.

Typically, if an employee violates the law while acting as an employee of the firm, the firm itself can be held liable. This is somewhat strange, and the question is about using economic theory to explain that.

So, any ideas?

Does anyone have any intuition about why this kind of rule exists?

Or an idea of what kind of economic theory we can use here?

Yes, Anir.

Great. So the idea is that if you make the firm liable for this misconduct, then they have an incentive to monitor their employees and ensure that employees are not engaging in misconduct. It's a way to indirectly hold the employee responsible. You can think of it as the state delegating the task of monitoring employees to the firm. Instead of the state directly checking if all the employees in Danske Bank are following the law, they say that if there's any problem, then Danske Bank will have to pay. This gives Danske Bank the incentive to monitor their employees.

So that is the idea. The question is, why is that system better? Why is this indirect monitoring system better than the state directly fining or punishing the employees?

Any thoughts on why that might be a better system?

Excellent. Part of the story here is that it might be costlier for the state to do the monitoring than for the firm. Making the firm liable and letting them monitor their employees might be cheaper than the state directly monitoring the employees. This is basically a cost argument or a cost-benefit argument. In this question, you have to use cost-benefit analysis and argue that this system of firm liability is cheaper than direct liability of the employees. However, firm liability will only work if the state or someone detects that there is a problem in the bank. If the state never observes that some employees in Danske Bank are not abiding by the law, then Danske Bank will never pay that fine for their employee not following the law, and they won't have the incentive to monitor the employees. In this system of firm liability, the state must also monitor the employees; otherwise, it will break down. If this is never detected, then Danske Bank will never have to pay a fine, and they won't have the incentive to monitor. It's good thinking, but it's not the complete answer, because it's not necessarily the case that by doing this firm monitoring, you can avoid state monitoring.

Great. It could be that the firm thinks they might be detected, but the state is actually not doing much to detect. Or it could be that...

I'm maybe giving you too much, but this is a hard question, so I think it's fine. One can think of the state monitoring with a very low probability of detecting and then having a very high fine if they do detect something. That could give Danske Bank the incentive to actually do the monitoring. By outsourcing the monitoring of the employees to the firm, the state can save by monitoring at a lower intensity. You have to explain why they can't just monitor the employees with very low intensity and then issue a very high fine if they're caught.

Okay. I think that's it for the hints on this. This is a very interesting question, and it shows that this is a much more complicated question. This would be the kind of question I would put on the exam to distinguish the best students from the next best.

This is a hard question. Questions 2A and 2B are the questions I'm going to use to figure out who learned something. These are easier questions, and I will have a question like that on the exam to make sure I know who learned something or who will at least get one of the middle grades. For the very top grade, there will be some question like this that requires a bit of creativity.

All right, any questions on 2B?

No? Okay, let me stop here about assignment one and briefly mention what we're going to look at after the break.

Okay, let me find out how to full screen this in a break. After the break, we're going to talk about tort law versus criminal law.

We're going to ask the question, why do we need criminal law at all when we have tort law? What is the role of criminal law with respect to tort law? Tort law is "statniksrett" in Norwegian. All right, let's take a break, and we'll see each other at 11.

We're going to talk about tort law versus criminal law. Specifically, we're going to discuss why we need criminal law.

Maybe that's a question you never thought about. It feels obvious that we need criminal law, but it may not be clear why. However, once we think about this from an economist's point of view, it becomes clearer. This is one way of preventing fraud.

You could have criminal punishment, and we can also have tort law. In the case of the Wirecard case, the investor could sue the CEO for stealing the money. That's tort law. We don't have a Norwegian translation for "tort," but it means any kind of harmful behavior. It could be an accident; it doesn't have to be intentional.

These are the definitions of torts versus crimes according to law. A tort is harm to an individual, while a crime is harm to the social order. We'll see how that connects to economics later. Tort law, in Norwegian, aims to compensate the plaintiff. Criminal law aims to punish the defendant.

Tort law lawsuits are filed by individuals, while criminal law cases are typically filed by the state, meaning by prosecutors. We can also have private criminal lawsuits, but they are very rare. There are different standards of evidence as well. We won't talk about that now, but you can use economic theory to explain why we have different evidence standards across tort law and criminal law. These are the legal definitions, if you will.

The question of why we have criminal law is interesting because, historically, there wasn't a distinction between tort law and criminal law. Back in the medieval ages, the only kind of lawsuits were private lawsuits. The aim was both to compensate and to punish.

There was no state that entered with a criminal lawsuit.

Individuals entered with lawsuits, and there could be some punishment in those lawsuits, but also compensation. Okay, let's think about tort law.

Let's think about the investor in the Wirecard case suing the CEO for fraud.

Given that possibility, why do we need fraud to also be a criminal offense? There is already a solution to this problem of fraud. In tort law, you can sue the CEO and get compensated. So why do we need criminal law?

This is chapter 12 to A. We're doing this a little bit backwards. This is deep into the book, but we're addressing it now.

Let's consider this simple model. The investor lends 100 to the company. The CEO will choose whether to steal the money or not. After seeing what the CEO does, the investor can choose whether to sue or not. If the investor sues, the court will order the CEO to pay back any stolen money in damages to the investor. Assume that litigation costs are 20, and the loser of the lawsuit pays for those expenses.

### Slide 13 - Game Tree

At each of these nodes, someone is going to make a decision. Here, the CEO will choose to steal or not steal the 100. Then, depending on the choice, the investor will have to decide whether to sue or not to sue.

### Slide 14 - Solution

Why is the answer no?

Let me explain. You may have had different assumptions than what I listed here, or you may have added some assumptions.

If the CEO steals the money, the first question is whether the investor will sue or not. The investor will sue because the court will order the CEO to pay back any stolen money. If the investor sues, the CEO will have to pay back the 100 to the investor. The investor is going to sue, and who will pay for the cost of the lawsuit? The loser, which will be the CEO. So the CEO will have to pay back 100 and also pay 20 for the lawsuit. Is it worth it for the CEO to embezzle these 100? No, because the investor will sue, the CEO will have to pay it back, and they have to pay for the lawsuit.

That's why my answer is no, but maybe someone would want to explain to me why they thought the answer was yes.

Maybe you had in mind a slightly different model or something like that.

Here, if the investor sues, the court will order the CEO to pay back the stolen money. The outcome of the lawsuit is very certain in this case. Maybe that was why you thought the answer was no, because you thought there was some uncertainty in the lawsuit. In that case, the answer could have been yes.

I'm going to explain this using game theory. I gave you the verbal explanation, but let's use game theory as introduced in Chapter 3. It's not going to be very complicated. We think about game theory by setting it up as these game trees. The way to read those trees is...

If the CEO steals and the investor sues, the CEO will end up with minus 20. Why? Because the 100 that was stolen will have to be paid back to the investor in damages, and the CEO will need to pay 20 for the lawsuit. The investor will break even because they will get back the 100 and won't have to pay for the lawsuit, as they will win it.

If the CEO does not steal and the investor sues, the investor will lose the lawsuit and pay 20 for the lawsuit. Obviously, if the CEO does not steal, the investor does not have an incentive to sue. So here, the investor will choose not to sue. In the other case, the investor will choose to sue because they will get back the 100 and not lose 100, like in the previous scenario.

This is how we deal with games like this. They typically have a sequential nature. Someone makes the first move, and then someone else makes a move later. To solve these games, we first look at the last stage and figure out what the investor will do. We already did that. Then we can solve it from the CEO's perspective, knowing what the investor will do. The investor will sue in this case, but not in the other case. It's actually optimal for the CEO not to steal. The CEO will get zero instead of minus 20.

This restates what I said using words and this game tree. It's a useful way of setting things up. It makes clear what the assumptions are and so on.

Any questions about this representation?

On the exam, you're allowed to draw these game trees. You cannot do that directly in WiseFlow, but you can draw it on a separate piece of paper, take a photo with your webcam, and add it to your answers. You don't have to, but in some questions, it might be useful to add a game tree to show how you're thinking.

All right.

### Slide 15 - Mentimeter

In this example, we saw that the possibility of the investor suing is sufficient to avoid fraud. This leads us to a puzzle: why is fraud also a crime? It seems enough that it's a tort and that the investor can sue. So why do we need fraud to be a crime? Talk to your neighbor, and then I want to see some hands with thoughts on why fraud is a crime.

Does anyone want to share their thoughts on why fraud is a crime?

A lot of bad behavior is not a crime. So it's not clear that any kind of bad behavior should be a crime.

Fraud is a crime, but why? Can we use economic theory to explain why fraud, in particular, is a crime? Any thoughts?

Don't write it because responding is up.

### Slide 16 - One Potential Answer

When someone commits fraud, they have to repay what they stole and possibly cover litigation costs if they don't settle. They also face an increased risk of going to jail or paying a fine, which relates to deterrence. It's a cost to society if we have people committing fraud. If we go back to the legal definition of crime, it states that something causing a cost to society is a crime. Typically, crimes generate costs to society, and fraud, in particular, decreases trust in capital markets. This generates costs for society, which, according to legal theory, should mean that it is a crime.

But as an economist, I need to understand why...

this must be the case using economic theory. It's not completely clear to me why that's a valid argument. You might think that fraud has bad consequences for society, but if tort law is sufficient to avoid fraud, then we don't have to worry about those consequences. If an investor is going to sue and that is enough to prevent the CEO from engaging in fraud, then we don't need to make it a crime. For example, breaching a contract is not a crime. However, if people breach contracts frequently, it would decrease trust in contracts, leading to bad consequences for society. According to the legal theory of crime, it should be a crime because of these negative effects. But breaching a contract is not a crime, so this theory is not complete in explaining why certain actions are crimes.

But it's a good intuition. The first point was about deterrence. Your argument was that tort law doesn't provide enough deterrence.

We need extra punishment or something like that. Is that your idea?

Yes.

Okay, excellent. In this simple example, assume they have to pay minus 20 for the lawsuit. Most disputes don't go all the way to court; they are settled somehow. If you settle, you avoid paying all those lawyer costs. The CEO might just say, "Sorry, I’ll give you back the 100," and that's it. There’s no punishment, so there’s no reason to engage in fraud if you only have to give it back.

Excellent.

A key issue with fraud is that it’s not 100% certain you will get caught. If it were 100% certain, like breaching a contract, it’s easy to prove and see, especially if it’s blatant.

So tort law works in the case of breach of a contract, but not necessarily with fraud because there's a chance that you are not caught. If there is a 50% chance that you're caught and you have to pay back 100, then...

you're going to engage in that fraud because, in expectation, you're going to gain 50, which is 100 minus 50% times 100. So let's develop this argument a bit further.

Fraud is not always detected, so tort law is not sufficient to deter fraud. Sorry about this complicated game tree. This is how you could set it up. The CEO will steal, and there's a 20% probability that it's detected and an 80% probability that it's not detected. Then the investor can choose to sue or not sue. If it's not detected and the investor tries to sue, you cannot convince the judge that there was fraud. Maybe you don't have the evidence. You lost a lot of money, but the CEO will say there were some bad business decisions. We just lost the money. Without proof of fraud, you're not going to win the lawsuit, so the investor is not going to sue in that case.

### Slide 18 - Solving The Game

Only if it's detected and you have proof of the fraud can you sue and win. Given this 20% probability of having to pay minus 20% and an 80% probability of gaining 100, the CEO is going to take the chance and engage in the fraud.

If this probability is very high, it's not worth it for the CEO. But if it's low, then tort law doesn't give sufficient incentives to abstain from fraud. So you need extra punishment somehow.

Any questions or comments?

### Slide 19 - "In general, thieves cannot be deterred by the

I think this is a quote I made up. I don't think it's from the book. In general, thieves cannot be deterred by the requirement that they return what they have stolen whenever they get caught. Think about someone stealing a car. If you can just sue the thief and get back the car if you figure out who it is, that's not going to be sufficient punishment for thieves to abstain from stealing cars. You have to have a worse punishment, which is where criminal law will enter. The punishment of compensating the victim is not sufficient to deter bad behavior that is not discovered with 100% certainty. For bad behavior that is discovered with 100% certainty, you could use tort law. But for behaviors that are not discovered with 100% certainty, you need some worse punishment.

### Slide 20 - Alternative solution: Punitive damages

In tort law, you can think about a different solution. We don't have this in Norway, but in the U.S., they have what's called punitive damages. In a tort system, you can sue and get back not only the full compensation but also something more, and that extra amount is there to provide that additional punishment. It's not necessarily clear that you need criminal law to get that extra punishment. Maybe you can just say that for these bad behaviors that are not detected with 100% probability, you need to double the damages to the victim.

### Slide 21 - Chapter 7.II.B

In this case, you have 1,000 in damages. The actual amount stolen was 100, but because the detection probability was so low, you have an extremely high level of damages here. Even if the probability of detection is low, the CEO is not going to steal. Tort law works in the sense that it prevents fraud in this model. We still don't have a perfect theory of why we need criminal law. It seems like tort law with some extra punitive damages could do it, even in this case. Any questions or comments?

Good point. It might seem strange that the victim is going to get this very high compensation, and it might encourage too many lawsuits by plaintiffs because they can get these extremely high values. That could be one downside of this kind of system. We're not going to talk about that in terms of economic theories, but that could at least intuitively be one problem with this.

### Slide 23 - Mentimeter

Okay, let's try this calculation exercise. If you look in MetaMeter, can you see the game tree? Try to figure out how high the punitive damages must be to stop the CEO from stealing. What is the exact level? If it's high enough, the CEO won't engage in the fraud. If it's low enough, the CEO will engage in the fraud. What is the cutoff? What is the lowest possible level of the damages that is sufficient to deter the conduct? Spend some time calculating this, and then I want you to answer on Mentimeter.

### Slide 24 - Solution

The answer here is correct in a general sense, but I want a number. I want the exact number.

To solve this, you need to remember how to solve an equation with one unknown.

There are no correct answers so far.

I'll give you some seconds to try. You're not correct so far.

### Slide 25 - Solution

I'm going to give you my answer. At least I activated you, even though you didn't solve this yet. You need to solve this as an equation with one unknown. For the CEO to prefer not stealing, we need that 80%, which is the probability that the CEO will keep the 100, times 100, to be higher than 20% plus 20, which is the lawsuit cost, and X, which is the damages. Solve this for X, and you get the answer, which is 380.

You don't need that much. 380 is sufficient. If this is 380, then damages plus the cost of the losses is 400. 400 times 20% is 80, which is exactly the same as the benefit of the fraud. That's the value at which the CEO is indifferent. If the damages are higher than 380, the CEO has strict incentives not to engage in the fraud.

You don't have to answer on the exam using this method. I'm not going to write exam questions that force you to solve equations like this, but this is very simple math. This is like secondary school.

You don't have to answer on the exam using, I'm not going to write exam questions that forces you to solve equations like this, but this is very simple math. This is like secondary school.

So it would be useful to be able to do this.

### Slide 27 - Mentimeter

OK, let's go back and think about why fraud is a crime. Fraud is a crime because the detection probability is low. However, you can have punitive damages, and you can get sufficient deterrence just with tort law. So why do we need fraud to be a crime? In Norway, we don't have punitive damages, but there's no reason why we couldn't have them. In the U.S., where you have punitive damages, you still have criminal law. There seems to be a place for criminal law, but we still don't have the justification in terms of economic theory for why we actually need it. Discuss with your neighbors and think about what might be the problems with punitive damages.

So any thoughts so far?

Okay, I need some ideas here. Why is fraud a crime, and why are punitive damages not enough? Why can't we just have punitive damages instead of criminal law?

### Slide 28 - Reason 1: The CEO Might Not Be Able to Pay Damages

One issue was already mentioned by Henrik, which is that there might be a problem with the plaintiff getting extremely high damages. This could increase the incentives to litigate, even if the chance of winning is low. We're not going to talk about that here. That could be one potential explanation, but there's another explanation as well for why punitive damages won't work in many cases.

There's a very simple reason. When you hear me say it, you'll think, "Great." The punitive damages could be extremely high, so they could be set sufficiently high to make it equally scary.

### Slide 29 - Reason 2: Investors Might Abstain From Suing

Excellent. One potential issue is that some potential plaintiffs may not sue. That's one explanation we will discuss.

You could think of a private lawsuit. There are private criminal lawsuits, so you can pursue that against the CEO to get them imprisoned. Or maybe imprisonment isn't an option in those private lawsuits. But you could imagine a system where plaintiffs bring these criminal cases to get people into prison. In practice, it's the state that does that. This relates to the second issue: lawsuits are risky. In the Wirecard case, there could be many small investors, each suffering a little, but they don't have enough money to pay for lawyers in a complex fraud case. They can pool resources and file a class action lawsuit together to try to overcome those issues, but many cases might not happen in practice. Also, lawsuits are risky, and some people might not want to file one. This is another reason why the state sometimes needs to take on that responsibility and pursue these cases. We return to the problem of fraud costing society. If fraud only generated costs for investors, then the fact that some of them don't file lawsuits would only be a problem for them, not for society as a whole. However, since fraud has a social cost, like reduced trust in capital markets, we need a way to deal with situations where plaintiffs are unwilling or unable to file lawsuits. This is where the idea that crimes are costly to society comes in. But that's not the only explanation for crimes. For example, breach of contracts is not a crime, even though it has negative consequences for society. The combination of bad consequences for society and a low probability of detection is, at least for me, a sufficient explanation for why we have criminal law. All right, that's it for today. We'll sum up next week and then move on to a new topic. See you next week.

### Slide 30 - Investors did not sue the management of Wirecard

A problem with punitive damages is that the criminal often won't be able to pay them. Take the Wirecard case, for example.

The money lost was billions. There's no way the CEO of Wirecard can pay back even those billions, let alone a punitive damage amount like 10 times that. And in many cases, the fraudster might be even poorer than the CEO of Wirecard.

Those are the two issues with this system.

The first is that the CEO might not have the necessary funds to pay damages.

You need some kind of other punishment, like imprisonment.
