# Lecture Transcript: Assignment 1 Discussion

## About This Document

This is a transcript of lectures from the course **GRA6296 - Economic Analysis of Topics in Law** at BI Norwegian Business School, taught by Henrik Sigstad.

**Topic:** Assignment 1 Discussion
**Lecture date(s):** January 20, 2026, January 27, 2026

This transcript has been cleaned for readability. The original was auto-generated from lecture recordings using OpenAI Whisper.

---

## January 20, 2026

So today we're going to start talking about the first assignment. I'm not going to give you the solutions, but we're going to discuss it a bit, and I'll give you some help along the way. Then we'll start comparing tort law and criminal law in the second part of the lecture. Just to remind you, the assignments are practice exam questions. The questions you see on this assignment could have been on the exam. The assignments are mandatory, so you have to do them. This is also a way to practice for the exam, so make sure you use these opportunities and actually try to attempt them. As I said in the last lecture, I'm trying to teach you a skill, and the only way to learn a skill is to practice. There's no way to learn what I want you to learn in this course without doing these kinds of assignments. You won't do well on the exam without practicing.

I'm going to have these guidelines to remind you how to answer the questions. I'll give you example solutions so you can see how they could look. The point is that you have to show that you understand the theories and the material in your answer. If you say something very vague or general, I'm not going to be convinced that you understand the material because this is an open book exam. You could just copy something from the book or your general notes. If you use general language without connecting it to the specific case, I'm not going to be convinced that you actually understand it. Question?

You often have to make assumptions. The questions on the exam and assignments are very open-ended. I don't provide all the possible assumptions you need to make. Typically, you might say something like, "We assume that the persons are risk neutral," or whatever. I'll show you examples later on how to do that, but you always need to have some assumptions to solve these questions. It's helpful if you set that up clearly, stating your assumptions. If you want a very good grade, you can also discuss what happens if those assumptions change.

I'm going to read a random sample of your responses. You're not going to get individual feedback, but I'll read some random samples and give you general feedback on how you did.

I think we should spend some time on this second question as well. You can discuss both A and B together. I think B is trickier. If you find A easy, you can just move on to B.

Let's talk a little bit together. For 2A, the people I was talking to had the same idea of using a similar theory to...

This is a hard question. Questions 2A and 2B are the ones I'm going to use to figure out who learned something. These are easier questions, and I'll have a question like this on the exam to ensure I know who has learned something or who will at least get one of the middle grades. For the very top grade, there will be a question that requires a bit of creativity.

Any questions on 2B?

On the exam, you're allowed to draw these game trees. You cannot do that directly in WiseFlow, but you can draw it on a separate piece of paper, take a photo with your webcam, and add it to your answers. You don't have to, but in some questions, it might be useful to add a game tree to show how you're thinking.

## January 27, 2026

So what we're going to do today is first go over assignment one that you handed in. I read some of it and have some general feedback. I said I wouldn't give you individual feedback, but now I realize I can probably give you AI-generated feedback on the assignment. I'm working on a prompt that will provide reasonable feedback. If that works and you allow me to submit your text to an AI, I'll give you individualized feedback. I'll also write this on its learning. If anyone does not want their assignment given to an AI, let me know, and I won't do it for your assignment. For the others, I'm going to generate feedback, and as long as I'm confident that the quality of the feedback is good enough, I'll give that to you. If the prompt works well, I'll release it for you in the future, so when you're working on the exam and trying to solve exam questions, you can use that prompt to generate feedback on your own answers.

All right, so I added a solution example. Let me briefly show you how it looks. For each of the questions, there's a box or a section called "what a good answer should include." This is general guidance about what your answer should include.

Now let me briefly discuss the solution that I think is the right one and then some comments on your answers.

For question one, you were tasked with designing a tax audit program.

In general, you did very well on this question.

As I mentioned last lecture, you should use cost-benefit analysis and the economic theory of crime.

This is interesting. I'm going to show you this in the next slide. Here is one example of a weakness in an answer that claims the fines should cover the cost of the audit. For it to be a good audit program, it needs to be financed. The fines it collects need to finance the auditing. This seems like a reasonable criterion, but it's not the correct way to think in this case.

The second question was similar, where you were tasked with designing a compliance program to ensure that employees in the bank comply with AML rules.

You can probably improve by discussing when to increase the probability of detection, when to decrease bonuses, or when to increase fines. You cannot really impose fines on your employees, but you can have other kinds of sanctions. In this setting, there's probably a limit to how big these sanctions can be. The ultimate sanction is getting fired; you probably cannot do more than that.

Why should we impose fines on the firms instead of the actual individuals? In reality, we might do both, but why should the firm be held liable and not only the individuals? We have only seen these two theories so far in the course, and you have to use both of them.

An example of a vague claim that is not grounded in a theory is this: the firm is one subject, so it's easier to hold responsible. The firm may have 1,000 employees. It makes sense that it's easier to hold one firm liable than 1,000 employees. You can probably support that statement with economic theory in some way. But in this answer, it's not connected to the theory. All the claims you make should ideally be connected to the theory or explained in terms of economic reasoning.

The question is about a strange rule: if you're guilty beyond reasonable doubt, you can get a very large prison sentence. But if there is some doubt, you get zero punishment. If beyond reasonable doubt means 99% certainty, then if you're guilty with 99% certainty, you get 21 years in prison for a serious crime. But if it's just 98% certain, then you get zero, which is strange. Why wouldn't you punish someone with a 98% certainty of being guilty with, say, 10 years in prison? Why do we go straight from a very high punishment to zero? You can use economic theory to answer that question.

Okay, any questions about the first assignment?

What would you have done in this case to actually detect fraud? It's easy to say with hindsight that Ernst & Young should have seen this, but what would you have done if you had been the auditor of Wirecard?

They can say that they didn't claim there was no fraud. They just said in their statement that they were reasonably sure that Wirecard's statements were correct. They verified a random sample of bank accounts, and everything looked good. As auditors, they cannot be expected to detect all instances of fraud.

The question is, how much auditing should we expect these auditing companies to do? What is really reasonably sure? Were they actually reasonably sure? Did they do a reasonably good audit here or not? That's the key question the court will consider when looking at the Wirecard case. Of course, in hindsight, it's easy to say they should have audited more, but maybe it's not reasonable for audit firms to check everything. It can be very costly.

The benefit of that is multiplied by what the investors are going to invest. The investors here are going to invest 1 million. 1 million times 0.4 percentage points is 4,000.

The cost of verifying the account is easy; it's 100 euros by assumption.
